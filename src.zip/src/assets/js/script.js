// document.getElementById("btnSwitch").addEventListener("click", () => {
//   if (document.body.classList.contains("dark")) {
//     document.body.classList.remove("dark");
//   } else {
//     document.body.classList.add("dark");
//   }
//   document.getElementById("darkTheme").innerText = document.body.classList;
// });

// Theme Change
function themeChange() {
  var element = document.body;
  // var sidebar = document.getElementById("sidebar");
  var homesection = document.getElementById("home");
  // var cr = document.getElementById("cr");

  var head = document.getElementById("head");

  var search = document.getElementById("search");

  var breadcrumb = document.getElementById("breadcrumb");

  // var rightsec = document.getElementById("right-sec");

  var imgchng = document.getElementById("sunmoon");

  element.classList.toggle("light-mode");
  // sidebar.classList.toggle("light-mode");
  homesection.classList.toggle("light-mode");
  // cr.classList.toggle("light-mode");
  head.classList.toggle("light-mode");

  search.classList.toggle("light-mode");

  breadcrumb.classList.toggle("light-mode");

  // notification
  var noti1 = "img/notification.svg",
    noti2 = "/img/notification-black.svg";
  var imgElement = document.getElementById("noti");

  imgElement.src = imgElement.src === noti1 ? noti1 : noti2;

  // bug

  var bug1 = "img/bug.svg",
    bug2 = "/img/bug-black.svg";
  var imgElement = document.getElementById("bug");

  imgElement.src = imgElement.src === bug1 ? bug1 : bug2;

  // help
  var help1 = "img/help.svg",
    help2 = "img/help-black.svg";
  var imgElement = document.getElementById("help");

  imgElement.src = imgElement.src === help1 ? help1 : help2;
}
