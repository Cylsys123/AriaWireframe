$(document).ready(function () {
  $("#btn2").click(function () {
    if ($("#sidenav").width() == 78) {
      document.getElementById("sidenav").style.width = "285px";
      document.getElementById("main").style.paddingRight = "170px";
      // document.getElementById("slidebtn").style.paddingRight = "250px";
    } else {
      document.getElementById("sidenav").style.width = "78px";
      document.getElementById("main").style.paddingRight = "0";
      // document.getElementById("slidebtn").style.paddingRight = "78px";
    }
  });
});

$(document).ready(function () {
  $("#btn4").click(function () {
    let innerModal = document.getElementById("azt-summary");
    let closeBtn = document.getElementById("inner-content");
    innerModal.classList.toggle("col-md-3");

    if (innerModal.classList.contains("col-md-3")) {
      closeBtn.classList.replace("col-md-10", "col-md-8"); //replacing the iocns class
    } else {
      closeBtn.classList.replace("col-md-8", "col-md-10"); //replacing the iocns class
    }
  });
});

function hideShow() {
  $("#d-show").removeClass("d_hide");
  $("#d-hide").addClass("d_hide");
}

function hideShow2() {
  $("#d-show").addClass("d_hide");
  $("#d-hide").removeClass("d_hide");
}

function editBtn() {
  $("#d-hide").addClass("d_hide");
  $("#d-show").removeClass("d_hide");
}

function editClose() {
  $("#d-show").addClass("d_hide");
  $("#d-hide").removeClass("d_hide");
}

function openclose() {
  let sidebar = document.querySelector(".sidebar");
  sidebar.classList.toggle("open");
  document.getElementById("home").classList.toggle("collapsed");
  document.getElementById("head_row").classList.toggle("searchbar_pl");
  document.getElementById("sidenav2").classList.toggle("collapsed");
}

function btn3() {
  let modal = document.getElementById("cus-body");
  modal.classList.toggle("collapsed");
  document.getElementById("innerSidebar").classList.toggle("col-md-2");
  document.getElementById("innerBdy").classList.toggle("col-md-10");
}
