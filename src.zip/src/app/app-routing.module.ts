import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
 // {path: 'post-install-wizard', redirectTo:'/dashboard', pathMatch: 'full'},
  {
    path: '',
    loadChildren: () =>
      import('./features/auth/auth.module').then((m) => m.AuthModule)
  },
  {
    path: '',
    loadChildren: () =>
      import('./features/home/home.module').then((m) => m.HomeModule)
  },
  {
    path: '',
    loadChildren: () =>
      import('./features/post-install-wizard/post-install-wizard.module').then((m) => m.PostInstallWizardModule)
  },

  {
    path: '',
    loadChildren: () =>
      import('./features/policy/policy.module').then((m) => m.PolicyModule)
  },
  {
    path: '',
    loadChildren: () =>
      import('./features/notification/notification.module').then((m) => m.NotificationModule)
  },
  {
    path: '',
    loadChildren: () =>
      import('./features/device/device.module').then((m) => m.DeviceModule)
  },

  {
    path: '',
    loadChildren: () =>
      import('./features/inventory/inventory.module').then((m) => m.InventoryModule)
  },

  {
    path: '',
    loadChildren: () =>
      import('./features/reports/reports.module').then((m) => m.ReportsModule)
  },

  {
    path: '',
    loadChildren: () =>
      import('./features/settings/settings.module').then((m) => m.SettingsModule)
  },

  { path: '**', redirectTo: '/login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
