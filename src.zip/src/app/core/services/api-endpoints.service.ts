// Angular Modules
import { Injectable } from '@angular/core';
// Application Classes
import { UrlBuilder } from '../../shared/classes/url-builder';
import { QueryStringParameters } from '../../shared/classes/query-string-parameters';

// Application Constants
import { Constants } from 'src/app/config/constant';

@Injectable()
export class ApiEndpointsService {
  constructor(
    // Application Constants
    private _constants: Constants
  ) { }
  /* #region URL CREATOR */
  // URL
  private createUrl(
    action: string,
    isMockAPI: boolean = false
  ): string {
    const urlBuilder: UrlBuilder = new UrlBuilder(
      isMockAPI ? this._constants.API_MOCK_ENDPOINT :
        this._constants.API_ENDPOINT,
      action
    );
    return urlBuilder.toString();
  }
  // URL WITH QUERY PARAMS
  private createUrlWithQueryParameters(
    action: string,
    queryStringHandler?:
      (queryStringParameters: QueryStringParameters) => void
  ): string {
    const urlBuilder: UrlBuilder = new UrlBuilder(
      this._constants.API_ENDPOINT,
      action
    );
    // Push extra query string params
    if (queryStringHandler) {
      queryStringHandler(urlBuilder.queryString);
    }
    return urlBuilder.toString();
  }

  // URL WITH QUERY PARAMS
  private createUrlWithQueryParametersExclude(
    action: string,
    queryStringHandler?:
      (queryStringParameters: QueryStringParameters) => void
  ): string {
    const urlBuilder: UrlBuilder = new UrlBuilder(
      this._constants.API_ENDPOINT,
      action
    );
    // Push extra query string params
    if (queryStringHandler) {
      queryStringHandler(urlBuilder.queryString);
    }
    return urlBuilder.toString();
  }

  // URL WITH PATH VARIABLES
  private createUrlWithPathVariables(
    action: string,
    pathVariables: any[] = []
  ): string {
    let encodedPathVariablesUrl: string = '';
    // Push extra path variables
    for (const pathVariable of pathVariables) {
      if (pathVariable !== null) {
        encodedPathVariablesUrl +=
          `${encodeURIComponent(pathVariable.toString())}/`;
      }
    }
    const urlBuilder: UrlBuilder = new UrlBuilder(
      this._constants.API_ENDPOINT,
      `${action}${encodedPathVariablesUrl}`
    );
    return urlBuilder.toString();
  }
  /* #endregion */


  //Example

  //   public getNewsEndpoint(): string {
  //     return this.createUrl('news');
  //   }

  //   This method will return:
  //    https://domain.com/api/news


  //   public getNewsEndpoint(): string {
  //     return this.createUrl('news', true);
  //   }

  //   This method will return:
  //   https://mock-domain.com/api/news


  //   public getProductListByCountryAndPostalCodeEndpoint(
  //     countryCode: string, 
  //     postalCode: string
  //   ): string {
  //     return this.createUrlWithQueryParameters(
  //       'productlist', 
  //       (qs: QueryStringParameters) => {
  //         qs.push('countryCode', countryCode);
  //         qs.push('postalCode', postalCode);
  //       }
  //     );
  //   }

  //   This method will return:
  //   https://domain.com/api/productlist?countrycode=en&postalcode=12345


  //   public getDataByIdAndCodeEndpoint(
  //     id: string,
  //     code: number
  //   ): string {
  //     return this.createUrlWithPathVariables('data', [id, code]);
  //   }

  //   This method will return:
  //   https://domain.com/api/data/12/67


  // Now, let’s go to a component and use them all together.

  // constructor(
  //   // Application Services
  //   private apiHttpService: ApiHttpService,
  //   private apiEndpointsService: ApiEndpointsService
  // ) {
  //     ngOnInit() {
  //     this.apiHttpService
  //       .get(this.apiEndpointsService.getNewsEndpoint())
  //       .subscribe(() => {
  //         console.log('News loaded'))
  //       });
  // }

  public getCSRFEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_CSRF);
  }

  public getLoginEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_LOGIN);
  }

  public getLogoutEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_LOGOUT);
  }

  public getSessionEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_SESSION);
  }

  public getCheckauthEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_CHECKAUTH);
  }

  public getNetworkEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_NETWORK);
  }

  public getProxyEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_PROXY);
  }

  public getAdminUserEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_ADMIN_USER);
  }

  public getSiteNotesEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_SITE_NOTES);
  }

  public getSendMailEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_SENDMAIL);
  }

  public getSecretQuesByUsernameEndpoint(
    usename: string
  ): string {
    return this.createUrlWithPathVariables(this._constants.API_ENDPOINT_SECRET_QUES, [usename]);
  }

  public getChangePasswordEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_CHANGE_PASSWORD);
  }

  public getNewDeviceEndpoint(creationDate: any): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_DEVICE,
      (qs: QueryStringParameters) => {
        qs.push('creation', creationDate);
      }
    );
  }

  public getDeviceEndpoint(id: any = undefined,): string {
    if (id) {
      return this.createUrlWithPathVariables(this._constants.API_ENDPOINT_DEVICE, [id]);
    } else {
      return this.createUrl(this._constants.API_ENDPOINT_DEVICE);
    }
  }

  public getDeviceGroupEndpoint(id: any = undefined): string {
    if (id) {
      return this.createUrlWithPathVariables(this._constants.API_ENDPOINT_DEVICE_GROUP, [id]);
    } else {
      return this.createUrl(this._constants.API_ENDPOINT_DEVICE_GROUP);
    }
  }

  public getNotificationEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_ALERT_LIST);
  }

  public getNotificationWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_ALERT_LIST,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getAlertEndpoint(creationDate: any): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_ALERT_CATEGORY_LIST,
      (qs: QueryStringParameters) => {
        qs.push('date_added', creationDate);
      }
    );
  }

  public getNotificationCatEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_ALERT_CATEGORY_LIST);
  }

  public getNotificationStatusEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_ALERT_STATUS);
  }

  public getPolicyEndpoint(
    id: string
  ): string {
    return this.createUrlWithPathVariables(this._constants.API_ENDPOINT_POLICY, [id]);
  }

  public getCreatePolicyGroupEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_POLICY_GROUP);
  }

  public getCounterMeasurePolicyEndpoint(
    id: string
  ): string {
    return this.createUrlWithPathVariables(this._constants.API_ENDPOINT_COUNTER_MEASURE_POLICY, [id]);
  }

  public getPolicyGroupEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_POLICY_GROUP);
  }

  public getPolicyWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_POLICY,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getCounterMeasureWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_COUNTER_MEASURE_POLICY,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getPolicyGroupWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_POLICY_GROUP,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getPolicyGroupValidateNameWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_POLICY_GROUP_VALIDATE,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getPolicyGroupTempWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_POLICY_GROUP_TEMP,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getPolicyGroupByIdEndpoint(
    policyGroupid: any
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_POLICY_GROUP,
      (qs: QueryStringParameters) => {
        qs.push('id', policyGroupid);
      }
    );
  }

  public getDevicesGroupEndpoint(id: any = undefined): string {

    return this.createUrl(this._constants.API_ENDPOINT_DEVICE + "?device_group=" + id);
  }

  public getOtherDevicesEndpoint(id: any = undefined): string {

    return this.createUrl(this._constants.API_ENDPOINT_DEVICE + "?exclude" + '&device_group=' + id);
  }

  public getDeviceWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_DEVICE,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getDeviceGroupWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_DEVICE_GROUP,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public bulkChangeDeviceGroup(): any {

    return this.createUrl(this._constants.API_ENDPOINT_CHANGE_DEVICE);
  }

  public bulkDevicesUnregister(): any {
    return this.createUrl(this._constants.API_ENDPOINT_UNREGISTER_DEVICE);
  }

  public addDeviceGroup(): any {

    return this.createUrl(this._constants.API_ENDPOINT_DEVICE_GROUP);
  }

  public getDataByIdEndpoint(id: string): string {

    return this.createUrlWithPathVariables(this._constants.API_ENDPOINT_DEVICE_GROUP, [id]);
  }

  public getNotificationChildrenEndpoint(id: string, category: number, status: number): string {
    return this.createUrl(this._constants.API_ENDPOINT_ALERT_LIST_GROUP + "?device=" +
      id + "&category=" + category + "&status=" + status);
  }

  public resolveNotificationEndpoint() {
    return this.createUrl(this._constants.API_ENDPOINT_ALERT_RESOLVE);
  }

  public getAuditTrailEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_AUDIT_TRAIL);
  }

  public getAuditTrailWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_AUDIT_TRAIL,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getAlertTriggerEndpoint(id: any = undefined,): string {
    if (id) {
      return this.createUrlWithPathVariables(this._constants.API_ENDPOINT_ALERT_TRIGGER, [id]);
    } else {
      return this.createUrl(this._constants.API_ENDPOINT_ALERT_TRIGGER);
    }
  }

  public getAlertTriggrtFileNameWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_ALERT_FILENAME,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getAuditEventTypeWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_AUDIT_TRAIL_CATEGORY_LIST,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getAuditUsernameWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_AUDIT_TRAIL_USERS,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  // public getAuditTrailWithQueryParamsEndpoint(page_size: number, id: string, category: number, status: number): string {
  //   return this.createUrl(this._constants.API_ENDPOINT_ALERT_LIST_GROUP + "?page_size=" + page_size + "&device=" +
  //     id + "&category=" + category + "&status=" + status);
  // }


  public deleteDeviceGroups(id) {
    return this.createUrl(this._constants.API_ENDPOINT_DEVICE_GROUP + id) + '/';
  }

  public getDevicesWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_DEVICE,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }
  public getOtherDevicesWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParametersExclude(
      this._constants.API_ENDPOINT_DEVICE,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }

      }
    );
  }

  public getVersionEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_SYSTEM);
  }

  public getDeviceGroupNameEndpoint(
        name: string, 
      ): string {
        return this.createUrlWithQueryParameters(
          this._constants.API_ENDPOINT_DEVICE_GROUP, 
          (qs: QueryStringParameters) => {
            qs.push('name', name);
          }
        );
      }

  // Export to CSV and SYSLOG
  public getAuditInCSV(): string {
    return this.createUrl(this._constants.API_ENDPOINT_GET_AUDIT_CSV_FORMAT);
  }

  public getAuditInSyslog(): string {
    return this.createUrl(this._constants.API_ENDPOINT_GET_AUDIT_SYSLOG_FORMAT);
  }

  public getInventoryAppWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_INVENTORY_APP,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getInventoryAppFilenameWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_INVENTORY_APP_FILENAMES,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getInventoryAppGroupWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_INVENTORY_APP_GROUPS,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public getInventoryAppNamesEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_INVENTORY_APP_NAMES);
  }

  public getInventoryAppDevicesEndpoint(): string {
    return this.createUrl(this._constants.API_ENDPOINT_INVENTORY_APP_DEVICES);
  }
  
  // Reports
  public generateReport(): string {
    return this.createUrl(this._constants.API_ENDPOINT_REPORTS);
  }

  public getReportGroups(): string {
    return this.createUrl(this._constants.API_ENDPOINT_GET_REPORT_GROUPS);
  }

  public getReportslWithQueryParamsEndpoint(
    queryParamsObj: Object
  ): string {
    return this.createUrlWithQueryParameters(
      this._constants.API_ENDPOINT_REPORTS,
      (qs: QueryStringParameters) => {
        for (let queryParamKey in queryParamsObj) {
          qs.push(queryParamKey, queryParamsObj[queryParamKey]);
        }
      }
    );
  }

  public deleteReport(id) {
    return this.createUrl(this._constants.API_ENDPOINT_REPORTS + id) + '/';
  }

}