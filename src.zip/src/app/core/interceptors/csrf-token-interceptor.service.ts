import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { tap } from 'rxjs/operators';
import { AuthService } from 'src/app/features/auth/services/auth.service';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class CsrfTokenInterceptorService implements HttpInterceptor {

  stringifiedData: any;
  constructor(
    private _cookieService: CookieService,
    private _authService: AuthService,
    private _router: Router,
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      const token = this._cookieService.get('csrftoken');
      // const dupReq = req.clone({ headers: req.headers.set('X-CSRFToken', token) });
      const headers = new HttpHeaders({
        'X-CSRFToken': token,
        'credentials': "include"
      });
      const cloneReq = req.clone({ headers });
      return next.handle(cloneReq);
    } else {
      return next.handle(req).pipe(
        tap(event => {
          // if (event instanceof HttpResponse) {

            
          // }
        }, error => {
          // http response status code
          if(error.error.detail == "Authentication credentials were not provided."){            
              sessionStorage.setItem('isAuthenticated','false');
              this._router.navigate(['login']);            
          }
        })
      )
    }
  }
}
