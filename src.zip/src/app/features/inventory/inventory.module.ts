import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InventoryRoutingModule } from './inventory-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ApplicationComponent } from './components/application/application.component';
import { InventoryMainComponent } from './components/inventory-main/inventory-main.component';
import { HomeModule } from '../home/home.module';
import { InventoryResolverService } from './services/inventory-resolver.service';
import { RightFilterInvComponent } from './components/right-filter-inv/right-filter-inv.component';


@NgModule({
  declarations: [
    ApplicationComponent,
    InventoryMainComponent,
    RightFilterInvComponent
  ],
  imports: [
    CommonModule,
    HomeModule,
    InventoryRoutingModule,
    TranslateModule,
    SharedLazyModule,
    InfiniteScrollModule
  ],
  providers: [
    InventoryResolverService
  ]
})
export class InventoryModule { }
