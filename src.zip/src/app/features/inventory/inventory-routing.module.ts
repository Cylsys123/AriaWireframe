import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { ApplicationComponent } from './components/application/application.component';
import { InventoryMainComponent } from './components/inventory-main/inventory-main.component';
import { InventoryResolverService } from './services/inventory-resolver.service';

const routes: Routes = [
  {
    path: 'inventory', 
    canActivate: [AuthGuard],
    component: InventoryMainComponent,
    children:[
      {path:'', component:ApplicationComponent, resolve: {inventory: InventoryResolverService}},
      { path: '**', redirectTo: '/inventory', pathMatch: 'full' },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InventoryRoutingModule { }
