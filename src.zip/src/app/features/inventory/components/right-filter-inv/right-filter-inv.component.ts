import { DatePipe } from '@angular/common';
import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { InventoryService } from '../../services/inventory.service';

@Component({
  selector: 'app-right-filter-inv',
  templateUrl: './right-filter-inv.component.html',
  styleUrls: ['./right-filter-inv.component.css']
})
export class RightFilterInvComponent implements OnInit, OnChanges {
  isOpened: boolean = false;
  selectedFilterArr: any = [];
  detectDate: number = 0;
  @Input() url: string;

  platformArr: any = [];
  platformArrItem: any = [];

  applicationArr: any = [];
  applicationArrItem: any = [];

  statusArr: any = [];
  statusArrItem: any = [];

  triggerFileArr: any = [];
  triggerFileArrItem: any = [];

  vendorArr: any = [];
  vendorArrItem: any = [];

  deviceArr: any = [];
  deviceArrItem: any = [];

  filterList:object = {
    platform:'platform',
    application_name:'application_name',
    status:'status',
    filename:'filename',
    vendor:'vendor',
    device:'device'
  }

  constructor(
    private _inventoryService: InventoryService,
    private translate: TranslateService,
    public datepipe: DatePipe
  ) { }


  ngOnChanges(changes: SimpleChanges) {
    if (changes['url']['currentValue'] && !changes['url'].isFirstChange()) {
      this._checkUrl();
    }
  }

  ngOnInit(): void {
    console.log('url', this.url);
    this._initSetCatAndStatus();
  }

  private _initSetCatAndStatus() {
    this._checkUrl();
  }

  private _checkUrl() {
    if (this.url == '/inventory') {

      setTimeout(()=>{
        let groupByListObj = JSON.parse(localStorage.getItem('groupByList'));
      this.platformArrItem = groupByListObj['platforms'].map((platformObj) => {
        return { key: platformObj['id'], value: platformObj['name'], 'selected': false }
      });
      this.assignCopy(this.filterList['platform']);


      this.statusArrItem = groupByListObj['validation_statuses'].map((validation_status) => {
        return { key: validation_status, value: validation_status, 'selected': false }
      });
      this.assignCopy(this.filterList['status']);


      this.vendorArrItem = groupByListObj['vendors'].map((vendor) => {
        return { key: vendor, value: vendor, 'selected': false }
      });
      this.assignCopy(this.filterList['vendor']);


      let triggerFileArr = JSON.parse(localStorage.getItem('invAppFilenameList'));
      this.triggerFileArrItem = triggerFileArr['filenames'].map((triggerFile) => {
        return { key: triggerFile, value: triggerFile, 'selected': false }
      });
      this.assignCopy(this.filterList['filename']);

      let applicationArr = JSON.parse(localStorage.getItem('invAppNameList'));
      this.applicationArrItem = applicationArr['names'].map((application) => {
        return { key: application, value: application, 'selected': false }
      });
      this.assignCopy(this.filterList['application_name']);

      let deviceArr = JSON.parse(localStorage.getItem('invAppDeviceList'));
      this.deviceArrItem = deviceArr.map((device) => {
        return { key: device['id'], value: device['name'], 'selected': false }
      });
      this.assignCopy(this.filterList['device']);
      },1000);
      
    }
  }

  assignCopy(params){
    switch(params){
      case this.filterList['platform']:
        this.platformArr = Object.assign([], this.platformArrItem);
      break;

      case this.filterList['application_name']:
        this.applicationArr = Object.assign([], this.applicationArrItem);
      break;

      case this.filterList['status']:
        this.statusArr = Object.assign([], this.statusArrItem);
      break;

      case this.filterList['filename']:
        this.triggerFileArr = Object.assign([], this.triggerFileArrItem);
      break;

      case this.filterList['vendor']:
        this.vendorArr = Object.assign([], this.vendorArrItem);
      break;

      case this.filterList['device']:
        this.deviceArr = Object.assign([], this.deviceArrItem);
      break;
    }
  }

  filterItem(value,filterType) {

    if (!value) {
      this.assignCopy(filterType);
    } // when nothing has typed

    switch(filterType){
      case this.filterList['platform']:
        this.platformArr = Object.assign([], this.platformArrItem).filter(
          item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
        );
      break;

      case this.filterList['application_name']:
        this.applicationArr = Object.assign([], this.triggerFileArrItem).filter(
          item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
        );
      break;

      case this.filterList['status']:
        this.statusArr = Object.assign([], this.statusArrItem).filter(
          item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
        );
      break;

      case this.filterList['filename']:
        this.triggerFileArr = Object.assign([], this.triggerFileArrItem).filter(
          item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
        );
      break;

      case this.filterList['vendor']:
        this.vendorArr = Object.assign([], this.vendorArrItem).filter(
          item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
        );
      break;

      case this.filterList['device']:
        this.deviceArr = Object.assign([], this.deviceArrItem).filter(
          item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
        );
      break;
    }
    
  }

  isOpen() {
    return this.isOpened;
  }
  showHide() {
    this.isOpened = !this.isOpened;
  }

  getValue(value) {
    return Object.values(value)[0];
  }

  getKeys(value) {
    return Object.keys(value)[0];
  }

  clearFilter(selectedFilterObj = undefined) {
    if (selectedFilterObj === undefined) {
      this.selectedFilterArr = [];
      this.detectDate = 0;
      this._initSetCatAndStatus();
      let nextData = {};
      nextData['url'] = 'inventory';
      this._inventoryService.filterSharingSubject.next(nextData);
    }
  }

  onSelectFilter(selectedFilterObj, category = undefined) {
    switch (category) {
      case 'PLATFORM':
        console.log(selectedFilterObj);
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_PLATFORM"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key'] // -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

        case 'APP_NAME':
          console.log(selectedFilterObj);
          this.selectedFilterArr.push({
            filterCatType: category,
            filterCatName: this.translate.instant("LBL_AZT_APPLICATION_NAME"),
            filterSubCatNam: selectedFilterObj['value'],
            filterSubCatId: selectedFilterObj['key'] // -1 means all
          });
          if (selectedFilterObj['selected']) {
            this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
          }
          break;

      case 'DETECT_DATE':
        this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_PERIOD"),
          filterSubCatNam: this.getDetectDate(selectedFilterObj),
          filterSubCatId: selectedFilterObj // -1 means all
        });
        break;

      case 'STATUS':
        console.log(selectedFilterObj);
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_STATUS"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key'] // -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

      case 'TRIGGER_FILE':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_FILENAME"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key']// -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

      case 'VENDOR':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_VENDOR"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key']// -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

      case 'DEVICE':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_DEVICE"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key']// -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;
    }
    console.log(selectedFilterObj);
  }

  applyFilter() {
    let paramsObj = {};
    this.selectedFilterArr.map((selectedFilter) => {
      switch (selectedFilter['filterCatType']) {
        case 'PLATFORM':
          if (paramsObj['platform']) {
            paramsObj['platform'] = paramsObj['platform'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let platformParams = { platform: selectedFilter['filterSubCatId'].toString() };
            paramsObj = { ...paramsObj, ...platformParams };
          }
          break;

          case 'APP_NAME':
            if (paramsObj['name']) {
              paramsObj['name'] = paramsObj['name'] + '|' + selectedFilter['filterSubCatId'];
            } else {
              let nameParams = { name: selectedFilter['filterSubCatId'] };
              paramsObj = { ...paramsObj, ...nameParams };
            }
            break;
        case 'DETECT_DATE':
          paramsObj = { ...paramsObj, ...this.getDetectDateParams(selectedFilter['filterSubCatId']) };
          break;
        case 'STATUS':
          if (paramsObj['status']) {
            paramsObj['status'] = paramsObj['status'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let statusParams = { status: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...statusParams };
          }

          break;

        case 'TRIGGER_FILE':
          if (paramsObj['trigger_file']) {
            paramsObj['trigger_file'] = paramsObj['trigger_file'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let triggerParams = { filename: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...triggerParams };
          }
          break;

        case 'VENDOR':
          if (paramsObj['vendor']) {
            paramsObj['vendor'] = paramsObj['vendor'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let vendorParams = { vendor: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...vendorParams };
          }
          break;

        case 'DEVICE':
          if (paramsObj['device']) {
            paramsObj['device'] = paramsObj['device'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let deviceParams = { device: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...deviceParams };
          }
          break;
      }
    })
    let nextData = {};
    // if (this.isAuditTrail) {
    //   delete paramsObj['STATUS'];
    //   delete paramsObj['NOTIFICATION_TYPE'];
    //   delete paramsObj['TRIGGER_FILE'];
      nextData['url'] = 'inventory';
    // }

    // if (this.isAlert) {
    //   delete paramsObj['EVENT_TYPE'];
    //   delete paramsObj['USERNAME'];
    //   nextData['url'] = 'alert';
    // }

    nextData['data'] = paramsObj;

    this._inventoryService.filterSharingSubject.next(nextData);
  }

  getDetectDate(days) {
    if (days == 1) {
      return this.translate.instant("LBL_AZT_LAST_24_HOUR");
    } else if (days == 7) {
      return this.translate.instant("LBL_AZT_LAST_7_DAYS");
    } else if (days == 30) {
      return this.translate.instant("LBL_AZT_LAST_30_DAYS");
    } else {
      return this.translate.instant("LBL_AZT_LAST_365_DAYS");
    }
  }

  getDetectDateParams(days) {
    let format = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    let previousDays = new Date();
    previousDays.setDate(new Date().getDate() - days);
    if (days == 1) {
      return { recorded__lte: this.datepipe.transform(new Date(), format), recorded__gte: this.datepipe.transform(previousDays, format) };
    } else if (days == 7) {
      return { recorded__lte: this.datepipe.transform(new Date(), format), recorded__gte: this.datepipe.transform(previousDays, format) };
    } else if (days == 30) {
      return { recorded__lte: this.datepipe.transform(new Date(), format), recorded__gte: this.datepipe.transform(previousDays, format) };
    } else {
      return { recorded__lte: this.datepipe.transform(new Date(), format), recorded__gte: this.datepipe.transform(previousDays, format) };
    }
  }



}
