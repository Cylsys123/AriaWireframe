import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RightFilterInvComponent } from './right-filter-inv.component';

describe('RightFilterInvComponent', () => {
  let component: RightFilterInvComponent;
  let fixture: ComponentFixture<RightFilterInvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RightFilterInvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RightFilterInvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
