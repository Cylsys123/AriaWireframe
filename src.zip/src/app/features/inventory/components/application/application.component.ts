import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { InvAppGroupBy } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { InventoryService } from '../../services/inventory.service';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements OnInit {

  defaultShowAppListGroupBy:number = 1;
  invApplicationArr: any = [];
  selectedgroupBy:string;
  groupByList:object = {
    all:['All']
  };
  selectedGroupByObj:object = {
    'key': Object.keys(this.groupByList)[0], 
    'value': Object.values(this.groupByList)[0]
  };

  noDataFound:boolean = true;

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'name';
  filterParams: object = {};

  constructor(
    private _route: ActivatedRoute,
    private _inventoryService: InventoryService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private translate: TranslateService,
  ) { }

  ngOnInit(): void {
    this._setPreData();
    this.onSelectGroupByValue(this.selectedGroupByObj);
    this._inventoryService.selectedGroupByObjGlobal = this.selectedGroupByObj;
    this._inventoryService.filterSharingSubject
      .subscribe((borrower) => {
        if (borrower['url'] == 'inventory') {
          (borrower['data']) ? this.filterParams = borrower['data']: this.filterParams={} ;
          console.log('borrower',borrower);
          let selectedGroupByObjGlobal = this._removeObjFromArrById();
          this._selectedGroup(selectedGroupByObjGlobal);
        }
      });
  }

  private _removeObjFromArrById(){
    
    let selectedGroupByObjGlobal = JSON.parse(JSON.stringify(this._inventoryService.selectedGroupByObjGlobal));
    let splitArr = [];
    if(this.filterParams.hasOwnProperty("platform") && selectedGroupByObjGlobal['key'] == InvAppGroupBy.PLATFORM){
      splitArr = this.filterParams['platform'].split('|');
      selectedGroupByObjGlobal['value'] = selectedGroupByObjGlobal['value'].filter((singleData)=>{
        if(splitArr.includes(singleData['id'].toString()))
             return true;
        else
             return false; 
      });
      delete this.filterParams['platform'];

    }else if(this.filterParams.hasOwnProperty("status") && selectedGroupByObjGlobal['key'] == InvAppGroupBy.VALIDATION_STATUS){
      splitArr = this.filterParams['status'].split('|');
      selectedGroupByObjGlobal['value'] = selectedGroupByObjGlobal['value'].filter((singleData)=>{
        if(splitArr.includes(singleData))
             return true;
        else
             return false; 
      });
      delete this.filterParams['status'];

    }else if(this.filterParams.hasOwnProperty("vendor") && selectedGroupByObjGlobal['key'] == InvAppGroupBy.VENDOR){
      splitArr = this.filterParams['vendor'].split('|');
      selectedGroupByObjGlobal['value'] = selectedGroupByObjGlobal['value'].filter((singleData)=>{
        if(splitArr.includes(singleData))
             return true;
        else
             return false; 
      });
      delete this.filterParams['vendor'];
    }
    return selectedGroupByObjGlobal;
  } 

  private _setPreData() {
    this.selectedgroupBy = 'all';
    this.groupByList = this._route.snapshot.data['inventory']['applicationGroups'];
    localStorage.setItem('groupByList', JSON.stringify(this.groupByList));
    localStorage.setItem('invAppFilenameList', JSON.stringify(this._route.snapshot.data['inventory']['applicationFilename']));
    localStorage.setItem('invAppNameList', JSON.stringify(this._route.snapshot.data['inventory']['applicationName']));
    localStorage.setItem('invAppDeviceList', JSON.stringify(this._route.snapshot.data['inventory']['applicationDevice']));
    this.invApplicationArr.push(
      {
        "name": this.translate.instant("LBL_AZT_APPLICATIONS"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: ''
            },
            {
              colKey: 'status',
              colKeyLabel: this.translate.instant('LBL_AZT_APP_TRUST_STATUS')
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_APP_NAME')
            },
            {
              colKey: 'platform_name',
              colKeyLabel: this.translate.instant('LBL_AZT_PLATFORM')
            },
            {
              colKey: 'vendor',
              colKeyLabel: this.translate.instant('LBL_AZT_VENDOR')
            },
            {
              colKey: 'version',
              colKeyLabel: this.translate.instant('LBL_AZT_APP_VERSION')
            },
            {
              colKey: 'filename',
              colKeyLabel: this.translate.instant('LBL_AZT_FILE_NAME')
            },
            {
              colKey: 'num_hosts_detected',
              colKeyLabel: this.translate.instant('LBL_AZT_HOST_DETECTED')
            },
            {
              colKey: 'num_device_groups_affected',
              colKeyLabel: this.translate.instant('LBL_AZT_DEVICE_GROUP_AFFECTED')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_ACTION')
            }
          ],
          "value": []
        }
      });
  }
  
  onSelectGroupByValue(objParams){
    this.filterParams = {};
    this._inventoryService.selectedGroupByObjGlobal = objParams;
    this._selectedGroup(objParams);
  }

  private _selectedGroup(objParams){
    this.selectedgroupBy = objParams['key'];
    this.invApplicationArr[0]['data']['value'] = [];
    if(this.selectedgroupBy == InvAppGroupBy.ALL) objParams = this.selectedGroupByObj;
    if(typeof objParams['value'] != undefined && objParams['value'].length > 0 ){
        this._setPreCallingEndpoint(objParams);
        this._callEndpoint();
    }else{
      this.noDataFound = true;
    }
  }

  private _setPreCallingEndpoint(objParams){
    this.noDataFound = false;
      for(let value of objParams['value']){
        switch(objParams['key']){
          case InvAppGroupBy.PLATFORM:
            this.invApplicationArr[0]['data']['value'].push({
              key:value['id'],
              label:value['name'],
              field:'platform',
              pagination:{
                totalRecords:0,
                globalPageNumber:1,
                isScrollDisable:false,
                sortParamKey:'name'
              },
              data:[]
            });
            break;
          case InvAppGroupBy.VENDOR:
            this.invApplicationArr[0]['data']['value'].push({
              key:value,
              label:value,
              field:'vendor',
              pagination:{
                totalRecords:0,
                globalPageNumber:1,
                isScrollDisable:false,
                sortParamKey:'name'
              },
              data:[]
            });
            break;
          case InvAppGroupBy.VALIDATION_STATUS:
            this.invApplicationArr[0]['data']['value'].push({
              key:value,
              label:value,
              field:'status',
              pagination:{
                totalRecords:0,
                globalPageNumber:1,
                isScrollDisable:false,
                sortParamKey:'name'
              },
              data:[]
            });
            break;

          case InvAppGroupBy.ALL:
            this.invApplicationArr[0]['data']['value'].push({
              key:value,
              label:value,
              field:'all',
              pagination:{
                totalRecords:0,
                globalPageNumber:1,
                isScrollDisable:false,
                sortParamKey:'name'
              },
              data:[]
            });
            break;
        }
      }
  }

  private _callEndpoint(){
    //set pagination config and call endpoint
    let applicationsGroupBy = this.invApplicationArr[0]['data']['value'];
    for(let applicationGroupBy of applicationsGroupBy){
      this.sortParamKey = applicationGroupBy['pagination']['sortParamKey'];
      this.globalPageNumber = applicationGroupBy['pagination']['globalPageNumber'];
      this.filterParams[applicationGroupBy['field']] = applicationGroupBy['key'];
      this._fetchDataAndPopulate([applicationGroupBy]);
    }
  }


  onScrollDown(invApplication) {
    console.log('scroll');
    this._fetchDataAndPopulate([invApplication]);
  }

  private _setPaginationConfig(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());
    let filterQueryParams = this.filterParams;
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    let sortQueryParams = {
      ordering: this.sortParamKey
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  private _fetchDataAndPopulate(applicationGroupBy) {
    this._ngxLoader.start();
    let appQueryParams = this._setPaginationConfig();
    this._inventoryService.getInventoryAppWithQueryApi(appQueryParams).subscribe(res => {
      this._ngxLoader.stop();
      console.log(res);
      if (res && res['count'] !== 0 && res['results'].length !== 0) {
          applicationGroupBy[0]['data'].push(...res['results']);
          applicationGroupBy[0]['pagination']['totalRecords'] = res['count'];
          if (applicationGroupBy[0]['pagination']['totalRecords'] === applicationGroupBy[0]['data'].length) {
            applicationGroupBy[0]['pagination']['isScrollDisable'] = true;
          }
          applicationGroupBy[0]['pagination']['globalPageNumber'] += 1;
          console.log('applicationGroupBy',applicationGroupBy);
          this._sharedService._replaceArrayObject(this.invApplicationArr[0]['data']['value'],applicationGroupBy);
         
      }else{
        if(applicationGroupBy[0]['data'].length == 0){
          //remove from invApplicationArr
          this.invApplicationArr[0]['data']['value'] = this._sharedService._removeObjectFromArray(this.invApplicationArr[0]['data']['value'],applicationGroupBy[0]);
          console.log(this.invApplicationArr[0]['data']['value']);
        }
      }
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
      }
    });
  }

  showSortArrow(queryParamKey: string | undefined,invApplication): boolean {
    return queryParamKey === invApplication['pagination']['sortParamKey'].replace('-', '') && invApplication['pagination']['sortParamKey'].includes('-');
  }

  sortTableCol(queryParamKey: string | undefined, invApplication) {
    if (queryParamKey === invApplication['pagination']['sortParamKey'].replace('-', '') && invApplication['pagination']['sortParamKey'].includes('-')) {
      this.sortParamKey = invApplication['pagination']['sortParamKey'] = queryParamKey;
    } else {
      this.sortParamKey = invApplication['pagination']['sortParamKey'] = '-' + queryParamKey;
    }
    if (invApplication['pagination']['isScrollDisable']) 
      invApplication['pagination']['isScrollDisable'] = false;

    this.globalPageNumber = invApplication['pagination']['globalPageNumber'] = 1;
    invApplication['pagination']['totalRecords'] = 0;
    
    invApplication['data'] = [];

    this._fetchDataAndPopulate([invApplication]);
  }

}
