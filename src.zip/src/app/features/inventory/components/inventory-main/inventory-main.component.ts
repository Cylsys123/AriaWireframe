import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-main',
  templateUrl: './inventory-main.component.html',
  styleUrls: ['./inventory-main.component.css']
})
export class InventoryMainComponent implements OnInit {

  inventoryUrl:string = location.pathname;
  constructor() { }

  ngOnInit(): void {
  }

  onOutletLoaded(event): void{
    // this.inventoryUrl = event._router.url;
  }

}
