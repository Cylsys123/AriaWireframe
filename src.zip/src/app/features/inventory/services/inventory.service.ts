import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  filterSharingSubject = new Subject();
  selectedGroupByObjGlobal:object;
  constructor(
    private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService,
  ) { }

  //dashboard/application/groups
  getInventoryAppGroupsWithQueryApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getInventoryAppGroupWithQueryParamsEndpoint(queryParamsObj));
  }

  //dashboard/application
  getInventoryAppWithQueryApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getInventoryAppWithQueryParamsEndpoint(queryParamsObj));
  }

  //dashboard/application/filenames
  getInventoryAppFilenameWithQueryApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getInventoryAppFilenameWithQueryParamsEndpoint(queryParamsObj));
  }

  //dashboard/application/names
  getInventoryAppNamesApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getInventoryAppNamesEndpoint());
  }

  //dashboard/application/devices
  getInventoryAppDevicesApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getInventoryAppDevicesEndpoint());
  }
}
