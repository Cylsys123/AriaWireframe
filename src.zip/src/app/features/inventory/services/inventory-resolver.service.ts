import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';
import { InventoryService } from './inventory.service';

@Injectable({
  providedIn: 'root'
})
export class InventoryResolverService {

  constructor(private _inventoryService: InventoryService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
    return forkJoin([
      this._inventoryService.getInventoryAppGroupsWithQueryApi({}),
      this._inventoryService.getInventoryAppFilenameWithQueryApi({}),
      this._inventoryService.getInventoryAppNamesApi(),
      this._inventoryService.getInventoryAppDevicesApi(),
    ])
    .pipe(
      map(result=>{
        return {
          applicationGroups: result[0],
          applicationFilename: result[1],
          applicationName: result[2],
          applicationDevice: result[3]
      };
      })
    )
  }
}
