import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './components/login/login.component';
import { AuthMainComponent } from './components/auth-main/auth-main.component';

import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ResetSecretQuestionComponent } from './components/reset-secret-question/reset-secret-question.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
@NgModule({
  declarations: [LoginComponent, AuthMainComponent, ResetSecretQuestionComponent, ChangePasswordComponent, ResetPasswordComponent],
  imports: [
    CommonModule,
    AuthRoutingModule,
    SharedLazyModule,
    ReactiveFormsModule,
    HttpClientModule
  ]
})
export class AuthModule { }
