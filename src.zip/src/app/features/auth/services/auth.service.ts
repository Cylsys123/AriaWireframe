import { Injectable, OnInit } from '@angular/core';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements OnInit {

  constructor(
    private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService
  ) { }

  ngOnInit() {
  }

  getCREFApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getCSRFEndpoint());
  }

  postLoginApi(loginBody: object) {
    return this._apiHttpService
      .post(this._apiEndpointsService.getLoginEndpoint(), loginBody);
  }

  getLogoutApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getLogoutEndpoint());
  }

  isAuthenticatedApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getSessionEndpoint());
  }

  getSecetQuestionApi(usename: string) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getSecretQuesByUsernameEndpoint(usename));
  }

  postChangePasswordApi(changePassBody: object) {
    return this._apiHttpService
      .post(this._apiEndpointsService.getChangePasswordEndpoint(), changePassBody);
  }

  getVersion() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getVersionEndpoint());
  }
}
