import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { LoggedInAuthGuard } from 'src/app/core/guards/logged-in-auth.guard';
import { AuthMainComponent } from './components/auth-main/auth-main.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { LoginComponent } from './components/login/login.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { ResetSecretQuestionComponent } from './components/reset-secret-question/reset-secret-question.component';

const routes: Routes = [
  {
    path: '', 
    component: AuthMainComponent,
    canActivate:[LoggedInAuthGuard],
    children:[
      {path:'login',component:LoginComponent},
      {path:'reset-password',component:ResetPasswordComponent},
      {path:'reset-secret-question/:username',component:ResetSecretQuestionComponent},
      {path:'change-password',component:ChangePasswordComponent},
      {path:'', redirectTo:'/login', pathMatch:'full'}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
