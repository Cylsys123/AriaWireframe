import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetSecretQuestionComponent } from './reset-secret-question.component';

describe('ResetSecretQuestionComponent', () => {
  let component: ResetSecretQuestionComponent;
  let fixture: ComponentFixture<ResetSecretQuestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResetSecretQuestionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetSecretQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
