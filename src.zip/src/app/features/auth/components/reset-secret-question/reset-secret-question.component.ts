import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-reset-secret-question',
  templateUrl: './reset-secret-question.component.html',
  styleUrls: ['./reset-secret-question.component.css']
})
export class ResetSecretQuestionComponent implements OnInit {

  resetSecretForm: FormGroup;
  username:string;
  questionLists:any = [];
  constructor(
    private _fb:FormBuilder, 
    private _authService: AuthService,
    private _router:Router,
    private _route: ActivatedRoute,
    private _ngxLoader: NgxUiLoaderService,
    private _sharedService: SharedService,
  ) { }

  ngOnInit(): void {
    //loader start
    this._ngxLoader.start();
    this.username = this._route.snapshot.paramMap.get('username');
    this._callSecretServices();
    this.createResetSecretForm();
  }

  createResetSecretForm(){
    this.resetSecretForm = this._fb.group({
      secretQuestion: ['', [Validators.required]],
      secretAnswer: ['', [Validators.required]],
   });
  }

  onSubmitResetSecretForm(){
    if(this.resetSecretForm.invalid){
      return;
    }

    //loader start
    this._ngxLoader.start();
    this._callValidateSecretQuestion();
  }

  private _callValidateSecretQuestion(){
    this._authService.getSecetQuestionApi(this.username).subscribe((res)=>{
      console.log(res);
      //loader start
      this._ngxLoader.stop();
      this._router.navigate(['/change-password']);

    },(err)=>{
      //loader stop
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('!!OOPS, Invalid Answer','AZT Secret Question','error');
    });
  }

  private _callSecretServices(){
    this._authService.getSecetQuestionApi(this.username).subscribe((res)=>{
      console.log(res);

      if(res['question'] !== undefined){
        this.questionLists.push(res);
        console.log(typeof this.questionLists);
      }else{
        this._sharedService.getToastPopup('!!OOPS, Question is not found. Please Contact to Admin','AZT Secret Question','error');
      }
      //loader start
      this._ngxLoader.stop();
    },(err)=>{
      //loader stop
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('!!OOPS, Internal Server Error','AZT Enpoint','error');
    });
  }

}
