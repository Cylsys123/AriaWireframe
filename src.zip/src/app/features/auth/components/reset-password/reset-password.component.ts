import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  resetForm: FormGroup;
  constructor(
    private _fb:FormBuilder, 
    private _router:Router,
    private _ngxLoader: NgxUiLoaderService
  ) { }

  
  ngOnInit(): void {

    this.createResetForm();
  }

  createResetForm(){
    this.resetForm = this._fb.group({
      username: ['', [Validators.required]],
   });
  }

  onSubmitResetForm(){
    if(this.resetForm.invalid){
      return;
    }

    //loader start
    this._ngxLoader.start();
    this._router.navigate(['/reset-secret-question',this.resetForm['controls']['username'].value]);
  }


}
