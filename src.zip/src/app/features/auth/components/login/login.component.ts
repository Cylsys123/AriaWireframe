import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { environment } from 'src/environments/environment';
import { Constants } from 'src/app/config/constant';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  constructor(
    private _fb:FormBuilder, 
    private _authService: AuthService,
    private _router:Router, 
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private _constants: Constants
    ) { 
  }

  ngOnInit(): void {
    this.createLoginForm();    
    if(this._sharedService.isUserLoggedIn){
      sessionStorage.setItem('isAuthenticated','true');
      this._router.navigateByUrl('/dashboard');
    }
  }

  

  createLoginForm(){
    this.loginForm = this._fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
   });
  }

  onSubmitLoginForm(){
    if(this.loginForm.invalid){
      this._sharedService.getToastPopup('Invalid username or password','AZT Login','error');return;
    }

    //loader start
    this._ngxLoader.start();
    this._constants.API_IS_DEVELOPMENT_ENV ? this._getLoginApi() :this._getCSRFApi();
    
  }

  private _getCSRFApi(){    
    this._authService.getCREFApi().subscribe((res)=>{
      
      this._getLoginApi();
    },(err)=>{
      this._ngxLoader.stop();
     
      this._sharedService.getToastPopup('csrf token error','AZT Login','error');
    });
  }

  private _getLoginApi(){
    this._authService.postLoginApi(this.loginForm.value).subscribe((res)=>{
      sessionStorage.setItem('userInfo',JSON.stringify(res));
      this._getIsAuthenticated();
    },(err)=>{
      //loader stop
      this._sharedService.isUserLoggedIn = true;
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Invalid username or password','AZT Login','error');
    });
  }

  private _getIsAuthenticated(){
    this._authService.isAuthenticatedApi().subscribe((res)=>{
      //loader stop
      this._ngxLoader.stop();
      if(res){
        sessionStorage.setItem('isAuthenticated',res['isAuthenticated']);
        this._router.navigateByUrl('/dashboard');
      }else{
        this._sharedService.getToastPopup('!!OOPS, Internal Server Error','AZT Enpoint','error');
      }
    },(err)=>{
      //loader stop
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('!!OOPS, Internal Server Error','AZT Enpoint','error');
    });
  }



}
