import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  changePassForm: FormGroup;
  constructor(
    private _fb:FormBuilder, 
    private _authService: AuthService,
    private _router: Router,
    private _ngxLoader: NgxUiLoaderService,
    private _sharedService: SharedService
  ) { }

  ngOnInit(): void {
    this.createResetSecretForm();
  }

  createResetSecretForm(){
    this.changePassForm = this._fb.group({
      changePassword: ['', [Validators.required]],
      confChangePassword: ['', [Validators.required]],
   });
  }

  onSubmitChangePassForm(){
    if(this.changePassForm.invalid){
      return;
    }

    if(this.changePassForm['controls']['changePassword'].value == this.changePassForm['controls']['confChangePassword'].value){
      this._sharedService.getToastPopup('!!OOPS, Password and Conf Password is not matching, try again','AZT Enpoint','error'); return;
    }

    this._ngxLoader.start();
    this._callChangePasswordSer();
  }

  private _callChangePasswordSer(){
    let data = {
      'new_password':this.changePassForm['controls']['changePassword'].value
    }
    this._authService.postChangePasswordApi(data).subscribe((res)=>{
      console.log(res);
      //loader start
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Successfully, Change Password','AZT Change Password','success');
      this._router.navigate(['/login']);
    },(err)=>{
      //loader stop
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('!!OOPS, Internal Server Error','AZT Enpoint','error');
    });
  }

}
