import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';
import { NetworkSetupType } from 'src/app/shared/enum/shared.enum';
import { IPostInstallWizardForms } from '../models/ipost-install-wizard-forms';

@Injectable({
  providedIn: 'root'
})
export class PostInstallWizardService {

  postInstallFormValues:IPostInstallWizardForms;

  constructor(
    private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService,
    private translate: TranslateService
  ) { 
    this._setDefaultValuePostInstallWizardForm();
  }

  private _setDefaultValuePostInstallWizardForm(){
    this.postInstallFormValues = {
      networkSetupFormValue:{
        networkType:NetworkSetupType.AIRGAPPED
      },
      hostServerFormValue:{
        fullyQualifiedHostName:'',
        hostIPAddress:'',
        subnetMask:'',
        gatewayIP:'',
        destinationIP:'',
        proxyUrl:'',
        proxyServerUsername:'',
        proxyServerPassword:''
      },
      adminAccountFormValue:{
        adminUsername:'',
        adminEmail:'',
        adminPassword:'',
        adminConfPassword:'',
      },
      siteProfileFormValue:{
        siteDetails:{
          siteName:'',
          siteSummary:'',
          siteAlias:'',
          siteCategory:'',
          siteAutoUpdate:true,
          siteAutoUpdateUrl:''
        },
        siteAddress:{
          addrLine1:'',
          addrLine2:'',
          addrLine3:'',
          country:'',
          postalCode:''
        },
        siteContact:{
          name:'',
          phone:'',
          email:''
        }
      },
      ntpDnsMailFormValue:{
        networkTime:{
          networkTimeServer:''
        },
        dnsServer:{
          dnsServer1:'',
          dnsServer2:'',
          dnsServer3:''
        },
        mailServer:{
          mailServerIP:'',
          isMailServerRequireAuth:true,
          mailServerUsername:'',
          mailServerPassword:'',
          useSecureEmailServer:true
        }
      }
    }
  }

  preInfoMessage(){
    return {
      hostServer:{
        fullyQualifiedHostName: this.translate.instant('LBL_AZT_FQDN_TEXT'),
        hostIPAddress: this.translate.instant('LBL_AZT_SELECT_AD_DOMAIN_TEXT'),
        subnetMask: this.translate.instant('LBL_AZT_SELECT_AD_DOMAIN_TEXT'),
        gatewayIP: this.translate.instant('LBL_AZT_SELECT_AD_DOMAIN_TEXT'),
        destinationIP: this.translate.instant('LBL_AZT_DESTINATION_IP_TEXT'),
        proxyUrl: this.translate.instant('LBL_AZT_URL_OF_PROXY_SERVER'),
        proxyServerUsername: this.translate.instant('LBL_AZT_USER_TO_ACCESS_PROXY'),
        proxyServerPassword:  this.translate.instant('LBL_AZT_USER_PASSWORD_ACCESS_PROXY'),
      },
      adminAccount:{
        adminUsername: this.translate.instant('LBL_AZT_ADMINISTRATOR_TEXT'),
        adminEmail: this.translate.instant('LBL_AZT_ADMINISTRATOR_EMAIL_TEXT'),
        adminPassword: this.translate.instant('LBL_AZT_ADMINISTRATOR_PASSWORD_TEXT'),
        adminConfPassword: this.translate.instant('LBL_AZT_ADMINISTRATOR_PASSWORD_TEXT'),
      }
    }
  }

  //dashboard/network/
  postNetworkApi(networkBody:object){
    return this._apiHttpService
      .post(this._apiEndpointsService.getNetworkEndpoint(),networkBody);
  }

  //dashboard/network/
  getNetworkApi(){
    return this._apiHttpService
      .get(this._apiEndpointsService.getNetworkEndpoint());
  }

  //dashboard/proxy
  postProxyApi(proxyBody:object){
    return this._apiHttpService
      .post(this._apiEndpointsService.getProxyEndpoint(),proxyBody);
  }

  //dashboard/proxy
  getProxyApi(){
    return this._apiHttpService
      .get(this._apiEndpointsService.getProxyEndpoint());
  }

  //dashboard/admin_user_creation/
  postAdminAccountApi(adminBody:object){
    return this._apiHttpService
      .post(this._apiEndpointsService.getAdminUserEndpoint(),adminBody);
  }

  //dashboard/site_notes/
  postSiteProfileApi(siteBody:object){
    return this._apiHttpService
      .post(this._apiEndpointsService.getSiteNotesEndpoint(),siteBody);
  }

  //dashboard/sendmail/
  postMailServerApi(mailBody:object){
    return this._apiHttpService
      .post(this._apiEndpointsService.getSendMailEndpoint(),mailBody);
  }
  

}
