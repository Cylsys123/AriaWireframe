import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { NetworkSetupType } from 'src/app/shared/enum/shared.enum';
import { PostInstallWizardService } from '../../services/post-install-wizard.service';

@Component({
  selector: 'app-network-setup',
  templateUrl: './network-setup.component.html',
  styleUrls: ['./network-setup.component.css']
})
export class NetworkSetupComponent implements OnInit {
  
  networkSetupForm:FormGroup;
  networkTypeGenerator:object[];
  
  constructor(
    private _router: Router,
    private _fb:FormBuilder,
    private _postInstalllWizardServ: PostInstallWizardService,
  ) { }

  ngOnInit(): void {
    this.createNetworkType();
    this.createNetworkForm();
    this.onLoadUpdateNetworkSetupFormValue();
  }

  createNetworkForm(){
    this.networkSetupForm = this._fb.group({
      'networkType':[NetworkSetupType.AIRGAPPED,Validators.required]
    });
  }

  createNetworkType(){
    this.networkTypeGenerator = [{
      id:"airgapped",
      value:NetworkSetupType.AIRGAPPED,
      title:'Airgapped',
      summary:'Select this option if you will be running AZT in a setup that is completely isolated from online connectivity',
      img:'assets/img/airgapped.svg',
      formCName:'networkType'
    },
    {
      id:"directOnline",
      value:NetworkSetupType.DIRECT_ONLINE,
      title:'Direct/Online',
      summary:'Select this option if you are setting up AZT protection on a completely isolated network setup .',
      img:'assets/img/direct_online.svg',
      formCName:'networkType'
    },
    {
      id:"proxyEnabled",
      value:NetworkSetupType.PROXY_ENABLED,
      title:'Proxy Enabled',
      summary:'Select this option if you will be deploying AZT in a network environment that can connect to the internet via a proxy.',
      img:'assets/img/proxy_enabled.svg',
      formCName:'networkType'
    },]
  }

  submitNetworkSetupTypeForm() {
    this._router.navigate(['/post-install-wizard/host-server',this.networkSetupForm.value['networkType']]);
  }

  handleChange(networkSetupType:string){
    this._postInstalllWizardServ.postInstallFormValues['networkSetupFormValue']['networkType']= networkSetupType;
  }

  onLoadUpdateNetworkSetupFormValue(){
    this.networkSetupForm.patchValue(this._postInstalllWizardServ.postInstallFormValues['networkSetupFormValue']);
  }

}
