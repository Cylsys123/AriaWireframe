import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HostServerComponent } from './host-server.component';

describe('HostServerComponent', () => {
  let component: HostServerComponent;
  let fixture: ComponentFixture<HostServerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HostServerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HostServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
