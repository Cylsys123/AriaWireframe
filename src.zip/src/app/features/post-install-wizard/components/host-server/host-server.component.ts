import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { hostValidator,IPValidator, proxyURLValidator,nameValidator,stringValidator} from 'src/app/shared/classes/validator';
import { NetworkSetupType } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { PostInstallWizardService } from '../../services/post-install-wizard.service';

@Component({
  selector: 'app-host-server',
  templateUrl: './host-server.component.html',
  styleUrls: ['./host-server.component.css']
})
export class HostServerComponent implements OnInit {

  isProxyInputVisible: boolean = false;
  hostServerForm:FormGroup;
  networkType:string=NetworkSetupType.AIRGAPPED;
  inputInfoMessage:object;


  constructor(
    private _route: ActivatedRoute,
    private _router: Router,
    private _fb: FormBuilder,
    private _postInstalllWizardServ: PostInstallWizardService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService
    ) { }

  ngOnInit(): void {
    this.networkType = this._route.snapshot.paramMap.get('networkType');
    this.inputInfoMessage = this._postInstalllWizardServ.preInfoMessage()['hostServer'];
    this.createHostServerForm();
    this._setInputFormBasedOnNetworkType(this.networkType);
    this._onLoadUpdateHostServerFormValue();
  }

  createHostServerForm(){
    this.hostServerForm = this._fb.group({
      'fullyQualifiedHostName':['',{
        validators: [hostValidator('Host Name',true)],
        updateOn: 'change',
      }],
      'hostIPAddress':['',{
        validators: [IPValidator('Host IP Address',true)],
        updateOn: 'change',
      }],
      'subnetMask':['',{
        validators: [IPValidator('Subnet Mask',true)],
        updateOn: 'change',
      }],
      'gatewayIP':['',{
        validators: [IPValidator('Gateway IP',true)],
        updateOn: 'change',
      }],
      'destinationIP':['',{
        validators: [IPValidator('Destination IP')],
        updateOn: 'change',
      }]
    });

  }

  private _setInputFormBasedOnNetworkType(networkType:string){
    switch(networkType){
      case NetworkSetupType.AIRGAPPED:
        this.isProxyInputVisible = true;
        this.hostServerForm.addControl('proxyUrl',new FormControl('',{
          validators: [proxyURLValidator('Proxy Url',true)],
          updateOn: 'change',
        }));
        this.hostServerForm.addControl('proxyServerUsername',new FormControl('',{
          validators: [nameValidator('Proxy Server Username',8,20)],
          updateOn: 'change',
        }));
        this.hostServerForm.addControl('proxyServerPassword',new FormControl('',{
          validators: [stringValidator('Admin Password',8,20)],
          updateOn: 'change',
        }));
        break;
      case NetworkSetupType.DIRECT_ONLINE:
        this.isProxyInputVisible = false;
        break;
      case NetworkSetupType.PROXY_ENABLED:
        this.isProxyInputVisible = true;
        this.hostServerForm.addControl('proxyUrl',new FormControl('',{
          validators: [proxyURLValidator('Proxy Url')],
          updateOn: 'change',
        }));
        this.hostServerForm.addControl('proxyServerUsername',new FormControl(''));
        this.hostServerForm.addControl('proxyServerPassword',new FormControl(''));
        break;
    }

  }

  submitHostServerForm(){
    // check validation
    if(this.hostServerForm.invalid){
      return;
    }
    this._ngxLoader.start();
    //update service form
    this._updateHostServerFormValueInSer();
    //call api;
    this._hostNetworkEndPoint();
  }

  private _updateHostServerFormValueInSer(){
    this._postInstalllWizardServ.postInstallFormValues['hostServerFormValue']= {
        fullyQualifiedHostName:this.hostServerForm['controls']['fullyQualifiedHostName'].value,
        hostIPAddress:this.hostServerForm['controls']['hostIPAddress'].value,
        subnetMask:this.hostServerForm['controls']['subnetMask'].value,
        gatewayIP:this.hostServerForm['controls']['gatewayIP'].value,
        destinationIP:this.hostServerForm['controls']['destinationIP'].value,
        proxyUrl:this.hostServerForm['controls']['proxyUrl']?.value !== undefined ?this.hostServerForm['controls']['proxyUrl'].value:'',
        proxyServerUsername:this.hostServerForm['controls']['proxyServerUsername']?.value !== undefined ?this.hostServerForm['controls']['proxyServerUsername'].value:'',
        proxyServerPassword:this.hostServerForm['controls']['proxyServerPassword']?.value !== undefined ?this.hostServerForm['controls']['proxyServerPassword'].value:'',
    };
  }

  private _onLoadUpdateHostServerFormValue(){
    this._updateHostServerFormValueInSer();
    this.hostServerForm.patchValue(this._postInstalllWizardServ.postInstallFormValues['hostServerFormValue']);
  }

  get getHostServerForm(): any {
    return this.hostServerForm['controls'];
  }

  //update value in service is still pending
  private _hostNetworkEndPoint(){
    let networkBody = {
      'hostName':this.hostServerForm['controls']['fullyQualifiedHostName'].value,
      'static_ip':this.hostServerForm['controls']['hostIPAddress'].value,
      'netmask':this.hostServerForm['controls']['subnetMask'].value,
      'gateway_ip':this.hostServerForm['controls']['gatewayIP'].value,
      'destination_ip':this.hostServerForm['controls']['destinationIP'].value,
      'dnsServer1':'',
      'dnsServer2':'',
      'dnsServer3':'',
      'ntp':'',
      'airgapped':false,
      'noop':false
    };
    this._postInstalllWizardServ.postNetworkApi(networkBody).subscribe((res)=>{
      console.log(res);
      if(this.networkType == NetworkSetupType.AIRGAPPED || this.networkType == NetworkSetupType.PROXY_ENABLED ){
        this._proxyEndPoint();
      }else{
        this._ngxLoader.stop();
      }
    },
    (err)=>{
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Network Host','error');
    })
  }


  private _proxyEndPoint(){
    let proxyBody = {
      'proxyUrl':this.hostServerForm['controls']['proxyUrl'].value,
      'proxyUser':this.hostServerForm['controls']['proxyServerUsername'].value,
      'proxyPassword':this.hostServerForm['controls']['proxyServerPassword'].value
    };
    this._postInstalllWizardServ.postProxyApi(proxyBody).subscribe((res)=>{
      console.log(res);
      this._ngxLoader.stop();
      this._router.navigate(['/post-install-wizard/admin-account']);
    },
    (err)=>{
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Proxy','error');
    })
  }

}
