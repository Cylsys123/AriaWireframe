import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NtpDnsComponent } from './ntp-dns.component';

describe('NtpDnsComponent', () => {
  let component: NtpDnsComponent;
  let fixture: ComponentFixture<NtpDnsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NtpDnsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NtpDnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
