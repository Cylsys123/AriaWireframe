import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { IPValidator, stringValidator } from 'src/app/shared/classes/validator';
import { SharedService } from 'src/app/shared/services/shared.service';
import { PostInstallWizardService } from '../../services/post-install-wizard.service';

@Component({
  selector: 'app-ntp-dns',
  templateUrl: './ntp-dns.component.html',
  styleUrls: ['./ntp-dns.component.css']
})
export class NtpDnsComponent implements OnInit {

  ntpDnsMailDetailForm:FormGroup;
  constructor(
    private _router: Router,
    private _fb: FormBuilder,
    private _postInstalllWizardServ: PostInstallWizardService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService
  ) { }

  ngOnInit(): void {
    this.createNtpDnsMailDetailForm();
    this._onLoadUpdateNtpDnsMailDetailFormValue();
  }

  createNtpDnsMailDetailForm(){
    this.ntpDnsMailDetailForm = this._fb.group({
      'networkTime':this._fb.group({
        'networkTimeServer':['',{
          validators: [stringValidator('Network Time Server',8,20)],
          updateOn: 'change',
        }],
      }),
      'dnsServer':this._fb.group({
        'dnsServer1':['',{
          validators: [IPValidator('DNS Server 1')],
          updateOn: 'change',
        }],
        'dnsServer2':['',{
          validators: [IPValidator('DNS Server 2')],
          updateOn: 'change',
        }],
        'dnsServer3':['',{
          validators: [IPValidator('DNS Server 3')],
          updateOn: 'change',
        }]
      }),
      'mailServer':this._fb.group({
        'mailServerIP':['',{
          validators: [IPValidator('Mail Server IP')],
          updateOn: 'change',
        }],
        'isMailServerRequireAuth':[true],
        'mailServerUsername':['',{
          validators: [stringValidator('Mail Server Username',8,20)],
          updateOn: 'change',
        }],
        'mailServerPassword':['',{
          validators: [stringValidator('Mail Server Password',8,20)],
          updateOn: 'change',
        }],
        'useSecureEmailServer':[true]
      }),
    });
  }

  private _onLoadUpdateNtpDnsMailDetailFormValue(){
    this._updateNtpDnsMailDetailFormInSer();
    this.ntpDnsMailDetailForm.patchValue(this._postInstalllWizardServ.postInstallFormValues['ntpDnsMailFormValue']);
  }

  private _updateNtpDnsMailDetailFormInSer(){
    this._postInstalllWizardServ.postInstallFormValues['ntpDnsMailFormValue']= {
      networkTime:{
        networkTimeServer:this.ntpDnsMailDetailForm['controls']['networkTime']['controls']['networkTimeServer'].value
      },
      dnsServer:{
        dnsServer1:this.ntpDnsMailDetailForm['controls']['dnsServer']['controls']['dnsServer1'].value,
        dnsServer2:this.ntpDnsMailDetailForm['controls']['dnsServer']['controls']['dnsServer2'].value,
        dnsServer3:this.ntpDnsMailDetailForm['controls']['dnsServer']['controls']['dnsServer3'].value
      },
      mailServer:{
        mailServerIP:this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerIP'].value,
        isMailServerRequireAuth:this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['isMailServerRequireAuth'].value,
        mailServerUsername:this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerUsername'].value,
        mailServerPassword:this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerPassword'].value,
        useSecureEmailServer:this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['useSecureEmailServer'].value
      }
    }
  }

  submitNtpDnsMailDetailForm(){
    // check validation
    if(this.ntpDnsMailDetailForm.invalid){
      return;
    }
    //loader start
    this._ngxLoader.start();
    //update service form
    this._updateNtpDnsMailDetailFormInSer();
    //call api;
    this._networkEndPoint();
  }

  get getNtpDnsMailDetailForm(): any {
    return this.ntpDnsMailDetailForm['controls'];
  }

  onClickMailServerRequireAuth(event){
    if(event.target.checked){
      this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerUsername'].enable();
      this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerPassword'].enable();
    }else{
      this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerUsername'].disable();
      this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerPassword'].disable();
    }
  }

  private _networkEndPoint(){
    this._postInstalllWizardServ.getNetworkApi().subscribe((res)=>{
      console.log(res);
      this._ntpDnsEndPoint(res);
    },
    (err)=>{
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Network Host','error');
    })
  }

  private _ntpDnsEndPoint(networkHostData){
    let siteBody = {
      'hostName':networkHostData['hostName'],
      'static_ip':networkHostData['static_ip'],
      'netmask':networkHostData['netmask'],
      'gateway_ip':networkHostData['gateway_ip'],
      'destination_ip':networkHostData['destination_ip'],
      'dnsServer1':this.ntpDnsMailDetailForm['controls']['dnsServer']['controls']['dnsServer1'].value,
      'dnsServer2':this.ntpDnsMailDetailForm['controls']['dnsServer']['controls']['dnsServer2'].value,
      'dnsServer3':this.ntpDnsMailDetailForm['controls']['dnsServer']['controls']['dnsServer3'].value,
      'ntp':this.ntpDnsMailDetailForm['controls']['networkTime']['controls']['networkTimeServer'].value
    };
    this._postInstalllWizardServ.postNetworkApi(siteBody).subscribe((res)=>{
      console.log(res);
      this._sendMailEndPoint();
    },
    (err)=>{
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Network Host','error');
    })
  }

  private _sendMailEndPoint(){
    let mailBody = {
      'server_port':this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerIP'].value,
      'authuser':this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerUsername'].value,
      'authpassword':this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['mailServerUsername'].value,
      'tls':this.ntpDnsMailDetailForm['controls']['mailServer']['controls']['useSecureEmailServer'].value,
    };
    this._postInstalllWizardServ.postMailServerApi(mailBody).subscribe((res)=>{
      console.log(res);
      this._ngxLoader.stop();
      this._router.navigate(['/post-install-wizard-success']);
    },
    (err)=>{
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Send Mail','error');
    })
  }

}
