import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginProgressComponent } from './login-progress.component';

describe('LoginProgressComponent', () => {
  let component: LoginProgressComponent;
  let fixture: ComponentFixture<LoginProgressComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginProgressComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
