import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-progress',
  templateUrl: './login-progress.component.html',
  styleUrls: ['./login-progress.component.css']
})
export class LoginProgressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
