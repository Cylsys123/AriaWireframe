import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { confPasswordValidator, emailValidator, nameValidator,stringValidator } from 'src/app/shared/classes/validator';
import { SharedService } from 'src/app/shared/services/shared.service';
import { PostInstallWizardService } from '../../services/post-install-wizard.service';

@Component({
  selector: 'app-admin-account',
  templateUrl: './admin-account.component.html',
  styleUrls: ['./admin-account.component.css']
})
export class AdminAccountComponent implements OnInit {

  adminAccountForm:FormGroup;
  networkType:string;
  inputInfoMessage:object;

  constructor(
    private _router: Router,
    private _fb: FormBuilder,
    private _postInstalllWizardServ: PostInstallWizardService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService
  ) { }

  ngOnInit(): void {
    this.networkType = this._postInstalllWizardServ.postInstallFormValues.networkSetupFormValue['networkType'];
    this.inputInfoMessage = this._postInstalllWizardServ.preInfoMessage()['adminAccount'];
    this.createHostServerForm();
    this._onLoadUpdateAdminAccountFormValue();
  }

  createHostServerForm(){
    this.adminAccountForm = this._fb.group({
      'adminUsername':['',{
        validators: [nameValidator('Admin Username',5,20)],
        updateOn: 'change',
      }],
      'adminEmail':['',{
        validators: [emailValidator('Admin Email')],
        updateOn: 'change',
      }],
      'adminPassword':['',{
        validators: [stringValidator('Admin Password',8,20)],
        updateOn: 'change',
      }],
      'adminConfPassword':['',{
        validators: [stringValidator('Admin Password',8,20)],
        updateOn: 'change',
      }]
    // },confPasswordValidator('Admin Confirm Password','adminPassword','adminConfPassword'));
  });
  }

  private _onLoadUpdateAdminAccountFormValue(){
    this._updateAdminAccountFormInSer();
    this.adminAccountForm.patchValue(this._postInstalllWizardServ.postInstallFormValues['adminAccountFormValue']);
  }

  private _updateAdminAccountFormInSer(){
    this._postInstalllWizardServ.postInstallFormValues['adminAccountFormValue']= {
      adminUsername:this.adminAccountForm['controls']['adminUsername'].value,
      adminEmail:this.adminAccountForm['controls']['adminEmail'].value,
      adminPassword:this.adminAccountForm['controls']['adminPassword'].value,
      adminConfPassword:this.adminAccountForm['controls']['adminConfPassword'].value,
    }
  }

  submitAdminAccountForm(){
    if(this.adminAccountForm.invalid){
      return;
    }

    //loader start
    this._ngxLoader.start();
    //update service form
    this._updateAdminAccountFormInSer();
    //call api
    this._adminAccountEndPoint();
  }

  get getAdminAccountForm(): any {
    return this.adminAccountForm['controls'];
  }

  //update value in service is still pending
  private _adminAccountEndPoint(){
    let adminBody = {
      'adminUser':this.adminAccountForm['controls']['adminUsername'].value,
      'adminPassword':this.adminAccountForm['controls']['adminPassword'].value,
      'adminEmail':this.adminAccountForm['controls']['adminEmail'].value
    };
    this._postInstalllWizardServ.postAdminAccountApi(adminBody).subscribe((res)=>{
      console.log(res);
      this._ngxLoader.stop();
      this._router.navigate(['/post-install-wizard/site-profile']);
    },
    (err)=>{
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Admin Account','error');
    })
  }

}
