import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wizard-main',
  templateUrl: './wizard-main.component.html',
  styleUrls: ['./wizard-main.component.css']
})
export class WizardMainComponent implements OnInit {

  title: string = '';
  postInstallWizardForm : FormGroup;
  constructor(
    private _router: Router,
    private _fb:FormBuilder
    ) {
      window.addEventListener('beforeunload', (event) => {
        event.returnValue = 'There are unsaved changes which will be lost - do you still want to proceed with the refresh?';
      });
    }

  ngOnInit(): void {
  }
  
  setHeader() {
    let path = this._router.url.split('/')[1];
    this.title = decodeURIComponent(path);
  }
}
