import { Component, Input, OnChanges, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-error-display',
  templateUrl: './common-error-display.component.html',
  styleUrls: ['./common-error-display.component.css']
})

export class CommonErrorDisplayComponent implements OnInit {
  
  @Input('control') control: any;
  @Input('infoMessage') infoMessage:any;
  constructor() {}
  
  ngOnInit() {
  }
}
