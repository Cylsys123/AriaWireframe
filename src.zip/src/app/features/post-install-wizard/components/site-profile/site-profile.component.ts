import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { emailValidator, nameValidator, stringValidator } from 'src/app/shared/classes/validator';
import { countryListAllIsoData } from 'src/app/shared/models/country-list';
import { SharedService } from 'src/app/shared/services/shared.service';
import { PostInstallWizardService } from '../../services/post-install-wizard.service';

@Component({
  selector: 'app-site-profile',
  templateUrl: './site-profile.component.html',
  styleUrls: ['./site-profile.component.css']
})
export class SiteProfileComponent implements OnInit {

  siteProfileForm:FormGroup;
  countryList = countryListAllIsoData;
  constructor(
    private _router: Router,
    private _fb: FormBuilder,
    private _postInstalllWizardServ: PostInstallWizardService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private translate: TranslateService
  ) { }

  ngOnInit(): void {
    this.createSiteProfileForm();
    this._onLoadUpdateNtpDnsMailDetailFormValue();
  }

  createSiteProfileForm(){
    this.siteProfileForm = this._fb.group({
      'siteDetails':this._fb.group({
        'siteName':[this.translate.instant('LBL_AZT_SITE_PROFILE_NAME'),{
          validators: [stringValidator('Site Name',5,50)],
          updateOn: 'change',
        }],
        'siteSummary':[this.translate.instant('LBL_AZT_DUMMY_TEXT'),{
          validators: [stringValidator('Site Summary',5,300)],
          updateOn: 'change',
        }],
        'siteAlias':['',{
          validators: [stringValidator('Site Alias',5,50)],
          updateOn: 'change',
        }],
        'siteCategory':['',{
          validators: [stringValidator('Site Category',5,50)],
          updateOn: 'change',
        }],
        'siteAutoUpdate':[true],
        'siteAutoUpdateUrl':['',{
          validators: [stringValidator('Site Auto Update Url',5,50)],
          updateOn: 'change',
        }],
      }),
      'siteAddress':this._fb.group({
        'addrLine1':['',{
          validators: [stringValidator('Address Line one',5,50)],
          updateOn: 'change',
        }],
        'addrLine2':['',{
          validators: [stringValidator('Address Line two',0,50)],
          updateOn: 'change',
        }],
        'addrLine3':['',{
          validators: [stringValidator('Address Line three',0,50)],
          updateOn: 'change',
        }],
        'country':['USA'],
        'postalCode':['99950',{
          validators: [stringValidator('Postal Code',4,50)],
          updateOn: 'change',
        }]
      }),
      'siteContact':this._fb.group({
        'name':['',{
          validators: [nameValidator('Site Contanct Name',4,50)],
          updateOn: 'change',
        }],
        'phone':['',{
          validators: [nameValidator('Phone',4,15)],
          updateOn: 'change',
        }],
        'email':['',{
          validators: [emailValidator('Email')],
          updateOn: 'change',
        }]
      })
    });
  }

  private _onLoadUpdateNtpDnsMailDetailFormValue(){
    this._updateNtpDnsMailDetailFormInSer();
    this.siteProfileForm.patchValue(this._postInstalllWizardServ.postInstallFormValues['siteProfileFormValue']);
  }

  private _updateNtpDnsMailDetailFormInSer(){
    this._postInstalllWizardServ.postInstallFormValues['siteProfileFormValue']= {
      siteDetails:{
        siteName:this.siteProfileForm['controls']['siteDetails']['controls']['siteName'].value,
        siteSummary:this.siteProfileForm['controls']['siteDetails']['controls']['siteSummary'].value,
        siteAlias:this.siteProfileForm['controls']['siteDetails']['controls']['siteAlias'].value,
        siteCategory:this.siteProfileForm['controls']['siteDetails']['controls']['siteCategory'].value,
        siteAutoUpdate:this.siteProfileForm['controls']['siteDetails']['controls']['siteAutoUpdate'].value,
        siteAutoUpdateUrl:this.siteProfileForm['controls']['siteDetails']['controls']['siteAutoUpdateUrl'].value
      },
      siteAddress:{
        addrLine1:this.siteProfileForm['controls']['siteAddress']['controls']['addrLine1'].value,
        addrLine2:this.siteProfileForm['controls']['siteAddress']['controls']['addrLine2'].value,
        addrLine3:this.siteProfileForm['controls']['siteAddress']['controls']['addrLine3'].value,
        country:this.siteProfileForm['controls']['siteAddress']['controls']['country'].value,
        postalCode:this.siteProfileForm['controls']['siteAddress']['controls']['postalCode'].value,
      },
      siteContact:{
        name:this.siteProfileForm['controls']['siteContact']['controls']['name'].value,
        phone:this.siteProfileForm['controls']['siteContact']['controls']['phone'].value,
        email:this.siteProfileForm['controls']['siteContact']['controls']['email'].value,
      }
    }
  }

  submitSiteProfileForm(){
    if(this.siteProfileForm.invalid){
      return;
    }

     //loader start
     this._ngxLoader.start();
     //update service form
     this._updateNtpDnsMailDetailFormInSer();
     //call api;
    this._siteProfileEndPoint();
  }

  get getSiteProfileForm(): any {
    return this.siteProfileForm['controls'];
  }

  private _siteProfileEndPoint(){
    let siteBody = {
      'siteName':this.siteProfileForm['controls']['siteDetails']['controls']['siteName'].value,
      'siteSummary':this.siteProfileForm['controls']['siteDetails']['controls']['siteSummary'].value,
      'siteAlias':this.siteProfileForm['controls']['siteDetails']['controls']['siteAlias'].value,
      'siteCategory':this.siteProfileForm['controls']['siteDetails']['controls']['siteCategory'].value,
      'siteAddress':this.siteProfileForm['controls']['siteAddress']['controls']['addrLine1'].value +'\n'+ this.siteProfileForm['controls']['siteAddress']['controls']['addrLine2'].value +'\n'+this.siteProfileForm['controls']['siteAddress']['controls']['addrLine3'].value,
      'siteAddressCountry':this.siteProfileForm['controls']['siteAddress']['controls']['country'].value,
      'siteAddressPostcode':this.siteProfileForm['controls']['siteAddress']['controls']['postalCode'].value,
      'siteContactName':this.siteProfileForm['controls']['siteContact']['controls']['name'].value,
      'siteContactEmail':this.siteProfileForm['controls']['siteContact']['controls']['email'].value,
      'siteContactPhone':this.siteProfileForm['controls']['siteContact']['controls']['phone'].value,
      'siteAutoUpdate':this.siteProfileForm['controls']['siteDetails']['controls']['siteAutoUpdate'].value,
      'siteAutoUpdateURL':this.siteProfileForm['controls']['siteDetails']['controls']['siteAutoUpdateUrl'].value,
    };
    this._postInstalllWizardServ.postSiteProfileApi(siteBody).subscribe((res)=>{
      console.log(res);
      this._ngxLoader.stop();
      this._router.navigate(['/post-install-wizard/ntp-dns-mail']);
    },
    (err)=>{
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Site Profile','error');
    })
  }

}
