import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PostInstallWizardRoutingModule } from './post-install-wizard-routing.module';
import { WizardComponent } from './components/wizard/wizard.component';
import { WizardNavComponent } from 'src/app/shared/components/wizard-nav/wizard-nav.component';
import { WizardSummryComponent } from 'src/app/shared/components/wizard-summry/wizard-summry.component'
import { WizardHeaderComponent } from 'src/app/shared/components/wizard-header/wizard-header.component';
import { NetworkSetupComponent } from './components/network-setup/network-setup.component';
import { WizardMainComponent } from './components/wizard-main/wizard-main.component';
import { HostServerComponent } from './components/host-server/host-server.component';
import { AdminAccountComponent } from './components/admin-account/admin-account.component';
import { SiteProfileComponent } from './components/site-profile/site-profile.component';
import { NtpDnsComponent } from './components/ntp-dns/ntp-dns.component';
import { LoginProgressComponent } from './components/login-progress/login-progress.component';
import { ReactiveFormsModule } from '@angular/forms';
import { PostInstallWizardService } from './services/post-install-wizard.service';
import { CommonErrorDisplayComponent } from './components/common-error-display/common-error-display.component';
import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';

@NgModule({
  declarations: [
    WizardMainComponent,
    WizardNavComponent,
    WizardComponent,
    WizardSummryComponent,
    WizardHeaderComponent,
    NetworkSetupComponent,
    HostServerComponent,
    AdminAccountComponent,
    SiteProfileComponent,
    NtpDnsComponent,
    LoginProgressComponent,
    CommonErrorDisplayComponent,
  ],
  imports: [
    CommonModule,
    SharedLazyModule,
    PostInstallWizardRoutingModule,
    ReactiveFormsModule,
  ],
  providers:[PostInstallWizardService],
  exports: [WizardNavComponent,WizardHeaderComponent,WizardSummryComponent]
})
export class PostInstallWizardModule { }
