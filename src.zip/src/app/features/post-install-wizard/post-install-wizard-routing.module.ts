import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WizardComponent } from './components/wizard/wizard.component';
import { WizardMainComponent } from './components/wizard-main/wizard-main.component';
import { NetworkSetupComponent } from './components/network-setup/network-setup.component';
import { HostServerComponent } from './components/host-server/host-server.component';
import { AdminAccountComponent } from './components/admin-account/admin-account.component';
import { SiteProfileComponent } from './components/site-profile/site-profile.component';
import { NtpDnsComponent } from './components/ntp-dns/ntp-dns.component';
import { LoginProgressComponent } from './components/login-progress/login-progress.component';
import { AuthGuard } from 'src/app/core/guards/auth.guard';

const routes: Routes = [
  { path: 'post-install-wizard-success', component: LoginProgressComponent },
  {
    path: 'post-install-wizard',
    // canActivate: [AuthGuard],
    component: WizardMainComponent,
    children: [
      { path: '', component: WizardComponent },

      { path: 'network-setup', component: NetworkSetupComponent },
      { path: 'host-server/:networkType', component: HostServerComponent },
      { path: 'admin-account', component: AdminAccountComponent },
      { path: 'site-profile', component: SiteProfileComponent },
      { path: 'ntp-dns-mail', component: NtpDnsComponent },
      { path: '**', redirectTo: '/post-install-wizard', pathMatch: 'full' },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PostInstallWizardRoutingModule { }
