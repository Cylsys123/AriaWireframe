export interface IPostInstallWizardForms {
    networkSetupFormValue:INetworkSetupForm,
    hostServerFormValue:IHostServerForm,
    adminAccountFormValue:IAdminAccountForm,
    siteProfileFormValue:ISiteProfileForm,
    ntpDnsMailFormValue:INtpDnsMailForm
}

export interface INetworkSetupForm{
    networkType:string
}

export interface IHostServerForm{
    fullyQualifiedHostName:string,
    hostIPAddress:string,
    subnetMask:string,
    gatewayIP:string,
    destinationIP:string,
    proxyUrl:string,
    proxyServerUsername:string,
    proxyServerPassword:string
}

export interface IAdminAccountForm{
    adminUsername:string,
    adminEmail:string,
    adminPassword:string,
    adminConfPassword:string,
}

export interface ISiteProfileForm{
    siteDetails:ISiteDetailsFormGroup,
    siteAddress:ISiteAddressFormGroup,
    siteContact:ISiteContactFormGroup,
}

export interface INtpDnsMailForm{
    networkTime:INetworkTimeFormGroup,
    dnsServer:IDnsServerFormGroup,
    mailServer:IMailServerFormGroup
}

export interface ISiteDetailsFormGroup{
    siteName:string,
    siteSummary:string,
    siteAlias:string,
    siteCategory:string,
    siteAutoUpdate:boolean,
    siteAutoUpdateUrl:string
}

export interface ISiteAddressFormGroup{
    addrLine1:string,
    addrLine2:string,
    addrLine3:string,
    country:string,
    postalCode:string
}

export interface ISiteContactFormGroup{
    name:string,
    phone:string,
    email:string
}

export interface INetworkTimeFormGroup{
    networkTimeServer:string
}

export interface IDnsServerFormGroup{
    dnsServer1:string,
    dnsServer2:string,
    dnsServer3:string
}

export interface IMailServerFormGroup{
    mailServerIP:string,
    isMailServerRequireAuth:boolean,
    mailServerUsername:string
    mailServerPassword:string,
    useSecureEmailServer:boolean
}





