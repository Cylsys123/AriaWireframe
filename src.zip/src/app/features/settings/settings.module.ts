import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SettingsRoutingModule } from './settings-routing.module';
import { SettingsMainComponent } from './components/settings-main/settings-main.component';

import { HomeModule } from '../home/home.module';
import { TranslateModule } from '@ngx-translate/core';
import { PolicyModule } from '../policy/policy.module';
import { GlobalPolicyComponent } from './components/advanced/global-policy/global-policy.component';
import { GlobalDeviceComponent } from './components/advanced/global-device/global-device.component';
import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';



@NgModule({
  declarations: [
    SettingsMainComponent,
    GlobalPolicyComponent,
    GlobalDeviceComponent,
  ],
  imports: [
    CommonModule,
    HomeModule,
    SettingsRoutingModule,
    TranslateModule,
    PolicyModule,
    SharedLazyModule
  ]
})
export class SettingsModule { }
