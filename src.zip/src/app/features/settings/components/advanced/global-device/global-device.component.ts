import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { forkJoin, Observable } from 'rxjs';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Location } from '@angular/common';
import { PolicyService } from 'src/app/features/policy/services/policy.service';

@Component({
  selector: 'app-global-device',
  templateUrl: './global-device.component.html',
  styleUrls: ['./global-device.component.css']
})
export class GlobalDeviceComponent implements OnInit {
  urlData: string = ""
  policyGroupId: any;
  protectionPolicySimpleArr: any = [];
  protectionPolicyCounterMeasureArr: any = [];
  primaryKey: any;
  policySimpleArr: any = [];
  policyCounterMeasureArr: any = [];
  policyGrpName: string = '';
  groupByList: any = [];
  isPolicyCloneUrl: any = false;

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'name';

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private _policyService: PolicyService,
    private translate: TranslateService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this._setPreData();
  }

  private _setPreData() {
    this.protectionPolicySimpleArr.push(
      {
        "name": this.translate.instant("LBL_AZT_SIMPLE"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_STATUS')
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_NAME')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_POLICY_DETAILS')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_PARAMETERS')
            },
            {
              colKey: 'modified',
              colKeyLabel: this.translate.instant('LBL_AZT_MODIFIED_DATE')
            }

          ],
          "value": []
        }
      });

    this.protectionPolicyCounterMeasureArr.push(
      {
        "name": this.translate.instant("LBL_AZT_COUNTERMEASURE"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_STATUS')
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_NAME')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_POLICY_DETAILS')
            },
            {
              colKey: 'modified',
              colKeyLabel: this.translate.instant('LBL_AZT_MODIFIED_DATE')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_PROTECTION_MODE')
            }

          ],
          "value": []
        }
      });

    this.policyGroupId = this._route.snapshot.queryParams['policyGrpid'];
    this._callPolicyGroupById(this.policyGroupId);
    // (this.policyGroupId) ? this._callPolicyGroupById(this.policyGroupId): this._callSimpleAndCountermeasurePolicy();
    this.groupByList = [
      { name: 'Policy Group Type' },
      { name: 'Policy Group Status' },
      { name: 'On/Off' },
      { name: 'Policy Category' },
      { name: 'Policy Group Mode' },
      { name: 'Policy Group Function' },
    ];
  }
  private _callPolicyGroupById(policyGrpId) {
    this._ngxLoader.start();
    if (policyGrpId) {
      this._policyService.getPolicyGroupByIdApi(policyGrpId).subscribe((res) => {
        if (res["results"].length > 0) {
          let policyObj = this._sharedService.rtnSingleObjFromArrObj(res["results"], { "id": policyGrpId });
          // this.policyGrpName = policyObj.name;
          this.protectionPolicySimpleArr[0]['data']['value'] = policyObj.simple;
          this.protectionPolicyCounterMeasureArr[0]['data']['value'] = policyObj.countermeasures;
        }
        this._ngxLoader.stop();
      },
        (err) => {
          this._ngxLoader.stop();
          if (err.status == 403)
            this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
          else
            this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
        })
    } else {
      let defaultPolicyGroup = JSON.parse(localStorage.getItem('defaultPolicyGroup'));
      // this.policyGrpName = defaultPolicyGroup.name;
      this.protectionPolicySimpleArr[0]['data']['value'] = defaultPolicyGroup.simple;
      this.protectionPolicyCounterMeasureArr[0]['data']['value'] = defaultPolicyGroup.countermeasures;
      this._ngxLoader.stop();
    }

  }

  onToggle(event, value) {
    if (event.target.checked) {
      value['state'] = 1;
      this.upsert(this.policyCounterMeasureArr, value);
      this._sharedService.getToastPopup(value['name'] + ' is enabled. Please click on apply button to save it.', 'AZT Policy', 'success');
      return 1;
    } else {
      value['state'] = 0;
      this.upsert(this.policyCounterMeasureArr, value);
      this._sharedService.getToastPopup(value['name'] + ' is disabled. Please click on apply button to save it.', 'AZT Policy', 'success');
      return 0;
    }
  }

  upsert(array, element) { // (1)
    const i = array.findIndex(_element => _element.id === element.id);
    if (i > -1) array[i] = element; // (2)
    else array.push(element);
  }
  changeStatus(value: object, type: string) {
    if (type == 'simple') {
      value['state'] = Number(value['state']);
      this.upsert(this.policySimpleArr, value);
    } else {
      this.upsert(this.policyCounterMeasureArr, value);
    }

    if (value['state'] == 0) {
      this._sharedService.getToastPopup(value['name'] + ' is disabled. Please click on apply button to save it.', 'AZT Policy', 'success');
    } else {
      this._sharedService.getToastPopup(value['name'] + ' is enabled. Please click on apply button to save it.', 'AZT Policy', 'success');
    }
  }

}
