import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GlobalDeviceComponent } from './global-device.component';

describe('GlobalDeviceComponent', () => {
  let component: GlobalDeviceComponent;
  let fixture: ComponentFixture<GlobalDeviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GlobalDeviceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalDeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
