import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-global-policy',
  templateUrl: './global-policy.component.html',
  styleUrls: ['./global-policy.component.css']
})
export class GlobalPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
