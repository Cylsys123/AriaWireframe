import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings-main',
  templateUrl: './settings-main.component.html',
  styleUrls: ['./settings-main.component.css']
})
export class SettingsMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
