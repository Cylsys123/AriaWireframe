import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GlobalDeviceComponent } from './components/advanced/global-device/global-device.component';
import { GlobalPolicyComponent } from './components/advanced/global-policy/global-policy.component';

import { SettingsMainComponent } from './components/settings-main/settings-main.component';

const routes: Routes = [
  {
    path: 'settings',
    component: SettingsMainComponent,
    children: [
      // { path: '', component: PolicyGroupComponent },
      { path: 'policy-settings', component: GlobalPolicyComponent },
      { path: 'advanced-settings', component: GlobalDeviceComponent },
      { path: '**', redirectTo: '/settings', pathMatch: 'full' },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingsRoutingModule { }
