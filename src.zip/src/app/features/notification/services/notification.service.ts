import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  filterSharingSubject = new Subject();
  constructor(
    private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService,
  ) { }


  //dashboard/alert/list
  getNotificationApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getNotificationEndpoint());
  }

  //dashboard/alert/list
  getNotificationWithQueryApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getNotificationWithQueryParamsEndpoint(queryParamsObj));
  }

  getNotificationChildrenApi(id: string, category: number, status: number) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getNotificationChildrenEndpoint(id, category, status));
  }

  resolveNotification(body) {
    return this._apiHttpService.post(this._apiEndpointsService.resolveNotificationEndpoint(), body);
  }


  // resolveNotification(ids){
  //   return this._apiHttpService.put(this._apiEndpointsService + "dashboard/alert/resolve/?id="+ ids,{});
  // }

  //dashboard/auditTrail/list
  getAuditTrailWithQueryApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getAuditTrailWithQueryParamsEndpoint(queryParamsObj));
  }

  // getAuditTrailWithQueryApi() {
  //   return this._apiHttpService
  //     .get(this._apiEndpointsService.getAuditTrailEndpoint());
  // }

  postTrustUntrustNotificationApi(body: any) {
    return this._apiHttpService
      .post(this._apiEndpointsService.getAlertTriggerEndpoint(), body);
  }

  getTriggerFileNameFromNotificationApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getAlertTriggrtFileNameWithQueryParamsEndpoint(queryParamsObj));
  }

  getEventTypeApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getAuditEventTypeWithQueryParamsEndpoint(queryParamsObj));
  }

  getUsernameApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getAuditUsernameWithQueryParamsEndpoint(queryParamsObj));
  }

  getReportsInCSV(){
    return this._apiHttpService
      .get(this._apiEndpointsService.getAuditInCSV(),{responseType:'text/plain'});
  }

  getReportsInSyslog(){
    return this._apiHttpService
      .get(this._apiEndpointsService.getAuditInSyslog(),{responseType:'text/plain'});
  }

}
