import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuditTrailLogsComponent } from './components/audit-trail-logs/audit-trail-logs.component';
import { ConfirmationComponent } from './components/confirmation/confirmation.component';
import { NotificationMainComponent } from './components/notification-main/notification-main.component';
import { NotificationsLogsComponent } from './components/notifications-logs/notifications-logs.component';
import { NotificationService } from './services/notification.service';
import { TrustUntrustComponent } from './components/trust-untrust/trust-untrust.component';
import { AuthGuard } from 'src/app/core/guards/auth.guard';

const routes: Routes = [
  {
    path: 'notification',
    canActivate: [AuthGuard],
    component: NotificationMainComponent,
    children: [
      { path: '', component: NotificationsLogsComponent },
      { path: 'auditTrailLogs', component: AuditTrailLogsComponent },
      { path: '**', redirectTo: '/notification', pathMatch: 'full' },

    ]
  },

  { path: 'confirmation', component: ConfirmationComponent },
  { path: 'trustUntrust', component: TrustUntrustComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NotificationRoutingModule { }
