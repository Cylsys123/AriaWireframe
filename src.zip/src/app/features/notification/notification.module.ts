import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NotificationRoutingModule } from './notification-routing.module';
import { NotificationMainComponent } from './components/notification-main/notification-main.component';
import { NotificationsLogsComponent } from './components/notifications-logs/notifications-logs.component';
import { HomeModule } from '../home/home.module';
import { PostInstallWizardModule } from '../post-install-wizard/post-install-wizard.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ConfirmationComponent } from './components/confirmation/confirmation.component';
import { AuditTrailLogsComponent } from './components/audit-trail-logs/audit-trail-logs.component';
import { FormsModule } from '@angular/forms';
import { TrustUntrustComponent } from './components/trust-untrust/trust-untrust.component';


@NgModule({
  declarations: [
    NotificationMainComponent,
    NotificationsLogsComponent,
    ConfirmationComponent,
    AuditTrailLogsComponent,
    TrustUntrustComponent
  ],
  imports: [
    CommonModule,
    NotificationRoutingModule,
    HomeModule,
    PostInstallWizardModule,
    TranslateModule,
    SharedLazyModule,
    InfiniteScrollModule,
    FormsModule
  ],

})
export class NotificationModule { }
