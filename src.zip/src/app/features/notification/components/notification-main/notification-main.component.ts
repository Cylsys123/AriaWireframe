import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification-main',
  templateUrl: './notification-main.component.html',
  styleUrls: ['./notification-main.component.css']
})
export class NotificationMainComponent implements OnInit {

  notificationUrl:string
  constructor() { }

  ngOnInit(): void {
  }

  onOutletLoaded(event): void{
    console.log(event._router.url);
    this.notificationUrl = event._router.url;
  }

}
