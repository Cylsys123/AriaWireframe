import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuditTrailLogsComponent } from './audit-trail-logs.component';

describe('AuditTrailLogsComponent', () => {
  let component: AuditTrailLogsComponent;
  let fixture: ComponentFixture<AuditTrailLogsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AuditTrailLogsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AuditTrailLogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
