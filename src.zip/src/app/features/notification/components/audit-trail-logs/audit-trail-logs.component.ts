import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { NotificationService } from '../../services/notification.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { Router } from '@angular/router';

@Component({
  selector: 'app-audit-trail-logs',
  templateUrl: './audit-trail-logs.component.html',
  styleUrls: ['./audit-trail-logs.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AuditTrailLogsComponent implements OnInit {
  objectKeys = Object.keys
  AuditTrailArr: any = [];
  AuditTrailCatArr: any = [];
  AuditTrailStatusArr: any = [];
  groupByList: any = [];

  expanded: { [key: string]: boolean } = {};

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'category';
  filterParams: any = {};

  constructor(
    private _notificationService: NotificationService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private translate: TranslateService,
    private _router: Router,
  ) { }

  async ngOnInit() {
    console.log("AuditTrial OnInt")
    this._setPreData();
    this._fetchDataAndPopulate();

    this._notificationService.filterSharingSubject
      .subscribe((borrower) => {
        if (borrower['url'] == 'audit') {
          this.filterParams = borrower['data'];
          this.globalPageNumber = 1;
          this.AuditTrailArr[0]['data']['value'] = [];
          this._fetchDataAndPopulate();
        }
      });
  }

  private _setPreData() {
    this.AuditTrailArr.push(
      {
        "name": this.translate.instant("LBL_AZT_ALERT"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant(' ')
            },
            {
              colKey: 'category',
              colKeyLabel: this.translate.instant('LBL_AZT_EVENT_CATEGORY')
            },
            {
              colKey: 'date_added',
              colKeyLabel: this.translate.instant('LBL_AZT_EVENT_TIME')
            },
            {
              colKey: 'username',
              colKeyLabel: this.translate.instant('LBL_AZT_CAMERON_W')
            },
            {
              colKey: 'descriptions',
              colKeyLabel: this.translate.instant('LBL_AZT_DESCRIPTIONS')
            },
            {
              colKey: 'host',
              colKeyLabel: this.translate.instant('LBL_AZT_HOST')
            },
            {
              colKey: 'ip',
              colKeyLabel: this.translate.instant('LBL_AZT_HOST_IP')
            },

          ],
          "value": []
        }
      });

    this.AuditTrailCatArr = JSON.parse(localStorage.getItem('alertHostname'));
    this.AuditTrailCatArr = JSON.parse(localStorage.getItem('alertCategory'));
    this.AuditTrailStatusArr = JSON.parse(localStorage.getItem('alertStatus'));

    this.groupByList = [
      { name: 'All' },
      { name: 'Device group' },
      { name: 'Device type' },
      { name: 'Nofification' },
      { name: 'Alert' },
      { name: 'Valnerabilities' },
      { name: 'Policies' },
      { name: 'Integration' }
    ];

    this.getEventType();
    this.getUsername();
  }


  getAuditTrailStatusAndCat(id: number | string, type: string) {
    return type == 'status' ? this.AuditTrailStatusArr['Status'].filter((mData) => { return mData[id] })[0][id] :
      this.AuditTrailCatArr['Categories'].filter((mData) => { return mData[id] })[0][id];
  }


  // private _auditTrailEndPoint() {
  //   this._ngxLoader.start();
  //   let auditTrailQueryParams = this._setPaginationConfig();
  //   this._notificationService.getAuditTrailWithQueryApi(auditTrailQueryParams).subscribe((res) => {

  //     if (res['results'].length > 0) {
  //       this.AuditTrailArr[0]['data']['value'] = res['results'];

  //       for (let index = 0; index < this.AuditTrailArr[0]['data']['value'].length; index++) {
  //         this.AuditTrailArr[0]['data']['value'][index].children = [];
  //         this.AuditTrailArr[0]['data']['value'][index].isVisible = true;
  //         this.AuditTrailArr[0]['data']['value'][index].isOpened = false;
  //       }
  //     }
  //     this._ngxLoader.stop();
  //   },
  //     (err) => {
  //       if (err.status == 403) {
  //         this._ngxLoader.stop();
  //         this._sharedService.getToastPopup(err.error['detail'], 'AZT Notification', 'error');
  //       }
  //       else {
  //         this._ngxLoader.stop();
  //         this._sharedService.getToastPopup('Internal server error', 'AZT Notification', 'error');
  //       }
  //     })
  // }

  isRowClickable(rowIndex: number): boolean {
    return this.AuditTrailArr[0]['data']['value'].children && this.AuditTrailArr[0]['data']['value'].children.length > 0
  }

  fnHideShowChildren(value, isChildren) {

    if (isChildren == 1) {
      value.isVisible = true;
      value.isOpened = true;
    }
    else {
      value.isVisible = false;
      value.isOpened = false;
    }
  }

  deleteAlert() {


    this._router.navigate(['/confirmation']);
  }


  showSortArrow(queryParamKey: string | undefined): boolean {
    return queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-');
  }

  sortTableCol(queryParamKey: string | undefined) {
    if (queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-')) {
      this.sortParamKey = queryParamKey;
    } else {
      this.sortParamKey = '-' + queryParamKey;
    }
    this.globalPageNumber = 1;
    if (this.isScrollDisable) this.isScrollDisable = false;
    this.AuditTrailArr[0]['data']['value'] = [];
    this._fetchDataAndPopulate();
  }

  onScrollDown() {
    this._fetchDataAndPopulate();
  }

  private _setPaginationConfig(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());
    let filterQueryParams = this.filterParams;
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    let sortQueryParams = {
      ordering: this.sortParamKey
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  private _fetchDataAndPopulate() {
    this._ngxLoader.start();
    let deviceQueryParams = this._setPaginationConfig();
    this._notificationService.getAuditTrailWithQueryApi(deviceQueryParams).subscribe(res => {
      this._ngxLoader.stop();
      if (res && res['count'] !== 0 && res['results'].length !== 0) {
        this.AuditTrailArr[0]['data']['value'].push(...res['results']);
        this.totalRecords = res['count'];
        if (this.totalRecords === this.AuditTrailArr[0]['data']['value'].length) {
          this.isScrollDisable = true;
        }

        for (let index = 0; index < this.AuditTrailArr[0]['data']['value'].length; index++) {
          if (Object.keys(this.AuditTrailArr[0]['data']['value'][index].data).length == 0) {
            this.AuditTrailArr[0]['data']['value'][index].data = {};
          }
          // if (index == 0)
          //   this.AuditTrailArr[0]['data']['value'][index].data = { "field1": "test", "field2": "test" };
          // this.AuditTrailArr[0]['data']['value'][index].children = {};
          // if (Object.keys(this.AuditTrailArr[0]['data']['value'][index].data).length > 0) {
          //   let childdata = this.AuditTrailArr[0]['data']['value'][index].data
          //   this.AuditTrailArr[0]['data']['value'][index].children = childdata;
          // }







          // this.AuditTrailArr[0]['data']['value'][index].isVisible = true;
          // if (this._sharedService.alertObj != null && this._sharedService.alertObj != undefined) {
          //   if (this._sharedService.alertObj.id == this.AuditTrailArr[0]['data']['value'][index].id) {
          //     this.AuditTrailArr[0]['data']['value'][index].isOpened = true;
          //     let value = this.AuditTrailArr[0]['data']['value'][index];
          //     this._notificationService.getNotificationChildrenApi(value.device_id, value.category, value.status).subscribe(res => {
          //       value.children = res['results'];
          //     })
          //   }
          // }
        }

console.log('this.AuditTrailArr'); console.log(this.AuditTrailArr);
        this.globalPageNumber += 1;

      }
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Notification', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Notification', 'error');
      }
    });
  }

  getEventType(paramsObject = {}) {
    this._notificationService.getEventTypeApi(paramsObject).subscribe(res => {


      localStorage.setItem('eventType', JSON.stringify(res));
    })
  }

  getUsername(paramsObject = {}) {
    this._notificationService.getUsernameApi(paramsObject).subscribe(res => {


      localStorage.setItem('username', JSON.stringify(res));
    })
  }

  getReportInCSV(){
    this._ngxLoader.start();

    this._notificationService.getReportsInCSV().subscribe((res: any)=>{
      
      this._ngxLoader.stop();

      let blob = new Blob([res], { type: 'text/csv' });
      let url= window.URL.createObjectURL(blob);
      window.open(url);
      
    },(err)=>{
      console.log("ERRor",err);
      this._ngxLoader.stop();
    });
  }

  getReportInSyslog(){
    this._ngxLoader.start();
    this._notificationService.getReportsInSyslog().subscribe((res: any)=>{
      
      this._ngxLoader.stop();

      const file = new window.Blob([res], { type: 'text' });
      const downloadAncher = document.createElement("a");
      downloadAncher.style.display = "none";

      const fileURL = URL.createObjectURL(file);
      downloadAncher.href = fileURL;
      downloadAncher.download = "audit_file";
      downloadAncher.click();

    },(err)=>{
      console.log("Error",err);
      this._ngxLoader.stop();
    });
  }

}
