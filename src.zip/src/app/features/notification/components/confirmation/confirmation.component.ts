import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { DeviceService } from 'src/app/features/device/services/device.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent implements OnInit {

  alertIDs : any[] = [];
  device_Grp_ID : any;
  deviceGrpname : any;
  protectedDevCount : any;
  frmAlert : boolean = false;
  frmDevGrp : boolean = false;

  constructor(
              private _router: Router,
              private _notificationService: NotificationService,
              private _sharedService: SharedService,
              private _ngxLoader: NgxUiLoaderService,
              private _deviceService: DeviceService) { }



  ngOnInit(): void {
    
    this._ngxLoader.start();
    setTimeout(() => {
      this._ngxLoader.stop();
    }, 1000);

    if(this._sharedService.isFrmAlert){
      this.frmAlert = true;
      this.frmDevGrp = false;
      this.getAlertsIds();  
    }
    else if(this._sharedService.isFrmDeviceGrp){
      this.frmDevGrp = true;
      this.frmAlert = false;
      this.getDeviceId();
    }
  }

  getAlertsIds(){
    this.alertIDs = this._sharedService.alertIds;
  }

  getDeviceId(){
    this.device_Grp_ID = this._sharedService._device_group_ID;
    this.deviceGrpname = this._sharedService.deviceGroupname;
    this.protectedDevCount = this._sharedService.protectedDevices;
  }

  
  cancel() {

    if(this._sharedService.isFrmAlert) {
      this._router.navigate(['/notification']);
    }
    else if(this._sharedService.isFrmDeviceGrp){
      this._router.navigate(['/devices/device-group-summary']);
    }

  }

  deleteData(){
    if(this._sharedService.isFrmAlert) {
      this.deleteAlert();
    }
    else if(this._sharedService.isFrmDeviceGrp){
      this.deleteDeviceGrp();
    }
  }

  deleteAlert() {
    this._ngxLoader.start();

    let body = {
      "ids" : this.alertIDs
    }

    this._notificationService.resolveNotification(body).subscribe(res=>{
      this._ngxLoader.stop();
      if(res){
        this._sharedService.getToastPopup('Alert(s) Deleted Successful', 'AZT Notification', 'success');
        this._router.navigate(['/notification']);
        this.alertIDs = [];
      }
    },(err)=>{

      if (err.status == 403) {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Notification', 'error');
      }
      else {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Internal server error', 'AZT Notification', 'error');
      }
    })
  }

  deleteDeviceGrp(){
    this._ngxLoader.start();
    this._deviceService.deleteDeviceGroup(this.device_Grp_ID).subscribe((res : any)=>{
      this._ngxLoader.stop();
      if(res == null){
        this._sharedService.getToastPopup('Device Group Deleted Successful', 'AZT Device', 'success');
        this._router.navigate(['/devices/device-group-summary']);
        this.device_Grp_ID = [];
        this.deviceGrpname = "";
      }

    },(err)=>{
      if (err.status == 403) {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
      }
      else {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
      }
    })
  }
}
