import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationsLogsComponent } from './notifications-logs.component';

describe('NotificationsLogsComponent', () => {
  let component: NotificationsLogsComponent;
  let fixture: ComponentFixture<NotificationsLogsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotificationsLogsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationsLogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
