import { ChangeDetectorRef, Component, ElementRef, OnInit, QueryList, ViewChildren } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { NotificationService } from '../../services/notification.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { Router } from '@angular/router';

@Component({
  selector: 'app-notifications-logs',
  templateUrl: './notifications-logs.component.html',
  styleUrls: ['./notifications-logs.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class NotificationsLogsComponent implements OnInit {
  objectKeys = Object.keys
  latestAlertArr: any = [];
  latestAlertCatArr: any = [];
  latestAlertStatusArr: any = [];
  groupByList: any = [];
  alertList: any = [];

  masterSelected: boolean;
  selectedAlert = [];
  checkedAlertList: any;
  masterChecked: boolean = false;
  @ViewChildren("checkboxes") checkboxes: QueryList<ElementRef>;
  ParentIdtobechanged: any
  expanded: { [key: string]: boolean } = {};

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'host_name,timestamp';//timestamp added to correct trust/untrust ZT-1184
  alertIds: any[] = [];
  notificationGrpArr: any = [];
  filterParams: any = {};
  isDisabled: boolean = false;
  isScroll: boolean = false;
  fileIsTrusted: boolean = false;
  alertArray = [];
  trustedCount: number;
  istrustedCount: number;
  isUntrustedCount: number;
  isBothCount: number;
  tooltipText: any;

  parentId = "";
  lstToBeRemoved: any=[];
  constructor(
    private _notificationService: NotificationService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private translate: TranslateService,
    private _router: Router,
    private _chngDtr: ChangeDetectorRef
  ) { }

  async ngOnInit() {
    this._setPreData();
    this._fetchDataAndPopulate();
    // if (this.filterParams != null) {
    this._notificationService.filterSharingSubject
      .subscribe((borrower) => {
        if (borrower['url'] == 'alert') {
          this.filterParams = borrower['data'];
          this.globalPageNumber = 1;
          this.latestAlertArr[0]['data']['value'] = [];
          this._fetchDataAndPopulate();
        }
      });
    // }

    this.tooltipText = `
                  <div class="tooltiptxt" >
                    <div class="row " >
                      <div class="col-md-12">
                        <p><span>Risk Lavel :</span>  URGENT. NEED ATTENTION</p>
                      </div>
                      <div class="col-md-12">
                        <p><span>Summary :</span>  Your alerts indicates there are devices under attack and are not yet fully
                                protected by the AZT Prevent Protection Policy .</p>
                      </div>
                      <div class="col-md-12">
                        <p><span>Actions :</span>   Use the ACTIONS buttons provided to change the protection policy to PREVENT mode.
                        <a>Learn more...</a></p>
                      </div>
                    </div> 
                  </div>`

  }

  private _setPreData() {
    this.latestAlertArr.push(
      {
        "name": this.translate.instant("LBL_AZT_ALERT"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              // colKeyLabel: this.translate.instant('LBL_AZT_RISK')

            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_RISK_LEVEL')
            },
            {
              colKey: 'host_name',
              colKeyLabel: this.translate.instant('LBL_AZT_DEVICE_NAME')
            },
            {
              colKey: 'ip',
              colKeyLabel: this.translate.instant('LBL_AZT_IP')
            },
            {
              colKey: 'message',
              colKeyLabel: this.translate.instant('LBL_AZT_MESSAGE')
            },

            {
              colKey: 'filename',
              colKeyLabel: this.translate.instant('LBL_AZT_FILENAME')
            },

            {
              colKey: 'trusted',
              colKeyLabel: this.translate.instant('LBL_AZT_FILE_STATUS')
            },
            {
              colKey: 'category',
              colKeyLabel: this.translate.instant('LBL_AZT_CATEGORY')
            },
            {
              colKey: 'status',
              colKeyLabel: this.translate.instant('LBL_AZT_STATUS')
            },
            {
              colKey: 'recorded',
              colKeyLabel: this.translate.instant('LBL_AZT_DETECT_DATE_TIME')
            },
            // {
            //   colKey: 'datetime',
            //   colKeyLabel: this.translate.instant('LBL_AZT_STATUS')
            // },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_ACTION')
            },
          ],
          "value": []
        }
      });

    // this.latestAlertCatArr = JSON.parse(localStorage.getItem('alertHostname'));
    this.latestAlertCatArr = JSON.parse(localStorage.getItem('alertCategory'));
    this.latestAlertStatusArr = JSON.parse(localStorage.getItem('alertStatus'));

    this.groupByList = [
      { name: 'All' },
      { name: 'Device group' },
      { name: 'Device type' },
      { name: 'Nofification' },
      { name: 'Alert' },
      { name: 'Valnerabilities' },
      { name: 'Policies' },
      { name: 'Integration' }
    ];

    this.alertList = [
      // { name: 'Snooze 24h', isDisabled: true },
      // { name: 'Assign', isDisabled: true },
      { name: 'Dismiss', isDisabled: false, code: "Dismiss" },
      // { name: 'Ignore', isDisabled: true },
      // { name: 'Add trigger file to exceptions', isDisabled: true },
      { name: 'Mark filename as Trusted', isDisabled: false, code: "Trusted" },
      { name: 'Mark filename as Untrusted', isDisabled: false, code: "Untrusted" },
    ];

    this.getFileTrigger();
  }


  changeAlertTrigger(value: any, obj: any) {

    if (obj != null) {
      this.selectedAlert.push(obj.id);
      this._sharedService.selectedDevice = this.selectedAlert;
      if (value.code == "Trusted") {
        this._sharedService.isTrusted = true;
        if (this.isDisabled == false) {
          this._router.navigate(['/trustUntrust']);
        }
      }
      else if (value.name == "Dismiss") {
        this.onSingleClick(obj);
      }
      else {
        this._sharedService.isTrusted = false;
        if (this.isDisabled == false) {
          this._router.navigate(['/trustUntrust']);
        }
      }
    }

    else {
      this._sharedService.selectedDevice = this.selectedAlert;
      if (value.code == "Trusted") {
        this._sharedService.isTrusted = true;
        if (this.isDisabled == false) {
          this._router.navigate(['/trustUntrust']);
        }
      }
      else if (value.name == "Dismiss") {
        this.onMultiSelect();
      }
      else {
        this._sharedService.isTrusted = false;
        if (this.isDisabled == false) {
          this._router.navigate(['/trustUntrust']);
        }
      }
    }
  }

  changeChildAlertTrigger(childrow: any, obj: any) {

    if (obj != null) {
      this.selectedAlert.push(obj.id);
      this._sharedService.selectedDevice = this.selectedAlert;
      if (childrow.code == "Trusted") {
        this._sharedService.isTrusted = true;
        if (this.isDisabled == false) {
          this._router.navigate(['/trustUntrust']);
        }
      }
      else if (childrow.name == "Dismiss") {
        this.onSingleClick(obj);
      }
      else {
        this._sharedService.isTrusted = false;
        if (this.isDisabled == false) {
          this._router.navigate(['/trustUntrust']);
        }
      }
    }

    else {
      this._sharedService.selectedDevice = this.selectedAlert;
      if (childrow.code == "Trusted") {
        this._sharedService.isTrusted = true;
        if (this.isDisabled == false) {
          this._router.navigate(['/trustUntrust']);
        }
      }
      else if (childrow.name == "Dismiss") {
        this.onMultiSelect();
      }
      else {
        this._sharedService.isTrusted = false;
        if (this.isDisabled == false) {
          this._router.navigate(['/trustUntrust']);
        }
      }
    }
  }

  getAlertStatusAndCat(id: number | string, type: string) {
    return type == 'status' ? this.latestAlertStatusArr['Status'].filter((mData) => { return mData[id] })[0][id] :
      this.latestAlertCatArr['Categories'].filter((mData) => { return mData[id] })[0][id];
  }

  isRowClickable(rowIndex: number): boolean {
    return this.latestAlertArr[0]['data']['value'].children && this.latestAlertArr[0]['data']['value'].children.length > 0
  }

  async fnHideShowChildren(value, isChildren, isFromDashboard, event) {
    if (isChildren == 1) {
      value.isVisible = true;
      value.isOpened = true;

      let _deviceId = isFromDashboard == 1 ? this._sharedService.alertObj.device_id : value.device_id;
      let _categoryId = isFromDashboard == 1 ? this._sharedService.alertObj.category : value.category;
      let _statusId = isFromDashboard == 1 ? this._sharedService.alertObj.status : value.status;

      if (value.children.length > 0) {
        value.isOpened = true;
        value.isVisible = true;

        for (let index = 0; index < value.children.length; index++) {
          if (value != undefined && value.isSelected)
            value.children[index].isSelected = true;
          else
            value.children[index].isSelected = false;
        }

      }
      else {

        this._notificationService.getNotificationChildrenApi(_deviceId, _categoryId, _statusId).subscribe(res => {

          value.children = res['results'].filter(item => item.id != value.id);
          for (let index = 0; index < value.children.length; index++) {
            // if (value != undefined && value.isSelected) {
            //   value.children[index].isSelected = true;
            // }
            // else {
            //   value.children[index].isSelected = false;
            // }
            if (value.children[index].payload != undefined && value.children[index].payload != null) {
              value.children[index].level3 = this.isJsonString(atob(value.children[index].payload)) == true ? JSON.parse(atob(value.children[index].payload)) : "";
            }
            else {
              value.children[index].level3 = {};
            }

            // value.children[index].level3 = this.isJsonString(atob(value.children[index].payload)) == true ? JSON.parse(atob(value.children[index].payload)) : "";
            value.children[index].isOpened = false;
            if (value.isOpened && value.isSelected)
              value.children[index].isSelected = true;

            if (isFromDashboard == 1) {
              value.isOpened = true;
              value.isVisible = true;
            }
          }
        })
      }
    }
    else {

      value.isVisible = false;
      value.isOpened = false;



      for (let index = 0; index < value.children.length; index++) {
        value.children[index].isOpened = false;

        // var arr = document.getElementsByClassName('mylevel3_' + value.id);
        // for (var i = 0; i < arr.length; i++) {
        //   var children = arr[i];
        //   children.parentNode.removeChild(children);
        // }
        // arr.forEach(element => {

        // });
      }

      const elements = Array.from(document.querySelectorAll('.mylevel3_' + value.id));
      elements.forEach(element => {
        element.parentNode.removeChild(element);
      });

    }
  }

  fnHideShowChildren2(value, isChildren, isFromDashboard, childData, event) {

    if (isChildren == 1 && !childData.isOpened) {
      value.isLevel3 = true;
      value.isVisible = true;
      value.isOpened2 = true;
      value.level3 = this.isJsonString(atob(value.payload)) == true ? JSON.parse(atob(value.payload)) : "";
      childData.isOpened = true;
      if (isFromDashboard == 1) {
        value.isOpened2 = true;
      }

      const tr: HTMLTableRowElement = document.createElement('tr');
      tr.className = "mylevel3_" + value.id;
      const div: HTMLDivElement = document.createElement('div');
      div.className = "arrow-right"
      div.style.height = "13px !important";
      let html = `<td></td><td>
<div _ngcontent-bdw-c125="" class="arrow-right ng-tns-c125-0" style="display: flex;
width: 150%;
align-items: center;
position: relative;
left: 0px;
height: 32px;">
  <div _ngcontent-bdw-c125="" class="vertical ng-tns-c125-0" style="height: 116%;
  width: 2px;
  background-image: linear-gradient( rgb(55 151 194) 55%, rgb(234 217 217 / 0%) 0% );
  background-position: left;
  background-size: 7px 7px;
  background-repeat: repeat-y;
  position: relative;
  top: -19px;
  "></div>
  <div _ngcontent-bdw-c125="" class="horizontal ng-tns-c125-0" style="width: 100%;
  height: 2px;
  background-image: linear-gradient( to right, #3797c2 55%, rgba(228, 218, 218, 0) 0% );
  background-position: bottom;
  background-size: 7px 7px;
  background-repeat: repeat-x;"></div>
</div>
</td>`;


      html += `<td colspan="9" class="level3_data " >
<div _ngcontent-bdw-c125="" class="auditLavel2 auditLavel2_height ng-tns-c125-0"  style="border:1px solid #008dd1; border-top:1px solid #008dd1 !important; padding: 10px 0;">
  <div class="row m-0">
    <div class="col-md-12">
      <div class="auditLavel2-ul">
        <ul class="m-0 d-flex">`;

      for (let index = 0; index < this.objectKeys(value.level3).length; index++) {
        html += "<li>" + this.objectKeys(value.level3)[index] + " | " + "<span>"
          + value.level3[this.objectKeys(value.level3)[index]] + "</span></i>"

      }
      html += `
        </ul>
      </div>
    </div>
    <div class="col-md-2"></div>
  </div>
</div>
</td>`




      // tr.innerHTML = "<td></td><td>" + div.outerHTML + "</td><td>test</td><td>test</td><td>test</td><td>test</td><td>test</td><td>test</td><td>test</td>"
      tr.innerHTML = html;
      this.insertAfter(tr, event.srcElement.parentElement.parentElement.parentElement.parentElement);
    }
    else {
      value.isLevel3 = false;
      value.isVisible = false;
      value.isOpened2 = false;
      value.children.isOpened = false;
      childData.isOpened = false;

      //var parent = event.srcElement.parentElement.parentElement.parentElement.parentElement;
      var children = event.srcElement.parentElement.parentElement.parentElement.parentElement.nextSibling;

      children.parentNode.removeChild(children);
      // parent.remove(children);


    }
  }

  insertAfter(newElement, referenceElement) {
    referenceElement.parentNode.insertBefore(newElement, referenceElement.nextSibling);
  }

  isJsonString(str) {
    try {
      JSON.parse(str);
    } catch (e) {
      return false;
    }
    return true;
  }

  onSingleClick(item) {
    this.alertIds.push(item.id);
    this._sharedService.alertIds = this.alertIds;
    this._sharedService.isFrmAlert = true;
    this._sharedService.frmDeviceGrp = false;
    this._router.navigate(['/confirmation']);
  }

  onMultiSelect() {
    if (this.selectedAlert.length == 0) {
      return;
    }
    this._sharedService.alertIds = this.selectedAlert;
    this._sharedService.isFrmAlert = true;
    this._sharedService.isCancelFrmAlert = true;
    this._sharedService.frmDeviceGrp = false;
    this._router.navigate(['/confirmation']);
  }


  showSortArrow(queryParamKey: string | undefined): boolean {
    return queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-');
  }

  sortTableCol(queryParamKey: string | undefined) {
    if (queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-')) {
      this.sortParamKey = queryParamKey;
    } else {
      this.sortParamKey = '-' + queryParamKey;
    }
    this.globalPageNumber = 1;
    if (this.isScrollDisable) this.isScrollDisable = false;
    this.latestAlertArr[0]['data']['value'] = [];
    this._fetchDataAndPopulate();
  }

  async onScrollDown() {

    if (this.masterSelected == true)
      // await this.onScrollSelectAll();

      this.checkboxes.forEach((element) => {
        element.nativeElement.checked = true;
      });
    this.isScroll = true;
    this._fetchDataAndPopulate();
  }

  private _setPaginationConfig(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());

    let filterQueryParams = this.filterParams;

    if (!this.isScroll) {
      this.latestAlertArr[0]['data']['value'] = [];
    }
    // let filterQueryParams = {
    // };
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    // let sortQueryParams = {
    //   ordering: this.sortParamKey
    // };

    let sortQueryParams = {}
    //if (this.latestAlertArr[0]['data']['value'].length > 0) {
    sortQueryParams = {
      ordering: this.sortParamKey
    };
    //}
    // else {
    //   sortQueryParams = {
    //     ordering: this.sortParamKey
    //   };
    // }


    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  //  async onScrollSelectAll() {
  //     for (var i = 0; i < this.latestAlertArr[0]['data']['value'].length; i++) {
  //       this.latestAlertArr[0]['data']['value'].isSelected = this.masterSelected;
  //       this.selectedAlert.push(this.latestAlertArr[0]['data']['value'][i].id);
  //       this.checkboxes.forEach((element) => {
  //         element.nativeElement.checked = true;
  //       });
  //     }
  //   }

  ngAfterViewChecked() {
    if (this.masterSelected == true) {
      this.checkboxes.forEach((element) => {
        element.nativeElement.checked = true;
      });
    }

    if (this.ParentIdtobechanged != '') {
      this.checkboxes.forEach((element) => {
        if (element.nativeElement.name == this.ParentIdtobechanged) {
          element.nativeElement.checked = false;
          this.ParentIdtobechanged = ''
          return;
        }
      });
    }

  }

  private _fetchDataAndPopulate() {
    this._ngxLoader.start();
    let deviceQueryParams = this._setPaginationConfig();
    this._notificationService.getNotificationWithQueryApi(deviceQueryParams).subscribe(res => {

      if (res && res['count'] !== 0 && res['results'].length !== 0) {


        for (let index = 0; index < res['results'].length; index++) {
          res['results'][index].children = [];
          res['results'][index].isVisible = true;
        }
        this.latestAlertArr[0]['data']['value'].push(...res['results']);
        this.totalRecords = res['count'];

        if (this.totalRecords == this.latestAlertArr[0]['data']['value'].length) {
          this.isScrollDisable = true;
        }


        for (let index = 0; index < this.latestAlertArr[0]['data']['value'].length; index++) {

          if (this._sharedService.alertObj != null && this._sharedService.alertObj != undefined) {
            if (this._sharedService.alertObj.id == this.latestAlertArr[0]['data']['value'][index].id) {
              this.latestAlertArr[0]['data']['value'][index].isOpened = true;
              let value = this.latestAlertArr[0]['data']['value'][index];
            }
          }

          if (this._sharedService.isCancelFrmAlert) {
            if (this._sharedService.selectedDevice.length > 0) {
              for (let index = 0; index < this._sharedService.selectedDevice.length; index++) {
                if (this._sharedService.selectedDevice[index] == this.latestAlertArr[0]['data']['value'][index].id) {
                  this.latestAlertArr[0]['data']['value'][index].isSelected = true;
                }
              }
              this.selectedAlert = this._sharedService.selectedDevice;
            }
            this.checkboxes.forEach((element) => {
              element.nativeElement.checked = true;
            });
            this.isScrollDisable = true;
          }


        }

        this.globalPageNumber += 1;
      }

      if (this._sharedService.alertObj != null) {
        let obj = this.latestAlertArr[0]['data']['value'].filter(x => x.id == this._sharedService.alertObj.id)
        if (this._sharedService.alertObj.id != '')
          this.fnHideShowChildren(obj[0], 1, 1, null);
      }

      this._ngxLoader.stop();

    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Notification', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Notification', 'error');
      }
    });
  }

  checkUncheckAllAlerts(event) {
    this.selectedAlert = [];

    for (var i = 0; i < this.latestAlertArr[0]['data']['value'].length; i++) {
      this.masterSelected = event.target.checked;
      if (event.target.checked == true) {
        this.latestAlertArr[0]['data']['value'][i].isSelected = true;
        this.selectedAlert.push(this.latestAlertArr[0]['data']['value'][i].id);
        this.checkboxes.forEach((element) => {
          element.nativeElement.checked = true;
        });
      } else if (event.target.checked == false) {
        this.selectedAlert = [];
        this.checkboxes.forEach((element) => {
          element.nativeElement.checked = false;
        });
      }
      // this.latestAlertArr[0]['data']['value'][i].isSelected = this.masterSelected;
    }

    this.getCheckedAlertItemList();
  }

  isAllSelectedAlert(item, event) {
    if (event.target.checked == true) {
      this.selectedAlert.push(item.id);
      this.alertArray.push(item);
      this.fileIsTrusted = item.trusted;
      let obj = this.latestAlertArr[0]['data']['value'].find(o => o.id === item.id);
      obj.isSelected = true;

      if (item.children.length > 0) {
        for (let index = 0; index < item.children.length; index++) {
          item.children[index].isSelected = true;
          
          this.selectedAlert.push(item.children[index].id);
          this.alertArray.push(item.children[index]);
        }
      }

    } else if (event.target.checked == false) {
      this.fileIsTrusted = false;
      const index: number = this.selectedAlert.indexOf(item.id);
      if (index !== -1) {
        this.masterSelected = false;
        this.selectedAlert.splice(index, 1);
        let obj = this.latestAlertArr[0]['data']['value'].find(o => o.id === item.id);
        obj.isSelected = false;
      }


      

      const index1: number = this.alertArray.findIndex(x => x.id == item.id);
      if (index1 !== -1) {
        this.masterSelected = false;
        this.alertArray.splice(index1, 1);
      }
      if (item.children.length > 0) {
        for (let index = 0; index < item.children.length; index++) {
          this.lstToBeRemoved.push(item.children[index].id);
          item.children[index].isSelected = false;
          let index1: number = this.alertArray.findIndex(x => x.id == item.children[index].id);
          if (index1 !== -1) {            
            this.alertArray.splice(index1, 1);
          }
          index1 = this.selectedAlert.indexOf(item.id);
          if (index1 !== -1) {     
            this.selectedAlert.splice(index1, 1);
          }
        }
      }
    }


    let isOneSelected = this.checkboxes.filter(x => x.nativeElement.checked == false);

    if (isOneSelected.length > 0) {
      this.masterSelected = false;
    }
    else {
      this.masterSelected = true;
    }
    this.checkTrustUntrust();
    this.getCheckedAlertItemList();
  }






  isSingleAlert(item, event, parentobj) {
    if (event.target.checked == true) {
      this.selectedAlert.push(item.id);
      this.alertArray.push(item);
      this.fileIsTrusted = item.trusted;
      item.isSelected = true;
    } else if (event.target.checked == false) {
      this.fileIsTrusted = false;
      const index: number = this.selectedAlert.indexOf(item.id);
      if (index !== -1) {
        this.masterSelected = false;
        this.selectedAlert.splice(index, 1);
        let obj = this.latestAlertArr[0]['data']['value'].find(o => o.id === item.id);
        obj.isSelected = false;
      }
      item.isSelected = false;
      const index1: number = this.alertArray.findIndex(x => x.id == item.id);
      if (index1 !== -1) {
        this.masterSelected = false;
        this.alertArray.splice(index, 1);
      }
      parentobj.isSelected = false;
      this._chngDtr.detectChanges()
      let ele = document.getElementsByName("alert_name_" + parentobj.id) as unknown as HTMLInputElement;
      ele.checked = false;

      this.ParentIdtobechanged = ("alert_name_" + parentobj.id);

    }


    let isOneSelected = this.checkboxes.filter(x => x.nativeElement.checked == false);
    if (isOneSelected.length > 0) {
      this.masterSelected = false;
    }
    else {
      this.masterSelected = true;
    }
    this.checkTrustUntrust();
    this.getCheckedAlertItemList();

    let parent = this.latestAlertArr[0]['data']['value'].filter(x => x.id == parentobj.id)
    if (event.target.checked == false) {
      parent.isSelected = false;
    }
    else {
      let isAllchildSelected = parentobj.children.filter(x => !x.isSelected)
      if (isAllchildSelected.length > 0) {
        parent.isSelected = false;
      }
    }


  }

  private checkTrustUntrust() {
    this.istrustedCount = 0;
    this.isUntrustedCount = 0;
    this.isBothCount = 0;
    this.istrustedCount = this.alertArray.filter(x => x.trusted === true).length;
    this.isUntrustedCount = this.alertArray.filter(x => x.trusted === false).length;
    if (this.alertArray.length > 1) {

      if (this.istrustedCount > 0 && this.isUntrustedCount > 0) {
        this.isBothCount = 1;
      }
    }
  }

  getRecordStatus(code, type) {

    let status = type == 1 ? 'enable-file' : 'auto'

    if ((code === 'Trusted' || code === 'Untrusted') && this.isBothCount > 0) {

      status = type == 1 ? 'disabled-file' : 'none'
    }

    else if (code === 'Trusted' && this.istrustedCount > 0) {
      status = type == 1 ? 'disabled-file' : 'none'
    }

    else if (code === 'Untrusted' && this.isUntrustedCount > 0) {
      status = type == 1 ? 'disabled-file' : 'none'
    }

    return status;
  }

  getCheckedAlertItemList() {

    this.checkedAlertList = [];
    for (var i = 0; i < this.latestAlertArr[0]['data']['value'].length; i++) {
      if (this.latestAlertArr[0]['data']['value'][i].isSelected)
        this.checkedAlertList.push(this.latestAlertArr[0]['data']['value'][i]);
    }
    this.checkedAlertList = JSON.stringify(this.checkedAlertList);
  }

  getFileTrigger(paramsObject = {}) {
    this._notificationService.getTriggerFileNameFromNotificationApi(paramsObject).subscribe(res => {

      localStorage.setItem('triggerFile', JSON.stringify(res));
    })
  }

  tooltipOptions = {
    'placement': 'left',
    'showDelay': 500,
    'tooltip-class': 'riskTooltip'
  }
}
