import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-trust-untrust',
  templateUrl: './trust-untrust.component.html',
  styleUrls: ['./trust-untrust.component.css']
})
export class TrustUntrustComponent implements OnInit {

  alertIDs: any[] = [];
  trustuntrusted: any;
  constructor(
    private _router: Router,
    private _notificationService: NotificationService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService) { }


  ngOnInit(): void {

    this._ngxLoader.start();
    setTimeout(() => {
      this._ngxLoader.stop();
    }, 1000);

    this.getAlertsIds();
    this.gettrustuntrustedIds();
  }

  getAlertsIds() {

    this.alertIDs = this._sharedService.selectedDevice;
  }

  gettrustuntrustedIds() {
    this.trustuntrusted = this._sharedService.isTrusted;
  }

  cancel() {

    // if (this._sharedService.isCancelFrmAlert) {
    //   this._router.navigate(['/notification']);
    // }
    // else if (this._sharedService.isCancelFrmDeviceGrp) {
    //   this._router.navigate(['/devices/device-group-summary']);
    // }
    if(this._sharedService.selectedDevice.length == 1){
      this._sharedService.selectedDevice = [];
    }
    this._sharedService.isCancelFrmAlert = true;
    
    this._router.navigate(['/notification']);

  }

  confirmTrigger() {

    this._ngxLoader.start();

    let finalarray = {
      "triggers": []

    }

    for (let index = 0; index < this._sharedService.selectedDevice.length; index++) {

      finalarray.triggers.push({ alert_id: this._sharedService.selectedDevice[index], action: this.trustuntrusted == true ? 'trusted' : 'untrusted' });

    }

    this._notificationService.postTrustUntrustNotificationApi(finalarray).subscribe((res) => {
     
      this._ngxLoader.stop();
      if(this.trustuntrusted) {
        this._sharedService.getToastPopup('Selected trigger file(s) have been successfully marked as trusted', 'AZT Notification', 'success');
      }
      else {
        this._sharedService.getToastPopup('Selected trigger file(s) have been successfully marked as untrusted', 'AZT Notification', 'success');
      }

      this._sharedService.selectedDevice = [];
      this._sharedService.alertObj = null;
      this._router.navigate(['/notification']);


    },
      (err) => {
      if (err.status == 403) {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Notification', 'error');
      }
      else {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Internal server error', 'AZT Notification', 'error');
      }
    })
  }
}
