import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrustUntrustComponent } from './trust-untrust.component';

describe('TrustUntrustComponent', () => {
  let component: TrustUntrustComponent;
  let fixture: ComponentFixture<TrustUntrustComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrustUntrustComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrustUntrustComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
