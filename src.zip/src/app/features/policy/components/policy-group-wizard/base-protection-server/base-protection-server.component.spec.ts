import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseProtectionServerComponent } from './base-protection-server.component';

describe('BaseProtectionServerComponent', () => {
  let component: BaseProtectionServerComponent;
  let fixture: ComponentFixture<BaseProtectionServerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BaseProtectionServerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseProtectionServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
