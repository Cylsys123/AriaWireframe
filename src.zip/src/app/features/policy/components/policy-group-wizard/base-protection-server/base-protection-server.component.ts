import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-base-protection-server',
  templateUrl: './base-protection-server.component.html',
  styleUrls: ['./base-protection-server.component.css']
})
export class BaseProtectionServerComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }
  serverException(){
    this._router.navigateByUrl('/policy-group/server-exceptions');
  }
}
