import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-groups',
  templateUrl: './device-groups.component.html',
  styleUrls: ['./device-groups.component.css']
})
export class DeviceGroupsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
