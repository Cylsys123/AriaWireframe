import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyExclusionComponent } from './apply-exclusion.component';

describe('ApplyExclusionComponent', () => {
  let component: ApplyExclusionComponent;
  let fixture: ComponentFixture<ApplyExclusionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplyExclusionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplyExclusionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
