import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-exclusion',
  templateUrl: './apply-exclusion.component.html',
  styleUrls: ['./apply-exclusion.component.css']
})
export class ApplyExclusionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
