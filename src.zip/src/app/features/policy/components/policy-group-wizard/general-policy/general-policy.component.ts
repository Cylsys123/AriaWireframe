import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PolicyNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { stringValidator } from 'src/app/shared/classes/validator';
import { PolicyService } from '../../../services/policy.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Location } from '@angular/common';

@Component({
  selector: 'app-general-policy',
  templateUrl: './general-policy.component.html',
  styleUrls: ['./general-policy.component.css']
})
export class GeneralPolicyComponent implements OnInit {

  isPolicyInstallWizard: any = false;
  isPolicyCloneUrl: any = false;
  policyName: string | null = 'N/A';
  getWizardNavigations: any = [];

  policyGroupId: string;
  isEditable:boolean = true;

  policyGroupGeneralForm:FormGroup;

  constructor(
        private _route: ActivatedRoute,
        private _sharedService: SharedService,
        private _router: Router,
        private _fb: FormBuilder,
        private _policyService: PolicyService,
        private _ngxLoader: NgxUiLoaderService,
        private location: Location
        ) { 

            window.addEventListener('beforeunload', (event) => {
              if(this.policyGroupGeneralForm.dirty){
                event.returnValue = 'There are unsaved changes which will be lost - do you still want to proceed with the refresh?';
              }
            });
        }
  ngOnInit(): void {
    this.getPolicyNavObs();
    this.createPolicyGroupGeneralForm();
    this._onLoadUpdatePolicyGroupGeneralFormValue();
    if(this.policyGroupId) this._getPolicyGroupById();
  }

  createPolicyGroupGeneralForm(){
    
    this.policyGroupGeneralForm = this._fb.group({
      'policyGroupname':['',{
        validators: [stringValidator('Policy group name',1,100)],
        updateOn: 'change',
      }],
      'description':['',{
        validators: [stringValidator('Description',0,100)],
        updateOn: 'change',
      }],
      'iconLabel':['',{
        validators: [stringValidator('Icon Label',0,100)],
        updateOn: 'change',
      }],
      'iconColor':['',{
        validators: [stringValidator('color',0,20)],
        updateOn: 'change',
      }]
    // },confPasswordValidator('Admin Confirm Password','adminPassword','adminConfPassword'));
    });

    if(!this.policyGroupId){
      let policyObj = JSON.parse(localStorage.getItem('defaultPolicyGroup'));
      this.policyGroupGeneralForm['controls']['policyGroupname'].setValue(policyObj['name'] ?policyObj['name']:'')
      this.policyGroupGeneralForm['controls']['description'].setValue(policyObj['description'] ?policyObj['description']:'')
      this.policyGroupGeneralForm['controls']['iconLabel'].setValue(policyObj['icon'] ?policyObj['icon']:'')
      this.policyGroupGeneralForm['controls']['iconColor'].setValue(policyObj['color'] ?policyObj['color']:'')
      this._updatePolicyGroupGeneralFormInSer();
    } 
  }

  private _onLoadUpdatePolicyGroupGeneralFormValue(){
    this.policyGroupGeneralForm.patchValue(this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue']);
    this._policyService.policyGrpName = this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue'].policyGroupname;
  }

  private _updatePolicyGroupGeneralFormInSer(){
    this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue']= {
      policyGroupname:this.policyGroupGeneralForm['controls']['policyGroupname'].value,
      description:this.policyGroupGeneralForm['controls']['description'].value,
      iconLabel:this.policyGroupGeneralForm['controls']['iconLabel'].value,
      iconColor:this.policyGroupGeneralForm['controls']['iconColor'].value,
    }
  }
  

  getPolicyNavObs() {
    this.policyGroupId = this._route.snapshot.queryParams['policyGrpid'];
    this.isPolicyInstallWizard = this._route.snapshot.queryParams['isPolicyInstallWizard'];
    this.isPolicyCloneUrl = this._route.snapshot.queryParams['isPolicyCloneUrl'];
  }


  submitPolicyGeneralForm() {
    this._updatePolicyGroupGeneralFormInSer();
    let policyNameValidate = {
      name:this.policyGroupGeneralForm['controls']['policyGroupname'].value
    };

    if(this.policyGroupId){
      policyNameValidate['exclude_ids'] = this.policyGroupId; 
      this._validatePolicyGroupName(policyNameValidate);
      this._policyService.policyGrpName = this.policyGroupGeneralForm['controls']['policyGroupname'].value;
    }else{
      this._validatePolicyGroupName(policyNameValidate);
      this._policyService.policyGrpName = this.policyGroupGeneralForm['controls']['policyGroupname'].value;
    }
  }

  private _getPolicyGroupById() {
    this._ngxLoader.start();
    this._policyService.getPolicyGroupsWithQueryApi(this.policyGroupId,true).subscribe(res => {
      console.log(res);
      if (res) {
        let policyObj = res;
        this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue']= {
          policyGroupname: policyObj['name'] ?policyObj['name']:'',
          description:policyObj['description'] ?policyObj['description']:'',
          iconLabel:policyObj['icon'] ?policyObj['icon']:'',
          iconColor:policyObj['color'] ?policyObj['color']:'',
        }
        this._onLoadUpdatePolicyGroupGeneralFormValue();
      }
      this._ngxLoader.stop();
      
    }, (err) => {
      if (err.status == 403) {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
      }
      else {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
      }
    });
  }

  private _validatePolicyGroupName(paramsObje:Object) {
    this._ngxLoader.start();
    this._policyService.getPolicyGroupsValidateNameWithQueryApi(paramsObje).subscribe(res => {
      this._ngxLoader.stop();
      if(this.policyGroupId){
        this._router.navigate(['/policy-group/protection-policy'], { queryParams: {isPolicyCloneUrl: this.isPolicyCloneUrl,policyGrpid: this.policyGroupId } });
      }else{
        this._router.navigate(['/policy-group/protection-policy'], { queryParams: {isPolicyCloneUrl: this.isPolicyCloneUrl } });
      }
    }, (err) => {
      if (err.status == 403 || err.status == 400) {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
      }
      else {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
      }
    });
  }

  saveDescription() {
    this.isEditable = false;
  }

  back() {
    this.location.back();
  }

}
