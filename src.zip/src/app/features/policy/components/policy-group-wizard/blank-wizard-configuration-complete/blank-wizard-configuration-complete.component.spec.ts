import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlankWizardConfigurationCompleteComponent } from './blank-wizard-configuration-complete.component';

describe('BlankWizardConfigurationCompleteComponent', () => {
  let component: BlankWizardConfigurationCompleteComponent;
  let fixture: ComponentFixture<BlankWizardConfigurationCompleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlankWizardConfigurationCompleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BlankWizardConfigurationCompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
