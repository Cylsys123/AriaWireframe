import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blank-wizard-configuration-complete',
  templateUrl: './blank-wizard-configuration-complete.component.html',
  styleUrls: ['./blank-wizard-configuration-complete.component.css']
})
export class BlankWizardConfigurationCompleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
