import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationCompleteComponent } from './configuration-complete.component';

describe('ConfigurationCompleteComponent', () => {
  let component: ConfigurationCompleteComponent;
  let fixture: ComponentFixture<ConfigurationCompleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfigurationCompleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationCompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
