import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProtectionPolicy } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-configuration-complete',
  templateUrl: './configuration-complete.component.html',
  styleUrls: ['./configuration-complete.component.css']
})
export class ConfigurationCompleteComponent implements OnInit {
  url: any = "policy-group";
  policyBlankUrl: string = "/";
  policyName: string = "N/A";
  constructor(private _router: Router, private _sharedService: SharedService, private _route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getPolicyUrl();
  }
  getPolicyUrl() {

    this.policyName = this._route.snapshot.queryParams['policyName'];
    switch (this.policyName) {
      case ProtectionPolicy.PROTECTION_POLICIES:
        this.policyBlankUrl = '/policy-group/protection-policy';
        break;
    }
  }
  navigatePolicy() {
    this._router.navigateByUrl('/policy');
  }

  move() {
    // this._router.navigateByUrl('/protection-policy');
    this._router.navigate(['policy-group/protection-policy'], { queryParams: { policyName: this.policyName, isPolicyInstallWizard: false, isPolicyCloneUrl: false } });
  }
}
