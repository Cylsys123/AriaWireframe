import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { PolicyNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { PolicyService } from '../../../services/policy.service';

@Component({
  selector: 'app-policy-wizard-group',
  templateUrl: './policy-wizard-group.component.html',
  styleUrls: ['./policy-wizard-group.component.css']
})
export class PolicyWizardGroupComponent implements OnInit {

  policyBlankUrl: string = "/";
  policyCloneUrl: string = "/";
  policyName: string = "N/A";
  policyNameLabel: string = "N/A";
  constructor(
    private _sharedService: SharedService,
    private _router: Router,
    private _route: ActivatedRoute,
    private _ngxLoader: NgxUiLoaderService,
    private _policyService: PolicyService
    ) { }

  ngOnInit(): void {
    this.getPolicyUrl();
  }

  getPolicyUrl() {

    this.policyName = this._route.snapshot.queryParams['policyName'];
    switch (this.policyName) {
      case PolicyNav.POLICY_GROUPS:
        this.policyNameLabel = 'LBL_AZT_POLICY_GROUPS';
        this.policyBlankUrl = '/policy-group/general';
        this.policyCloneUrl = '/policy-group/source-policy';
        break;

      case PolicyNav.PROTECTION_POLICIES:
        this.policyBlankUrl = '/protection-policies/general';
        this.policyCloneUrl = '/protection-policies/source-policy';
        break;

      case PolicyNav.EXCEPTION_POLICIES:
        this.policyBlankUrl = '/exception-policies/general';
        this.policyCloneUrl = '/exception-policies/source-policy';
        break;

      case PolicyNav.NOTIFICATION_POLICIES:
        this.policyBlankUrl = '/notification-policies/general';
        this.policyCloneUrl = '/notification-policies/source-policy';
        break;

        case PolicyNav.SYSTEM_POLICIES:
          this.policyBlankUrl = '/system-policies/general';
          this.policyCloneUrl = '/system-policies/source-policy';
          break;
    }
  }

  redirectToBlankPolicy() {
    this._ngxLoader.start();
    this._generateTempPolicyGroup();
  }

  redirectToClonePolicy() {
    this._router.navigate([this.policyCloneUrl], { queryParams: { policyName: PolicyNav.POLICY_GROUPS, isPolicyInstallWizard: true, isPolicyCloneUrl: true} });
  }

  private _generateTempPolicyGroup() {
    this._policyService.postPolicyGroupsTempWithQueryApi({}).subscribe(res => {
      this._ngxLoader.stop();
      console.log(res);
      localStorage.setItem('defaultPolicyGroup',JSON.stringify(res));
      this._router.navigate([this.policyBlankUrl], { queryParams: { policyName: PolicyNav.POLICY_GROUPS, isPolicyInstallWizard: true, isPolicyCloneUrl: false} });
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) 
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
      else 
        this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
    });
  }



}
