import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-system-policy',
  templateUrl: './system-policy.component.html',
  styleUrls: ['./system-policy.component.css']
})
export class SystemPolicyComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }


  next() {
    this._router.navigateByUrl('/policy-group/miscellaneous-policy');
}

back(){
  this._router.navigateByUrl('/policy-group/notification-policy');
}

}
