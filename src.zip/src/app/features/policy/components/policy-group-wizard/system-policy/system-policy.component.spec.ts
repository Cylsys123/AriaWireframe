import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemPolicyComponent } from './system-policy.component';

describe('SystemPolicyComponent', () => {
  let component: SystemPolicyComponent;
  let fixture: ComponentFixture<SystemPolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SystemPolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemPolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
