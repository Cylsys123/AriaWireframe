import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SourcePolicyComponent } from './source-policy.component';

describe('SourcePolicyComponent', () => {
  let component: SourcePolicyComponent;
  let fixture: ComponentFixture<SourcePolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SourcePolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SourcePolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
