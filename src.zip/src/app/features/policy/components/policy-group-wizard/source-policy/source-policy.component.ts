import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { PolicyService } from '../../../services/policy.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-source-policy',
  templateUrl: './source-policy.component.html',
  styleUrls: ['./source-policy.component.css']
})
export class SourcePolicyComponent implements OnInit {

  policyGroupArr: any = [];
  groupByList: any = [];

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'name';
  policyGroupName: string;
  selectedPolicyGroupId:number;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _policyService: PolicyService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private translate: TranslateService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this._setPreData();
    this._fetchDataAndPopulate();
  }

  private _setPreData() {
    this.policyGroupArr.push(
      {
        "name": this.translate.instant("LBL_AZT_NEW_DEVICE"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: ''
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_NAME')
            },
            {
              colKey: 'description',
              colKeyLabel: this.translate.instant('LBL_AZT_DESCRIPTIONS')
            },
            {
              colKey: 'icon',
              colKeyLabel: this.translate.instant('LBL_AZT_ICON_LABEL')
            },
            {
              colKey: 'color',
              colKeyLabel: this.translate.instant('LBL_AZT_ICON_COLOR')
            },
            {
              colKey: 'modified',
              colKeyLabel: this.translate.instant('LBL_AZT_MODIFIED_DATE')
            }
          ],
          "value": []
        }
      });
    // this.getPolicyUrl();
    this.policyGroupName = this._route.snapshot.queryParams['policyName'];
    this.groupByList = [
      { name: 'Policy Group Type' },
      { name: 'Policy Group Status' },
      { name: 'On/Off' },
      { name: 'Policy Category' },
      { name: 'Policy Group Mode' },
      { name: 'Policy Group Function' },
    ];
    this.selectedPolicyGroupId = this._policyService.policyGroupFormValues['policyGroupSourceTabFormValue']['selectedPolicyGroupId'];
  }

  // getPolicyUrl() {
  //   this.policyName = this._route.snapshot.queryParams['policyName'];
  //   switch (this.policyName) {
  //     case ProtectionPolicy.PROTECTION_POLICIES:
  //       this.policyBlankUrl = '/policy-group/protection-policy';
  //       break;
  //   }
  // }

  showSortArrow(queryParamKey: string | undefined): boolean {
    return queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-');
  }

  sortTableCol(queryParamKey: string | undefined) {
    if (queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-')) {
      this.sortParamKey = queryParamKey;
    } else {
      this.sortParamKey = '-' + queryParamKey;
    }
    this.globalPageNumber = 1;
    if (this.isScrollDisable) this.isScrollDisable = false;
    this.policyGroupArr[0]['data']['value'] = [];
    this._fetchDataAndPopulate();
  }

  onScrollDown() {
    console.log('scroll');
    this._fetchDataAndPopulate();
  }

  private _setPaginationConfig(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());
    let filterQueryParams = {};
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    let sortQueryParams = {
      ordering: this.sortParamKey
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  private _fetchDataAndPopulate() {
    this._ngxLoader.start();
    let deviceQueryParams = this._setPaginationConfig();
    this._policyService.getPolicyGroupsWithQueryApi(deviceQueryParams).subscribe(res => {
      this._ngxLoader.stop();

      if (res && res['count'] !== 0 && res['results'].length !== 0) {
        this.policyGroupArr[0]['data']['value'].push(...res['results']);
        this.totalRecords = res['count'];
        if (this.totalRecords === this.policyGroupArr[0]['data']['value'].length) {
          this.isScrollDisable = true;
        }
        this.globalPageNumber += 1;
      }
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
      }
    });
  }

  onChange(evt) {
    this.selectedPolicyGroupId = this._policyService.policyGroupFormValues['policyGroupSourceTabFormValue']['selectedPolicyGroupId'] = evt.target.value;
  }

  clonePolicyGroup() {
    let policyGroupObj = this._setPrePolicyServiceForm();
    this._generateTempPolicyGroup(policyGroupObj);
  }

  private _setPrePolicyServiceForm() {
    let policyGroupObj = this._sharedService.rtnSingleObjFromArrObj(this.policyGroupArr[0]['data']['value'], { "id": this._policyService.policyGroupFormValues['policyGroupSourceTabFormValue']['selectedPolicyGroupId'] });
    console.log(policyGroupObj);
    return policyGroupObj;
  }


  back() {
    this.location.back();
  }

  private _generateTempPolicyGroup(params) {
    this._ngxLoader.start();
    this._policyService.postPolicyGroupsTempWithQueryApi({clone:params['id']}).subscribe(res => {
      this._ngxLoader.stop();
      console.log(res);
      localStorage.setItem('defaultPolicyGroup',JSON.stringify(res));
      this._policyService.policyGroupFormValues['isPolicyGroupCloned'] = true;
      this._policyService.checkClonedPolicySubject.next('PG');
      this._router.navigate(['/policy-group/general'], { queryParams: {isPolicyInstallWizard: true, isPolicyCloneUrl: true } });
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) 
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
      else 
        this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
    });
  }

}
