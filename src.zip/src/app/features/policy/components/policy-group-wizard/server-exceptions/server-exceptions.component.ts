import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-server-exceptions',
  templateUrl: './server-exceptions.component.html',
  styleUrls: ['./server-exceptions.component.css']
})
export class ServerExceptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
