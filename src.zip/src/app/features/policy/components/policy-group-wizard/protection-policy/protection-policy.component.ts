import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { PolicyService } from '../../../services/policy.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-protection-policy',
  templateUrl: './protection-policy.component.html',
  styleUrls: ['./protection-policy.component.css']
})
export class ProtectionPolicyComponent implements OnInit {
  urlData: string = "";
  policyGroupId: any;
  protectionPolicySimpleArr: any = [];
  protectionPolicyCounterMeasureArr: any = [];
  primaryKey: any;
  policySimpleArr: any = [];
  policyCounterMeasureArr: any = [];
  policyGrpName: string = '';
  groupByList: any = [];
  isPolicyCloneUrl: any = false;
  counterMeasurePolicyState : any;

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'name';

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private _policyService: PolicyService,
    private translate: TranslateService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this._setPreData();
    
    this.policyGrpName = this._policyService.policyGrpName;

    if(this._policyService.frmAdvanceSetting) {
      for (let index = 0; index < this.protectionPolicyCounterMeasureArr[0]['data']['value'].length; index++) {
       let data = Object.keys(this._policyService.counterMeasurePolicy).length
       let isExists = false;
        for (let zindex = 0; zindex < data; zindex++) {
            if((this.protectionPolicyCounterMeasureArr[0]['data']['value'][index].id == this._policyService.counterMeasurePolicy[zindex].id) &&  this._policyService.counterMeasurePolicy[zindex].state == 1){
              isExists = true;
            }
        }
        if(isExists) {
          this.protectionPolicyCounterMeasureArr[0]['data']['value'][index].state = 1;
        } 
        else {
          this.protectionPolicyCounterMeasureArr[0]['data']['value'][index].state = 0;
        }
          
      }
    }
  }

  private _setPreData() {
    this.protectionPolicySimpleArr.push(
      {
        "name": this.translate.instant("LBL_AZT_SIMPLE"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_STATUS')
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_NAME')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_POLICY_DETAILS')
            },
            {
              colKey: 'modified',
              colKeyLabel: this.translate.instant('LBL_AZT_MODIFIED_DATE')
            }

          ],
          "value": []
        }
      });

    this.protectionPolicyCounterMeasureArr.push(
      {
        "name": this.translate.instant("LBL_AZT_COUNTERMEASURE"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_STATUS')
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_NAME')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_POLICY_DETAILS')
            },
            {
              colKey: 'modified',
              colKeyLabel: this.translate.instant('LBL_AZT_MODIFIED_DATE')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_PROTECTION_MODE')
            }

          ],
          "value": []
        }
      });

    this.policyGroupId = this._route.snapshot.queryParams['policyGrpid'];
    this._callPolicyGroupById(this.policyGroupId);

    // (this.policyGroupId) ? this._callPolicyGroupById(this.policyGroupId): this._callSimpleAndCountermeasurePolicy();
    this.groupByList = [
      { name: 'Policy Group Type' },
      { name: 'Policy Group Status' },
      { name: 'On/Off' },
      { name: 'Policy Category' },
      { name: 'Policy Group Mode' },
      { name: 'Policy Group Function' },
    ];
  }

  private _callPolicyGroupById(policyGrpId) {
    this._ngxLoader.start();
    if (policyGrpId) {
      this._policyService.getPolicyGroupByIdApi(policyGrpId).subscribe((res) => {
        if (res["results"].length > 0) {
          let policyObj = this._sharedService.rtnSingleObjFromArrObj(res["results"], { "id": policyGrpId });
          this.policyGrpName = policyObj.name;
          this.protectionPolicySimpleArr[0]['data']['value'] = policyObj.simple;
          this.protectionPolicyCounterMeasureArr[0]['data']['value'] = policyObj.countermeasures;
          this.policyGrpName = this._policyService.policyGrpName;
        }
        this._ngxLoader.stop();
      },
        (err) => {
          this._ngxLoader.stop();
          if (err.status == 403)
            this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
          else
            this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
        })
    } else {
      let defaultPolicyGroup = JSON.parse(localStorage.getItem('defaultPolicyGroup'));
      
      // this.policyGrpName = defaultPolicyGroup.name;
      this.policyGrpName = this._policyService.policyGrpName;
      this.protectionPolicySimpleArr[0]['data']['value'] = defaultPolicyGroup.simple;
      this.protectionPolicyCounterMeasureArr[0]['data']['value'] = defaultPolicyGroup.countermeasures;
      this._ngxLoader.stop();
    }

  }

  next() {
    this._ngxLoader.start();
    // let simple = this.protectionPolicySimpleArr[0]['data']['value'].map(simple => {
    //   return { id: simple['id'], state: simple['state'] };
    // });
    // let counterMeasure = this.protectionPolicyCounterMeasureArr[0]['data']['value'].map(counterMeasure => {
    //   return { id: counterMeasure['id'], state: counterMeasure['state'] };
    // });

    this._policyService.counterMeasurePolicy = this.protectionPolicyCounterMeasureArr[0]['data']['value'].map(counterMeasure => {
      return { id: counterMeasure['id'], state: counterMeasure['state'] };
    });

    if(Object.keys(this._policyService.counterMeasurePolicy).length === 0){
      this._policyService.counterMeasurePolicy = [];
    }

    if(Object.keys(this._policyService.simplePolicyObj).length === 0){
      this._policyService.simplePolicyObj = this.protectionPolicySimpleArr[0]['data']['value'].map(simple => {
          return { id: simple['id'], enabled: simple['enabled'] };
        });

    }

    let bodyParams = {};
    bodyParams['name'] = this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue']['policyGroupname'];
    bodyParams['description'] = this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue']['description'];
    bodyParams['icon'] = this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue']['iconLabel'];
    bodyParams['color'] = this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue']['iconColor'];
    // bodyParams['simple'] = simple;
    bodyParams['simple'] = this._policyService.simplePolicyObj;
    // bodyParams['countermeasures'] = counterMeasure;

    bodyParams['countermeasures'] = this._policyService.counterMeasurePolicy;

    if (this.policyGroupId) {
      //call put
      this._policyService.putPolicyGroupsWithQueryApi(this.policyGroupId, bodyParams, true).subscribe((res) => {
        this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue'] = {
          policyGroupname: '',
          description: '',
          iconLabel: '',
          iconColor: ''
        };
        this._policyService.simplePolicyObj = {};
        this._policyService.counterMeasurePolicy = {};
        this._policyService.policyGrpName = "";
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Successfully, Updated Policy', 'AZT Policy', 'success');
        this._router.navigateByUrl('/policy');
      },
        (err) => {
          this._ngxLoader.stop();
          if (err.status == 403) {
            this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
          }
          else if (err.status == 400) {
            this._sharedService.getToastPopup(err.error['name'], 'AZT Policy', 'error');
          }
          else {
            this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
          }
        })
    } else {
      //call post
      this._policyService.postPolicyGroupApi(bodyParams).subscribe((res) => {
        this._policyService.policyGroupFormValues['policyGroupGeneralTabFormValue'] = {
          policyGroupname: '',
          description: '',
          iconLabel: '',
          iconColor: ''
        };
        this._policyService.simplePolicyObj = {};
        this._policyService.counterMeasurePolicy = {};
        this._policyService.policyGrpName = "";
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Successfully, Updated Policy', 'AZT Policy', 'success');
        this._router.navigateByUrl('/policy');
      },
        (err) => {
          this._ngxLoader.stop();
          if (err.status == 403) {
            this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
          }
          else if (err.status == 400) {
            this._sharedService.getToastPopup(err.error['name'], 'AZT Policy', 'error');
          }
          else {
            this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
          }
        })
    }
  }

  back() {
    // this._router.navigateByUrl('/policy');
    this.location.back();
  }

  BaseProtection() {
    this._router.navigateByUrl('/policy-group/base-protection-server');
  }

  onToggle(event, value) {
    if (event.target.checked) {
      value['state'] = 1;
      this.upsert(this.policyCounterMeasureArr, value);
      this._sharedService.getToastPopup(value['name'] + ' is enabled. Please click on apply button to save it.', 'AZT Policy', 'success');
      return 1;
    } else {
      value['state'] = 0;
      this.upsert(this.policyCounterMeasureArr, value);
      this._sharedService.getToastPopup(value['name'] + ' is disabled. Please click on apply button to save it.', 'AZT Policy', 'success');
      return 0;
    }
  }

  upsert(array, element) { // (1)
    const i = array.findIndex(_element => _element.id === element.id);
    if (i > -1) array[i] = element; // (2)
    else array.push(element);
  }

  changeStatus(value: object, type: string) {
    if (type == 'simple') {
      value['state'] = Number(value['state']);
      this.upsert(this.policySimpleArr, value);
    } else {
      this.upsert(this.policyCounterMeasureArr, value);
    }

    if (value['state'] == 0) {
      this._sharedService.getToastPopup(value['name'] + ' is disabled. Please click on apply button to save it.', 'AZT Policy', 'success');
    } else {
      this._sharedService.getToastPopup(value['name'] + ' is enabled. Please click on apply button to save it.', 'AZT Policy', 'success');
    }
  }



  advanceSetting() {

    this._policyService.counterMeasurePolicy = this.protectionPolicyCounterMeasureArr[0]['data']['value'].map(counterMeasure => {
      return { id: counterMeasure['id'], state: counterMeasure['state'] };
    });

    
    this._router.navigate(['/policy-group/advanceSetting'], { queryParams: { isPolicyCloneUrl: this.isPolicyCloneUrl, policyGrpid: this.policyGroupId } });

  }
}
