import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-config-secret-question',
  templateUrl: './config-secret-question.component.html',
  styleUrls: ['./config-secret-question.component.css']
})
export class ConfigSecretQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
