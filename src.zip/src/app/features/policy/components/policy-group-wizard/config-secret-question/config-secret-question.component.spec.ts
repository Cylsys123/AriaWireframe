import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigSecretQuestionComponent } from './config-secret-question.component';

describe('ConfigSecretQuestionComponent', () => {
  let component: ConfigSecretQuestionComponent;
  let fixture: ComponentFixture<ConfigSecretQuestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfigSecretQuestionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigSecretQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
