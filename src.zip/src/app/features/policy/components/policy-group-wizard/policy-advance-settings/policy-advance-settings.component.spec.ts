import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyAdvanceSettingsComponent } from './policy-advance-settings.component';

describe('PolicyAdvanceSettingsComponent', () => {
  let component: PolicyAdvanceSettingsComponent;
  let fixture: ComponentFixture<PolicyAdvanceSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyAdvanceSettingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyAdvanceSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
