import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiscellaneusPolicyComponent } from './miscellaneus-policy.component';

describe('MiscellaneusPolicyComponent', () => {
  let component: MiscellaneusPolicyComponent;
  let fixture: ComponentFixture<MiscellaneusPolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiscellaneusPolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiscellaneusPolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
