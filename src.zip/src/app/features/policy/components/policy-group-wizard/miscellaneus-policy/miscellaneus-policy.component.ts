import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-miscellaneus-policy',
  templateUrl: './miscellaneus-policy.component.html',
  styleUrls: ['./miscellaneus-policy.component.css']
})
export class MiscellaneusPolicyComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }


  next() {
    this._router.navigateByUrl('/policy-group/device-groups');
}

back(){
  this._router.navigateByUrl('/policy-group/system-policy');
}

}
