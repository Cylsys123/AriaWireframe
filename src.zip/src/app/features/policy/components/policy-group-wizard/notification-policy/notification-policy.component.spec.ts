import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationPolicyComponent } from './notification-policy.component';

describe('NotificationPolicyComponent', () => {
  let component: NotificationPolicyComponent;
  let fixture: ComponentFixture<NotificationPolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotificationPolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationPolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
