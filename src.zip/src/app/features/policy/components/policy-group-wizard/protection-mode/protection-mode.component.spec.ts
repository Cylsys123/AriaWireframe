import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProtectionModeComponent } from './protection-mode.component';

describe('ProtectionModeComponent', () => {
  let component: ProtectionModeComponent;
  let fixture: ComponentFixture<ProtectionModeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProtectionModeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProtectionModeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
