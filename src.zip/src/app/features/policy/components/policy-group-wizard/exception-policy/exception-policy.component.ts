import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-exception-policy',
  templateUrl: './exception-policy.component.html',
  styleUrls: ['./exception-policy.component.css']
})
export class ExceptionPolicyComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }

  next() {
    this._router.navigateByUrl('/policy-group/notification-policy');
}

back(){
  this._router.navigateByUrl('/policy-group/protection-policy');
}

}
