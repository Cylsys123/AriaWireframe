import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExceptionPolicyComponent } from './exception-policy.component';

describe('ExceptionPolicyComponent', () => {
  let component: ExceptionPolicyComponent;
  let fixture: ComponentFixture<ExceptionPolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExceptionPolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExceptionPolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
