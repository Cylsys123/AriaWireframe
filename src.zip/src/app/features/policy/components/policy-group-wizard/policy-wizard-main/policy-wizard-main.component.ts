import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-wizard-main',
  templateUrl: './policy-wizard-main.component.html',
  styleUrls: ['./policy-wizard-main.component.css']
})
export class PolicyWizardMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
