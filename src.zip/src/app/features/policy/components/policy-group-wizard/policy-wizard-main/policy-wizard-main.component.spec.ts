import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyWizardMainComponent } from './policy-wizard-main.component';

describe('PolicyWizardMainComponent', () => {
  let component: PolicyWizardMainComponent;
  let fixture: ComponentFixture<PolicyWizardMainComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyWizardMainComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyWizardMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
