import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-properties',
  templateUrl: './properties.component.html',
  styleUrls: ['./properties.component.css']
})
export class PropertiesComponent implements OnInit {

  isServerException: boolean = false;

  constructor(private _router: Router) { }

  ngOnInit(): void {
    console.log("url", this._router.url)
  }

  setTitle() {

    console.log("url", this._router.url)

    if (this._router.url == "/policy-group") {
      this.isServerException = true;
    } else if (this._router.url == "/policy-group/properties") {
      this.isServerException = true;
    }
   
  }

  ngAfterContentChecked(): void {
    this.setTitle();
  }
}
