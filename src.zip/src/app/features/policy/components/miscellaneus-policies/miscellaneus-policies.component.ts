import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-miscellaneus-policies',
  templateUrl: './miscellaneus-policies.component.html',
  styleUrls: ['./miscellaneus-policies.component.css']
})
export class MiscellaneusPoliciesComponent implements OnInit {
  url: any = "miscellaneous-policy"
  constructor(private _router: Router, private _sharedService: SharedService) { }

  ngOnInit(): void {

  }
  navigateUrl() {
    this._router.navigate(['/policy-group-wizard']);
  }


}
