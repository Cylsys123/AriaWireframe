import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiscellaneusPoliciesComponent } from './miscellaneus-policies.component';

describe('MiscellaneusPoliciesComponent', () => {
  let component: MiscellaneusPoliciesComponent;
  let fixture: ComponentFixture<MiscellaneusPoliciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiscellaneusPoliciesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiscellaneusPoliciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
