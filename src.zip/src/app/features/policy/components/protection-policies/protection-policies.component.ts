import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-protection-policies',
  templateUrl: './protection-policies.component.html',
  styleUrls: ['./protection-policies.component.css']
})
export class ProtectionPoliciesComponent implements OnInit {
  url: any = "protection-policy"
  constructor(private _router: Router, private _sharedService: SharedService) { }

  ngOnInit(): void {
  }



  navigateUrl() {

    this._router.navigate(['policy-group-wizard'], { queryParams: { policyName: PolicyNav.PROTECTION_POLICIES } });
  }


}
