import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-notification-policies',
  templateUrl: './notification-policies.component.html',
  styleUrls: ['./notification-policies.component.css']
})
export class NotificationPoliciesComponent implements OnInit {
  url: any = "miscellaneous-policy"
  constructor(private _router: Router, private _sharedService: SharedService) { }

  ngOnInit(): void {
  }
  navigateUrl() {

    this._router.navigate(['policy-group-wizard'], { queryParams: { policyName: PolicyNav.NOTIFICATION_POLICIES } });

  }



}
