import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from 'src/app/shared/services/shared.service';
import { PolicyNav, ProtectionPolicy } from 'src/app/shared/enum/shared.enum';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { PolicyService } from '../../services/policy.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-policy-group',
  templateUrl: './policy-group.component.html',
  styleUrls: ['./policy-group.component.css']
})
export class PolicyGroupComponent implements OnInit {
  url: any = "policy-group";
  policyBlankUrl: string = "/";
  policyName: string = "N/A";
  policyGroupArr: any = [];
  groupByList: any = [];

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'name';
  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _policyService: PolicyService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private translate: TranslateService
  ) { }

  ngOnInit(): void {
    this._setPreData();
    this._fetchDataAndPopulate();
  }

  private _setPreData() {
    this.policyGroupArr.push(
      {
        "name": this.translate.instant("LBL_AZT_NEW_DEVICE"),
        "data": {
          "columnKeyName": [
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_NAME')
            },
            {
              colKey: 'modified',
              colKeyLabel: this.translate.instant('LBL_AZT_MODIFIED_DATE')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_ACTION')
            },

          ],
          "value": []
        }
      });
    this.getPolicyUrl();
    this.groupByList = [
      { name: 'Policy Group Type' },
      { name: 'Policy Group Status' },
      { name: 'On/Off' },
      { name: 'Policy Category' },
      { name: 'Policy Group Mode' },
      { name: 'Policy Group Function' },
    ];

  }

  getPolicyUrl() {
    this.policyName = this._route.snapshot.queryParams['policyName'];
    switch (this.policyName) {
      case ProtectionPolicy.PROTECTION_POLICIES:
        this.policyBlankUrl = '/policy-group/protection-policy';
        break;
    }
  }

  navigateUrl() {
    this._policyService.frmAdvanceSetting = false;
    this._router.navigate(['policy-group-wizard'], { queryParams: { policyName: PolicyNav.POLICY_GROUPS } });
    // this._router.navigate(['policy'], { queryParams: { policyName: ProtectionNav.PROTECTION_POLICIES } });
  }

  redirectToBlankPolicy(id: any, name: string) {
    this._router.navigate(['/policy-group/general'], { queryParams: {policyName: PolicyNav.POLICY_GROUPS,isPolicyInstallWizard: true, policyGrpid: id } });
  }


  showSortArrow(queryParamKey: string | undefined): boolean {
    return queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-');
  }

  sortTableCol(queryParamKey: string | undefined) {
    if (queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-')) {
      this.sortParamKey = queryParamKey;
    } else {
      this.sortParamKey = '-' + queryParamKey;
    }
    this.globalPageNumber = 1;
    if (this.isScrollDisable) this.isScrollDisable = false;
    this.policyGroupArr[0]['data']['value'] = [];
    this._fetchDataAndPopulate();
  }

  onScrollDown() {
    console.log('scroll');
    this._fetchDataAndPopulate();
  }

  private _setPaginationConfig(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());
    let filterQueryParams = {};
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    let sortQueryParams = {
      ordering: this.sortParamKey
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  private _fetchDataAndPopulate() {
    this._ngxLoader.start();
    let deviceQueryParams = this._setPaginationConfig();
    this._policyService.getPolicyGroupsWithQueryApi(deviceQueryParams).subscribe(res => {
      this._ngxLoader.stop();
      if (res && res['count'] !== 0 && res['results'].length !== 0) {
        this.policyGroupArr[0]['data']['value'].push(...res['results']);
        this.totalRecords = res['count'];
        if (this.totalRecords === this.policyGroupArr[0]['data']['value'].length) {
          this.isScrollDisable = true;
        }
        this.globalPageNumber += 1;

      }
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {

        this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
      }
    });
  }
}
