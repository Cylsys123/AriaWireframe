import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyGroupComponent } from './policy-group.component';

describe('PolicyGroupComponent', () => {
  let component: PolicyGroupComponent;
  let fixture: ComponentFixture<PolicyGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyGroupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
