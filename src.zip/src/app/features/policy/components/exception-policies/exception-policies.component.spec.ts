import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExceptionPoliciesComponent } from './exception-policies.component';

describe('ExceptionPoliciesComponent', () => {
  let component: ExceptionPoliciesComponent;
  let fixture: ComponentFixture<ExceptionPoliciesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExceptionPoliciesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExceptionPoliciesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
