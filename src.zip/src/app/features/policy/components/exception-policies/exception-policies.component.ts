import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-exception-policies',
  templateUrl: './exception-policies.component.html',
  styleUrls: ['./exception-policies.component.css']
})
export class ExceptionPoliciesComponent implements OnInit {
  url: any = "exception-policy"
  constructor(private _router: Router, private _sharedService: SharedService) { }

  ngOnInit(): void {
    // this.sendNewData('exception-policy');
  }

  navigateUrl() {

    this._router.navigate(['policy-group-wizard'], { queryParams: { policyName: PolicyNav.EXCEPTION_POLICIES } });
  }
}
