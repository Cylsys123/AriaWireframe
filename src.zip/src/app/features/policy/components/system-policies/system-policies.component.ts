import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-system-policies',
  templateUrl: './system-policies.component.html',
  styleUrls: ['./system-policies.component.css']
})
export class SystemPoliciesComponent implements OnInit {

  constructor(private _router: Router, private _sharedService: SharedService) { }

  ngOnInit(): void {
  }

  navigateUrl() {

    this._router.navigate(['policy-group-wizard'], { queryParams: { policyName: PolicyNav.SYSTEM_POLICIES } });
  }


}
