import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyMainComponent } from './policy-main.component';

describe('PolicyMainComponent', () => {
  let component: PolicyMainComponent;
  let fixture: ComponentFixture<PolicyMainComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PolicyMainComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicyMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
