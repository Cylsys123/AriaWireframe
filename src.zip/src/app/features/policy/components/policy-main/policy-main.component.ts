import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-main',
  templateUrl: './policy-main.component.html',
  styleUrls: ['./policy-main.component.css']
})
export class PolicyMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
