import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { ExceptionPoliciesComponent } from './components/exception-policies/exception-policies.component';
import { MiscellaneusPoliciesComponent } from './components/miscellaneus-policies/miscellaneus-policies.component';
import { NotificationPoliciesComponent } from './components/notification-policies/notification-policies.component';
import { ApplyExclusionComponent } from './components/policy-group-wizard/apply-exclusion/apply-exclusion.component';
import { BaseProtectionServerComponent } from './components/policy-group-wizard/base-protection-server/base-protection-server.component';
import { BlankWizardConfigurationCompleteComponent } from './components/policy-group-wizard/blank-wizard-configuration-complete/blank-wizard-configuration-complete.component';
import { ConfigSecretQuestionComponent } from './components/policy-group-wizard/config-secret-question/config-secret-question.component';
import { ConfigurationCompleteComponent } from './components/policy-group-wizard/configuration-complete/configuration-complete.component';
import { DeviceGroupsComponent } from './components/policy-group-wizard/device-groups/device-groups.component';
import { ExceptionPolicyComponent } from './components/policy-group-wizard/exception-policy/exception-policy.component';
import { GeneralPolicyComponent } from './components/policy-group-wizard/general-policy/general-policy.component';
import { MiscellaneusPolicyComponent } from './components/policy-group-wizard/miscellaneus-policy/miscellaneus-policy.component';
import { NotificationPolicyComponent } from './components/policy-group-wizard/notification-policy/notification-policy.component';
import { PolicyAdvanceSettingsComponent } from './components/policy-group-wizard/policy-advance-settings/policy-advance-settings.component';
import { PolicyWizardGroupComponent } from './components/policy-group-wizard/policy-wizard-group/policy-wizard-group.component';
import { PolicyWizardMainComponent } from './components/policy-group-wizard/policy-wizard-main/policy-wizard-main.component';
import { PropertiesComponent } from './components/policy-group-wizard/properties/properties.component';
import { ProtectionModeComponent } from './components/policy-group-wizard/protection-mode/protection-mode.component';
import { ProtectionPolicyComponent } from './components/policy-group-wizard/protection-policy/protection-policy.component';
import { ServerExceptionsComponent } from './components/policy-group-wizard/server-exceptions/server-exceptions.component';
import { SourcePolicyComponent } from './components/policy-group-wizard/source-policy/source-policy.component';
import { SystemPolicyComponent } from './components/policy-group-wizard/system-policy/system-policy.component';
import { PolicyGroupComponent } from './components/policy-group/policy-group.component';
import { PolicyMainComponent } from './components/policy-main/policy-main.component';
import { ProtectionPoliciesComponent } from './components/protection-policies/protection-policies.component';
import { SystemPoliciesComponent } from './components/system-policies/system-policies.component';

const routes: Routes = [
  {
    path: 'policy',
    canActivate: [AuthGuard],
    component: PolicyMainComponent,
    children: [
      { path: '', component: PolicyGroupComponent },
      { path: 'protection-policy', component: ProtectionPoliciesComponent },
      { path: 'exception-policies', component: ExceptionPoliciesComponent },
      { path: 'notification-policies', component: NotificationPoliciesComponent },
      { path: 'miscellaneous-policies', component: MiscellaneusPoliciesComponent },
      { path: 'system-policies', component: SystemPoliciesComponent },
      { path: '**', redirectTo: '/policy', pathMatch: 'full' },
    ]
  },

  { path: 'policy-group-wizard', component: PolicyWizardGroupComponent },
  { path: 'apply-exclusion', component: ApplyExclusionComponent },
  { path: 'config-secret-question', component: ConfigSecretQuestionComponent },
  { path: 'blank-wizard-configuration-complete', component: BlankWizardConfigurationCompleteComponent },
  {
    path: 'policy-group',
    canActivate: [AuthGuard],
    component: PolicyWizardMainComponent,
    children: [
      { path: 'source-policy', component: SourcePolicyComponent },
      { path: 'general', component: GeneralPolicyComponent },
      { path: 'protection-mode', component: ProtectionModeComponent },
      { path: 'protection-policy', component: ProtectionPolicyComponent },
      { path: 'exception-policy', component: ExceptionPolicyComponent },
      { path: 'notification-policy', component: NotificationPolicyComponent },
      { path: 'system-policy', component: SystemPolicyComponent },
      { path: 'miscellaneous-policy', component: MiscellaneusPolicyComponent },
      { path: 'configuration-complete', component: ConfigurationCompleteComponent },
      { path: 'device-groups', component: DeviceGroupsComponent },
      { path: 'server-exceptions', component: ServerExceptionsComponent },
      { path: 'base-protection-server', component: BaseProtectionServerComponent },
      { path: 'properties', component: PropertiesComponent },
      { path: 'advanceSetting', component: PolicyAdvanceSettingsComponent },

      { path: '**', redirectTo: '/policy-group', pathMatch: 'full' },
    ]
  },

  {
    path: 'protection-policies',
    canActivate: [AuthGuard],
    component: PolicyWizardMainComponent,
    children: [
      { path: 'source-policy', component: SourcePolicyComponent },
      { path: 'general', component: GeneralPolicyComponent },
      { path: 'protection-mode', component: ProtectionModeComponent },
      { path: 'properties', component: PropertiesComponent },
      { path: '**', redirectTo: '/policy', pathMatch: 'full' },
    ]
  },

  {
    path: 'exception-policies',
    canActivate: [AuthGuard],
    component: PolicyWizardMainComponent,
    children: [
      { path: 'source-policy', component: SourcePolicyComponent },
      { path: 'general', component: GeneralPolicyComponent },
      { path: 'properties', component: PropertiesComponent },
      { path: '**', redirectTo: '/policy', pathMatch: 'full' },
    ]
  },

  {
    path: 'notification-policies',
    canActivate: [AuthGuard],
    component: PolicyWizardMainComponent,
    children: [
      { path: 'source-policy', component: SourcePolicyComponent },
      { path: 'general', component: GeneralPolicyComponent },
      { path: 'properties', component: PropertiesComponent },
      { path: '**', redirectTo: '/policy', pathMatch: 'full' },
    ]
  },

  {
    path: 'system-policies',
    canActivate: [AuthGuard],
    component: PolicyWizardMainComponent,
    children: [
      { path: 'source-policy', component: SourcePolicyComponent },
      { path: 'general', component: GeneralPolicyComponent },
      { path: 'properties', component: PropertiesComponent },
      { path: '**', redirectTo: '/policy', pathMatch: 'full' },
    ]
  },

  { path: 'configuration-complete', component: ConfigurationCompleteComponent },

  // {
  //   path: 'protection-policy',
  //   component: PolicyWizardMainComponent,
  //   children: [
  //     { path: 'advanceSetting', component: PolicyAdvanceSettingsComponent },
  //     { path: '**', redirectTo: '/policy-group', pathMatch: 'full' },
  //   ]
  // },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PolicyRoutingModule { }
