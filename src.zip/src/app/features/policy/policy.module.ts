import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PolicyRoutingModule } from './policy-routing.module';
import { PolicyGroupComponent } from './components/policy-group/policy-group.component';
import { PolicyMainComponent } from './components/policy-main/policy-main.component';
import { InnerSidebarComponent } from 'src/app/shared/components/inner-sidebar/inner-sidebar.component';
import { ProtectionPoliciesComponent } from './components/protection-policies/protection-policies.component';
import { HomeModule } from '../home/home.module';
import { NotificationPoliciesComponent } from './components/notification-policies/notification-policies.component';
import { MiscellaneusPoliciesComponent } from './components/miscellaneus-policies/miscellaneus-policies.component';
import { SystemPoliciesComponent } from './components/system-policies/system-policies.component';
import { ExceptionPoliciesComponent } from './components/exception-policies/exception-policies.component';
import { PostInstallWizardModule } from '../post-install-wizard/post-install-wizard.module';
import { PolicyWizardMainComponent } from './components/policy-group-wizard/policy-wizard-main/policy-wizard-main.component';
import { PolicyWizardGroupComponent } from './components/policy-group-wizard/policy-wizard-group/policy-wizard-group.component';
import { PropertiesComponent } from './components/policy-group-wizard/properties/properties.component';
import { ServerExceptionsComponent } from './components/policy-group-wizard/server-exceptions/server-exceptions.component';
import { ApplyExclusionComponent } from './components/policy-group-wizard/apply-exclusion/apply-exclusion.component';
import { ConfigSecretQuestionComponent } from './components/policy-group-wizard/config-secret-question/config-secret-question.component';
import { TranslateModule } from '@ngx-translate/core';
import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';
import { BaseProtectionServerComponent } from './components/policy-group-wizard/base-protection-server/base-protection-server.component';
import { BlankWizardConfigurationCompleteComponent } from './components/policy-group-wizard/blank-wizard-configuration-complete/blank-wizard-configuration-complete.component';
import { ConfigurationCompleteComponent } from './components/policy-group-wizard/configuration-complete/configuration-complete.component';
import { DeviceGroupsComponent } from './components/policy-group-wizard/device-groups/device-groups.component';
import { GeneralPolicyComponent } from './components/policy-group-wizard/general-policy/general-policy.component';
import { NotificationPolicyComponent } from './components/policy-group-wizard/notification-policy/notification-policy.component';
import { ProtectionModeComponent } from './components/policy-group-wizard/protection-mode/protection-mode.component';
import { ProtectionPolicyComponent } from './components/policy-group-wizard/protection-policy/protection-policy.component';
import { SourcePolicyComponent } from './components/policy-group-wizard/source-policy/source-policy.component';
import { SystemPolicyComponent } from './components/policy-group-wizard/system-policy/system-policy.component';
import { MiscellaneusPolicyComponent } from './components/policy-group-wizard/miscellaneus-policy/miscellaneus-policy.component';
import { ExceptionPolicyComponent } from './components/policy-group-wizard/exception-policy/exception-policy.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { PolicyAdvanceSettingsComponent } from './components/policy-group-wizard/policy-advance-settings/policy-advance-settings.component';

@NgModule({
  declarations: [
    PolicyGroupComponent,
    PolicyMainComponent,
    InnerSidebarComponent,
    ProtectionPoliciesComponent,
    NotificationPoliciesComponent,
    MiscellaneusPoliciesComponent,
    SystemPoliciesComponent,
    ExceptionPoliciesComponent,
    PolicyWizardMainComponent,
    PolicyWizardGroupComponent,
    PropertiesComponent,
    ServerExceptionsComponent,
    ApplyExclusionComponent,
    ConfigSecretQuestionComponent,
    SystemPolicyComponent,
    BlankWizardConfigurationCompleteComponent,
    ConfigurationCompleteComponent,
    DeviceGroupsComponent,
    GeneralPolicyComponent,
    NotificationPolicyComponent,
    ProtectionModeComponent,
    ProtectionPolicyComponent,
    SourcePolicyComponent,
    SystemPolicyComponent,
    MiscellaneusPolicyComponent,
    ExceptionPolicyComponent,
    BaseProtectionServerComponent,
    PolicyAdvanceSettingsComponent
  ],
  imports: [
    CommonModule,
    PolicyRoutingModule,
    HomeModule,
    PostInstallWizardModule,
    TranslateModule,
    SharedLazyModule,
    FormsModule,
    InfiniteScrollModule,
    ReactiveFormsModule
  ],
  exports: [InnerSidebarComponent]
})
export class PolicyModule { }
