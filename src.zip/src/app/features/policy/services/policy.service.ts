import { Injectable } from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {

  policyGroupFormValues:object;
  checkClonedPolicySubject = new Subject();
  policyGrpName: string = "";

  simplePolicyObj = {};
  counterMeasurePolicy = {};
  frmAdvanceSetting : boolean = false;

  constructor(
    private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService
  ) { 
    this._setDefaultValuePolicyGroupForm();
  }

   //dashboard/policygroup/
   postPolicyGroupApi(policyGroupBody:object){
    return this._apiHttpService
      .post(this._apiEndpointsService.getCreatePolicyGroupEndpoint(),policyGroupBody);
  }

  //dashboard/policy/
  getPolicyWithQueryApi(queryParamsObj:Object){
    return this._apiHttpService
      .get(this._apiEndpointsService.getPolicyWithQueryParamsEndpoint(queryParamsObj));
  }

  //dashboard/counterMeasurePolicy/
  getCounterMeasureWithQueryApi(queryParamsObj:Object){
    return this._apiHttpService
      .get(this._apiEndpointsService.getCounterMeasureWithQueryParamsEndpoint(queryParamsObj));
  }

  //dashboard/policy/
  getPolicyGroupsValidateNameWithQueryApi(queryParamsObj:Object){
    return this._apiHttpService
      .get(this._apiEndpointsService.getPolicyGroupValidateNameWithQueryParamsEndpoint(queryParamsObj));
  }


  //dashboard/policygroup/
  getPolicyGroupApi(){
    return this._apiHttpService
      .get(this._apiEndpointsService.getPolicyGroupEndpoint());
  }

  //dashboard/policygroup/
  getPolicyGroupsWithQueryApi(queryParamsObjOrId:Object,isById:boolean = false){
    if(isById){
      return this._apiHttpService
      .get(this._apiEndpointsService.getPolicyGroupWithQueryParamsEndpoint({})+queryParamsObjOrId+'/');
    }else{
      return this._apiHttpService
      .get(this._apiEndpointsService.getPolicyGroupWithQueryParamsEndpoint(queryParamsObjOrId));
    }
    
  }

  //dashboard/policygroup/
  putPolicyGroupsWithQueryApi(queryParamsObjOrID:any,policyGroupBody:object,isById:boolean = false){
    if(isById){
      return this._apiHttpService
      .put(this._apiEndpointsService.getPolicyGroupWithQueryParamsEndpoint({})+queryParamsObjOrID+'/',policyGroupBody);
    }else{
      return this._apiHttpService
      .put(this._apiEndpointsService.getPolicyGroupWithQueryParamsEndpoint(queryParamsObjOrID),policyGroupBody);
    }
    
  }

  //dashboard/policygroup/temporary
  postPolicyGroupsTempWithQueryApi(queryParamsObj:Object){
    return this._apiHttpService
      .get(this._apiEndpointsService.getPolicyGroupTempWithQueryParamsEndpoint(queryParamsObj));
  }

  //dashboard/policygroup/?id=5
  getPolicyGroupByIdApi(policyGrpId){
    return this._apiHttpService
      .get(this._apiEndpointsService.getPolicyGroupByIdEndpoint(policyGrpId));
  }

  //dashboard/policy/
  postPolicyApi(id:any,policyGroupBody:object){
    return this._apiHttpService
      .put(this._apiEndpointsService.getPolicyEndpoint(id),policyGroupBody);
  }

  //dashboard/policygroup/
  postCounterMeasurePolicyApi(id:any,policyGroupBody:object){
    return this._apiHttpService
      .put(this._apiEndpointsService.getCounterMeasurePolicyEndpoint(id),policyGroupBody);
  }

  private _setDefaultValuePolicyGroupForm(){
    
    this.policyGroupFormValues = {
      policyGroupSourceTabFormValue:{
        selectedPolicyGroupId:0
      },
      policyGroupGeneralTabFormValue:{
        policyGroupname:'',
        description:'',
        iconLabel:'',
        iconColor:'#ff0000',
      },
      policyGroupProtectionTabFormValue:{
        
      },
      isPolicyGroupCloned:false
    }
  }
  
}
