import { formatDate } from '@angular/common';
import { Injectable } from '@angular/core';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  currentDate = formatDate(new Date(), 'YYYY-MM-dd HH:MM', 'en-US') + 'Z';

  constructor(
    private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService,
  ) { }


  //dashboard/device/
  getNewDeviceApi() {
    return this._apiHttpService
      // .get(this._apiEndpointsService.getNewDeviceEndpoint(this.currentDate));
      .get(this._apiEndpointsService.getDeviceEndpoint());
  }

  getDashboardDevicesApi(queryParamsObj) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDeviceWithQueryParamsEndpoint(queryParamsObj));
  }


  //dashboard/alert/list
  getAlertListApi() {
    return this._apiHttpService
      // .get(this._apiEndpointsService.getAlertEndpoint(this.currentDate));
      .get(this._apiEndpointsService.getNotificationEndpoint());
  }

  getDashboardAlertListApi(queryParamsObj) {
    return this._apiHttpService
      // .get(this._apiEndpointsService.getAlertEndpoint(this.currentDate));
      .get(this._apiEndpointsService.getNotificationWithQueryParamsEndpoint(queryParamsObj));
  }

  getAlertCategoryAPI() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getNotificationCatEndpoint());
  }

  getAlertStatusApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getNotificationStatusEndpoint());
  }

  getDeviceGroupApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDeviceGroupEndpoint());
  }

  getNewlyDiscoveredAppsApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getInventoryAppWithQueryParamsEndpoint({}));
  }
}
