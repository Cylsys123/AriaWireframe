import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { LoggedInAuthGuard } from 'src/app/core/guards/logged-in-auth.guard';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HomeMainComponent } from './components/home-main/home-main.component';

const routes: Routes = [
  {
    path: '', 
    component: HomeMainComponent,
    canActivate: [AuthGuard],
    children:[
      {path:'dashboard', component:DashboardComponent},
      {path:'', redirectTo:'/home/dashboard', pathMatch:'full'}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
