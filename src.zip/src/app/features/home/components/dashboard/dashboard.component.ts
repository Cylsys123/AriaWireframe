import { Component, OnInit } from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { forkJoin, Observable } from 'rxjs';
import { SharedService } from 'src/app/shared/services/shared.service';
import { HomeService } from '../../services/home.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  totalDataDisplay: number = 7;
  newDeviceAlert: any = [];
  latestAlertArrList: any = [];
  widgetInputObj: object[];

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  filterParams: any = {};
  sortParamKey: string = 'name';
  sortParamKey1: string = 'host_name';
  constructor(
    private _homeService: HomeService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService
  ) { }

  ngOnInit(): void {
    this._dashBoardEndPoint();
  }

  private _dashBoardEndPoint() {
    //start loader
    this._ngxLoader.start();
    this._getDashboardData().subscribe((res) => {
      this.widgetInputObj = [
        {
          type: 'larage',
          name: 'device',
          data: res[0]
        },
        {
          type: 'larage',
          name: 'alert',
          data: res[1].results
        },
        {
          type: 'larage',
          name: 'apps',
          data: res[5].results
        },
        {
          type: 'fullscreen',
          name: 'deviceGroup',
          data: res[4].results
        }
      ];

      localStorage.setItem('alertCategory', JSON.stringify(res[2]));
      localStorage.setItem('alertStatus', JSON.stringify(res[3]));

      this._ngxLoader.stop();
    }, (err) => {
      console.log(err);
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Dashboard', 'error');
    })
  }

  private _getDashboardData(): Observable<any> {
    let deviceQueryParams = this.setPaginationConfig();
    let alertQueryParams = this.setAlertPaginationConfig();
    const newDevice = this._homeService.getDashboardDevicesApi(deviceQueryParams);
    const alertList = this._homeService.getDashboardAlertListApi(alertQueryParams);
    const alertCategory = this._homeService.getAlertCategoryAPI();
    const alertStatus = this._homeService.getAlertStatusApi();
    const deviceGroup = this._homeService.getDeviceGroupApi();
    const inventoryApps = this._homeService.getNewlyDiscoveredAppsApi();
    return forkJoin([newDevice, alertList, alertCategory, alertStatus, deviceGroup, inventoryApps]);
  }

  refreshList() {
    this._dashBoardEndPoint();
  }

  setPaginationConfig(): object {
    let sortQueryParams = {
      ordering: this.sortParamKey
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...sortQueryParams, ...paginationQueryParams };
  }

  setAlertPaginationConfig(): object {
    let sortQueryParams = {
      ordering: this.sortParamKey1
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...sortQueryParams, ...paginationQueryParams };
  }

}
