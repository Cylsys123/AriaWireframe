import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HomeMainComponent } from './components/home-main/home-main.component';
import { LeftSidebarComponent } from 'src/app/shared/components/left-sidebar/left-sidebar.component';
import { MenuListComponent } from 'src/app/shared/components/left-sidebar/menu-list/menu-list.component';
import { HeaderComponent } from 'src/app/shared/components/header/header.component';
import { CarouselComponent } from 'src/app/shared/components/left-sidebar/carousel/carousel.component';
import { RightNotificationbarComponent } from 'src/app/shared/components/right-notificationbar/right-notificationbar.component';
import { WidgetsComponent } from 'src/app/shared/components/widgets/widgets.component';
import { SmallWidgetsComponent } from 'src/app/shared/components/widgets/small-widgets/small-widgets.component';
import { MediumWidgetsComponent } from 'src/app/shared/components/widgets/medium-widgets/medium-widgets.component';
import { LargeWidgetsComponent } from 'src/app/shared/components/widgets/large-widgets/large-widgets.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';
import { RightFilterComponent } from 'src/app/shared/components/right-filter/right-filter.component';
import { FullscreenWidgetsComponent } from 'src/app/shared/components/widgets/fullscreen-widgets/fullscreen-widgets.component';
import { ClearHistoryComponent } from 'src/app/shared/models/clear-history/clear-history.component';
import { ImagePriviewComponent } from 'src/app/shared/models/image-priview/image-priview.component';
import { ColumnChartComponent } from 'src/app/shared/components/widgets/column-chart/column-chart.component';
import { ChartsModule } from 'ng2-charts';

@NgModule({
  declarations: [
    DashboardComponent,
    HomeMainComponent,
    LeftSidebarComponent,
    MenuListComponent,
    HeaderComponent,
    CarouselComponent,
    RightNotificationbarComponent,
    WidgetsComponent,
    SmallWidgetsComponent,
    MediumWidgetsComponent,
    LargeWidgetsComponent,
    RightFilterComponent,
    FullscreenWidgetsComponent,
    ClearHistoryComponent,
    ImagePriviewComponent,
    ColumnChartComponent,
    ColumnChartComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    DragDropModule,
    SharedLazyModule,
    ChartsModule
  ],
  exports: [LeftSidebarComponent, HeaderComponent, RightNotificationbarComponent, RightFilterComponent, ClearHistoryComponent, ImagePriviewComponent]
})
export class HomeModule { }
