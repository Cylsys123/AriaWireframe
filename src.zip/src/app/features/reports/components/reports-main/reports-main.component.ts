import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports-main',
  templateUrl: './reports-main.component.html',
  styleUrls: ['./reports-main.component.css']
})
export class ReportsMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
