import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { ReportsService } from '../../services/reports.service';

@Component({
  selector: 'app-default-reports',
  templateUrl: './default-reports.component.html',
  styleUrls: ['./default-reports.component.css']
})
export class DefaultReportsComponent implements OnInit {

  rptCriteria : boolean = false;
  rptSummary : boolean = false;
  group_Id : string;
  defaultReportData : any;
  reportForm : FormGroup;
  generatedreportData : any;
  fileData : string;

  constructor(
    private _ngxLoader: NgxUiLoaderService,
    private _reportService: ReportsService,
    private _sharedService : SharedService,
    private _router : Router,
    private fb: FormBuilder
  ) { }



  ngOnInit(): void {

    this.getDefaultReport();

    this.generateReportForm();

    let date = new Date();
    this.fileData =
    ("00" + (date.getMonth() + 1)).slice(-2) + "-" +
    ("00" + date.getDate()).slice(-2) + "-" +
    date.getFullYear() + "_" +
    ("00" + date.getHours()).slice(-2) + ":" +
    ("00" + date.getMinutes()).slice(-2) + ":" +
    ("00" + date.getSeconds()).slice(-2);

}

  generateReportForm() {
    this.reportForm = this.fb.group({     
      reportType_Id:[null,[Validators.required]], 
      reportCriteria:[false],     
      reportSummary:[false], 
      groupBy:['',[Validators.required]],     
      reportOn:[null,[Validators.required]], 
      period : [null,[Validators.required]]
    });
  }

  changeCriteria(evt){
    this.reportForm.value.reportCriteria = evt.target.checked;
  }

  changeSummary(evt){
    this.reportForm.value.reportSummary = evt.target.checked;
  }

  getDefaultReport(){
    this._ngxLoader.start();
    this._reportService.getReportGroupsApi().subscribe(res=>{

      this._ngxLoader.stop();

      this.defaultReportData = res['results'][0];

      this.group_Id = this.defaultReportData.id;
    },(err)=>{
      console.log("Error",err);
      this._ngxLoader.stop();
    });
  }

  changeGrpBy(evt){
    this.reportForm.value.groupBy = evt.target.value;
  }

  changeRptOn(evt){
    this.reportForm.value.report_on = evt.target.value;
  }

  changeRptTypeOptions(evt){
    this.reportForm.value.report_type = evt.target.value;
  }

  changePeriod(evt){
    this.reportForm.value.period = evt.target.value;
  }



  onSubmit(form){

    this._ngxLoader.start();

    let body = {
      "group": this.group_Id,
      "report_type": this.reportForm.value.reportType_Id,
      "include_criteria": this.reportForm.value.reportCriteria,
      "include_summary": this.reportForm.value.reportSummary,
      "group_by": this.reportForm.value.groupBy,
      "report_on": this.reportForm.value.reportOn,
      "period": this.reportForm.value.period,
      "filename" : this.fileData
    }

    console.log("Body",body);

    this._reportService.generateReportApi(body).subscribe(res=>{
      this._ngxLoader.stop();
      this.generatedreportData = res;

    },(err)=>{      
        console.log("Error",err);
        this._ngxLoader.stop();
        if (err.status == 403) {
          this._sharedService.getToastPopup(err.error['detail'], 'AZT Report', 'error');
        }
        else if (err.status == 400) {
          this._sharedService.getToastPopup(err.error['name'], 'AZT Report', 'error');
        }
        else {
          this._sharedService.getToastPopup('Internal server error', 'AZT Report', 'error');
        }
    });
  }

  onContinue(){
    this._sharedService.getToastPopup('Report generated successfully','AZT Report', 'success');
    this._router.navigate(['/reports/reportsActivity']);
  }

}
