import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultReportsComponent } from './default-reports.component';

describe('DefaultReportsComponent', () => {
  let component: DefaultReportsComponent;
  let fixture: ComponentFixture<DefaultReportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefaultReportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
