import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject, timer } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { NotificationService } from 'src/app/features/notification/services/notification.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { ReportsService } from '../../services/reports.service';

@Component({
  selector: 'app-reports-activity',
  templateUrl: './reports-activity.component.html',
  styleUrls: ['./reports-activity.component.css']
})
export class ReportsActivityComponent implements OnInit {
  @ViewChild('delete_report') delete_report: any;
  sortParamKey: string = 'report_type';
  isDisabled: boolean = false;
  selectedAlert = [];
  alertList: any = [];

  objectKeys = Object.keys;
  reportsArr: any = [];
  groupByList: any = [];

  expanded: { [key: string]: boolean } = {};

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  filterParams: any = {};
  fileData : string;

  generatedreportData : any;
  cancelled_Report: { group: any; report_type: any; include_criteria: any; include_summary: any; group_by: any; report_on: any; period: any; filename: any; };
  grp_id: any;
  
  reportSubject: any;  
  destroy = new Subject();
  rxjsTimer = timer(30000, 10000);
  currentPage: number;
  report_Id: any;
  showModalBox: boolean = false;
  display: string = 'none';

  constructor(
    private translate: TranslateService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private _router: Router,
    private _reportService: ReportsService
  ) { }

  async ngOnInit() {
    this._setPreData();
    this._fetchDataAndPopulate();

    let date = new Date();
    this.fileData =
    ("00" + (date.getMonth() + 1)).slice(-2) + "/" +
    ("00" + date.getDate()).slice(-2) + "/" +
    date.getFullYear() + " " +
    ("00" + date.getHours()).slice(-2) + ":" +
    ("00" + date.getMinutes()).slice(-2) + ":" +
    ("00" + date.getSeconds()).slice(-2);
  }


  private _setPreData() {
    this.reportsArr.push(
      {
        "name": this.translate.instant("LBL_AZT_ALERT"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_REPORT_STATUS')
            },
            {
              colKey: 'group',
              colKeyLabel: this.translate.instant('LBL_AZT_REPORT_NAME')
            },
            {
              colKey: 'generated_at',
              colKeyLabel: this.translate.instant('LBL_AZT_DATE_TIME_REQUESTED')
            },
            {
              colKey: 'completed_at',
              colKeyLabel: this.translate.instant('LBL_AZT_DATE_TIME_COMPLETED')
            },
            {
              colKey: 'generated_by',
              colKeyLabel: this.translate.instant('LBL_AZT_REQUEST_BY')
            },
            {
              colKey: 'report_file',
              colKeyLabel: this.translate.instant('LBL_AZT_REQUEST_LOCATION')
            },
            {
              colKey: 'period',
              colKeyLabel: this.translate.instant('LBL_AZT_REQUEST_PERIOD')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_ACTION')
            },

          ],
          "value": []
        }
      });

    this.groupByList = [
      { name: 'All' },
      { name: 'Device group' },
      { name: 'Device type' },
      { name: 'Nofification' },
      { name: 'Alert' },
      { name: 'Valnerabilities' },
      { name: 'Policies' },
      { name: 'Integration' }
    ];

    this.alertList = [
      { name: 'Delete Report', isDisabled: false, code: "Delete" },
      { name: 'Cancel Report', isDisabled: false, code: "Cancel" },
      { name: 'Export to CSV', isDisabled: false, code: "Export" },
      // { name: 'Email report', isDisabled: true, code: "Email" },
      // { name: 'Clone report', isDisabled: true, code: "Clone" },
      // { name: 'Updated report settings', isDisabled: true, code: "Updated" },
    ];
  }


  showSortArrow(queryParamKey: string | undefined): boolean {
    return queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-');
  }

  sortTableCol(queryParamKey: string | undefined) {
    if (queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-')) {
      this.sortParamKey = queryParamKey;
    } else {
      this.sortParamKey = '-' + queryParamKey;
    }
    this.globalPageNumber = 1;
    if (this.isScrollDisable) this.isScrollDisable = false;
    this.reportsArr[0]['data']['value'] = [];
    this._fetchDataAndPopulate();
  }

  onScrollDown() {
    this._fetchDataAndPopulate();
  }

  private _setPaginationConfig(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());
    let filterQueryParams = this.filterParams;
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    let sortQueryParams = {
      ordering: this.sortParamKey
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  private _setPaginationConfigTimer(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());
    let filterQueryParams = this.filterParams;
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    let sortQueryParams = {
      ordering: this.sortParamKey
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber-1
    };

    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  private _fetchDataAndPopulate() {
    this._ngxLoader.start();
    let rptQueryParams = this._setPaginationConfig();
    this._reportService.getReportsListQueryApi(rptQueryParams).subscribe(res => {
      this._ngxLoader.stop();

      if (res && res['count'] !== 0 && res['results'].length !== 0) {
        this.reportsArr[0]['data']['value'].push(...res['results']);
        this.totalRecords = res['count'];
        if (this.totalRecords === this.reportsArr[0]['data']['value'].length) {
          this.isScrollDisable = true;
        }

        // for (let index = 0; index < this.reportsArr[0]['data']['value'].length; index++) {
        //   this.reportsArr[0]['data']['value'][index].status = 'in-progress';          
        // }
        this.globalPageNumber += 1;
        

        this.reportSubject = this.rxjsTimer.pipe(takeUntil(this.destroy)).subscribe(val => {
          for (let index = 0; index < this.globalPageNumber-1; index++) {
            this._fetchDataAndPopulateTimer()            
          }
          
        });

      }
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Notification', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Notification', 'error');
      }
    });
  }

  ngOnDestroy(){
    this.destroy.next();
    this.destroy.complete();    
  }

  private _fetchDataAndPopulateTimer() {
    
    this._ngxLoader.start();
    let rptQueryParams = this._setPaginationConfigTimer();
    this._reportService.getReportsListQueryApi(rptQueryParams).subscribe(res => {
      this._ngxLoader.stop();
      this.reportsArr[0]['data']['value'] = []
      if (res && res['count'] !== 0 && res['results'].length !== 0) {
        this.reportsArr[0]['data']['value'].push(...res['results']);
        this.totalRecords = res['count'];
        if (this.totalRecords === this.reportsArr[0]['data']['value'].length) {
          this.isScrollDisable = true;
        }        
      }
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Notification', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Notification', 'error');
      }
    });
  }
  //value.status == 'failed'? 'disabled-file': value.status == 'cancelled'? 'disabled-file': value.status == 'completed'? 'disabled-file' : 'enable-file'
  getRecordStatus(status, type) {
    let className ="";
    switch (status) {
      case 'completed':
        className = type == 1 ? 'enable-file' : 'auto'
        break;
      default:
        className = type == 1 ? 'disabled-file' : 'none'
        break;
    }
    return className;
  }

  changeReportStatus(value: any, obj: any) {
   
    // console.log("Value",value);
    // console.log("Object",obj);
    this.grp_id = obj.id;
    if (value.code == 'Cancel') {
      this.cancelled_Report = {
        "group": obj.id,
        "report_type": obj.report_type['id'],
        "include_criteria": obj.include_criteria,
        "include_summary": obj.include_summary,
        "group_by": obj.group_by['id'],
        "report_on": obj.report_on['id'],
        "period": obj.period,
        "filename" : obj.filename
      }

      this._ngxLoader.start();

      this._reportService.reportCancelWithQueryApi(this.grp_id, this.cancelled_Report).subscribe(res => {
        console.log("Res", res);
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Report canceled successfully', 'AZT Report', 'success');
        this._router.navigate(['/reports/reportsActivity'])
      }, (err) => {
        console.log("Error", err);
        this._sharedService.getToastPopup('Something went wrong', 'AZT Report', 'Error')
        this._ngxLoader.stop();
      });

    }

   else if(value.code == 'Delete'){
   
    this.showModalBox = true;
    this.display='block';
    this.report_Id = obj.id;     
      this.cancelled_Report = {
        "group": obj.id,
        "report_type": obj.report_type['display_name'],
        "include_criteria": obj.include_criteria,
        "include_summary": obj.include_summary,
        "group_by": obj.group_by['display_name'],
        "report_on": obj.report_on['display_name'],
        "period": obj.period,
        "filename" : obj.filename
      }
    }
  }


  downloadReport(file) {
    let downloadFile = file;
    if (downloadFile == undefined || downloadFile == null || downloadFile == "") {
      this._sharedService.getToastPopup('Something went wrong', 'AZT Report', 'Error')
      return;
    }
    window.open(downloadFile, "_blank");
  }

  onContinue(){
    // this._sharedService.getToastPopup('Report generated successfully','AZT Report', 'success');
    // this._router.navigate(['/reports/reportsActivity']);
    
    this._ngxLoader.start();

      this._reportService.reportCancelWithQueryApi(this.grp_id, this.cancelled_Report).subscribe(res => {
        console.log("Res", res);
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Report canceled successfully', 'AZT Report', 'success');
        // this._fetchDataAndPopulate();
        // this.cancelled_Report = {};
      }, (err) => {
        console.log("Error", err);
        this._sharedService.getToastPopup('Something went wrong', 'AZT Report', 'Error')
        this._ngxLoader.stop();
      });
  }

  deleteReport(){
    this._ngxLoader.start();

    this._reportService.deleteReports(this.report_Id).subscribe(res=>{
      console.log("Res", res);
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Report Deleted successfully', 'AZT Report', 'success');
      this.display = 'none'
      setTimeout(() => {
        this._fetchDataAndPopulateTimer()
      }, 3000);
      
    },(err) => {
      console.log("Error", err);
      this._sharedService.getToastPopup('Something went wrong', 'AZT Report', 'Error')
      this._ngxLoader.stop();
    });
  }

}
