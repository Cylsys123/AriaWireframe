import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsActivityComponent } from './reports-activity.component';

describe('ReportsActivityComponent', () => {
  let component: ReportsActivityComponent;
  let fixture: ComponentFixture<ReportsActivityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsActivityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
