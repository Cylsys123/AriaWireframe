import { Injectable } from '@angular/core';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {

  constructor(private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService) { }

  //reports/
  getReportGroupsApi(){
    return this._apiHttpService
      .get(this._apiEndpointsService.getReportGroups());
  }

  getReportsApi(){
    return this._apiHttpService
      .get(this._apiEndpointsService.generateReport());
  }


  generateReportApi(body){
    return this._apiHttpService
      .post(this._apiEndpointsService.generateReport(),body);
  }

  getReportsListQueryApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getReportslWithQueryParamsEndpoint(queryParamsObj));
  }

  reportCancelWithQueryApi(queryParamID:any,reportBody:object){
    
      return this._apiHttpService
      .post(this._apiEndpointsService.getReportslWithQueryParamsEndpoint({})+queryParamID+'/cancel/',reportBody);
    }


    deleteReports(id) {
      return this._apiHttpService.delete(this._apiEndpointsService.deleteReport(id));
    }
}
