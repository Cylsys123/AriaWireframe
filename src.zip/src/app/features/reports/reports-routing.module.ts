import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DefaultReportsComponent } from './components/default-reports/default-reports.component';
import { ReportsActivityComponent } from './components/reports-activity/reports-activity.component';
import { ReportsMainComponent } from './components/reports-main/reports-main.component';

const routes: Routes = [
  {
    path: 'reports',
    component: ReportsMainComponent,
    children: [
      // { path: '', component: PolicyGroupComponent },
      { path: 'reportsActivity', component: ReportsActivityComponent },
      { path: 'defaultReports', component: DefaultReportsComponent },
      { path: '**', redirectTo: '/reports', pathMatch: 'full' },
    ]
  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
