import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsMainComponent } from './components/reports-main/reports-main.component';
import { ReportsActivityComponent } from './components/reports-activity/reports-activity.component';
import { HomeModule } from '../home/home.module';
import { TranslateModule } from '@ngx-translate/core';
import { DefaultReportsComponent } from './components/default-reports/default-reports.component';
import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';


@NgModule({
  declarations: [
    ReportsMainComponent,
    ReportsActivityComponent,
    DefaultReportsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ReportsRoutingModule,
    TranslateModule,
    HomeModule,
    SharedLazyModule
  ]
})
export class ReportsModule { }
