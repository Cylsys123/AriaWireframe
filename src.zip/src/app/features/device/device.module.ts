import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { DeviceRoutingModule } from './device-routing.module';
import { DeviceMainComponent } from './components/device-main/device-main.component';
import { HomeModule } from '../home/home.module';
import { PostInstallWizardModule } from '../post-install-wizard/post-install-wizard.module';
import { DeviceComponent } from './components/device/device.component';
import { DeviceGroupComponent } from './components/device-group/device-group.component';
import { NewDeviceComponent } from './components/new-device/new-device.component';
import { ProtectionProfileComponent } from './components/protection-profile/protection-profile.component';
import { DeviceExceptionComponent } from './components/device-exception/device-exception.component';
import { DeviceTypeComponent } from './components/device-type/device-type.component';
import { DeviceGroupSummaryComponent } from './components/device-group-view/device-group-summary/device-group-summary.component';
import { DeviceDrillLevelComponent } from './components/device-group-view/device-drill-level/device-drill-level.component';
import { TranslateModule } from '@ngx-translate/core';
import { DeviceGroupWizardComponent } from './components/device-group-view/device-group-wizard/device-group-wizard.component';
import { GeneralDeviceComponent } from './components/device-group-view/general-device/general-device.component';
import { DeviceApplicationsComponent } from './components/device-group-view/device-applications/device-applications.component';
import { DevicesComponent } from './components/device-group-view/devices/devices.component';
import { SourceDeviceComponent } from './components/device-group-view/source-device/source-device.component';
import { DevicePolicyComponent } from './components/device-group-view/device-policy/device-policy.component';
import { DeviceProtectionModeComponent } from './components/device-group-view/device-protection-mode/device-protection-mode.component';
import { SaveSettingsComponent } from './components/device-group-view/save-settings/save-settings.component';
import { DeviceInnernavComponent } from './components/device-innernav/device-innernav.component';
import { AlertComponent } from './components/alert/alert.component';
import { HardwarePerformanceComponent } from './components/hardware-performance/hardware-performance.component';
import { ApplicationsComponent } from './components/applications/applications.component';
import { SharedLazyModule } from 'src/app/shared/shared-lazy.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { DeviceResolverService } from './services/device-resolver.service';
import { DeviceService } from './services/device.service';
import { DeviceAdvanceSettingsComponent } from './components/device-group-view/device-advance-settings/device-advance-settings.component';
@NgModule({
  declarations: [
    DeviceMainComponent,
    DeviceComponent,
    DeviceGroupComponent,
    NewDeviceComponent,
    ProtectionProfileComponent,
    DeviceExceptionComponent,
    DeviceTypeComponent,
    DeviceGroupSummaryComponent,
    DeviceDrillLevelComponent,
    DeviceGroupWizardComponent,
    GeneralDeviceComponent,
    DeviceApplicationsComponent,
    DevicesComponent,
    SourceDeviceComponent,
    DevicePolicyComponent,
    DeviceProtectionModeComponent,
    SaveSettingsComponent,
    DeviceInnernavComponent,
    AlertComponent,
    HardwarePerformanceComponent,
    ApplicationsComponent,
    DeviceAdvanceSettingsComponent
  ],
  imports: [
    CommonModule,
    DeviceRoutingModule,
    HomeModule,
    PostInstallWizardModule,
    TranslateModule,
    SharedLazyModule,
    FormsModule,
    ReactiveFormsModule,
    InfiniteScrollModule

  ],
  providers: [
    DeviceService,
    DeviceResolverService,
    DatePipe
  ]
})
export class DeviceModule { }
