import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-protection-profile',
  templateUrl: './protection-profile.component.html',
  styleUrls: ['./protection-profile.component.css']
})
export class ProtectionProfileComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }

  next() {
    this._router.navigateByUrl('/devices/device-alert');
  }
}
