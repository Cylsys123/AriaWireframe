import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProtectionProfileComponent } from './protection-profile.component';

describe('ProtectionProfileComponent', () => {
  let component: ProtectionProfileComponent;
  let fixture: ComponentFixture<ProtectionProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProtectionProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProtectionProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
