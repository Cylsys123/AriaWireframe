import { Component, OnInit } from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { SharedService } from 'src/app/shared/services/shared.service';
import { DeviceService } from '../../../services/device.service';
import { Router } from '@angular/router';
import { DeviceNav } from 'src/app/shared/enum/shared.enum';

@Component({
  selector: 'app-save-settings',
  templateUrl: './save-settings.component.html',
  styleUrls: ['./save-settings.component.css']
})
export class SaveSettingsComponent implements OnInit {

  selectedDevice: any[] = [];
  selectedOtherDevice: any[] = [];
  device_group_ID: any;

  deviceGroupname = "";
  creationDate = "";
  protectionPolicyGroup_id = "";
  protectedDevices = "";
  description = "";
  isEditGroup: boolean;
  isDefaltMsg : boolean = false;


  constructor(private _sharedService: SharedService,
    private _deviceService: DeviceService,
    private _ngxLoader: NgxUiLoaderService,
    private _router: Router,
  ) {
    this.getDevicesData();
  }

  async ngOnInit() {
    //await  this.getDevisesData();

    this._ngxLoader.start();
    setTimeout(() => {
      this._ngxLoader.stop();
    }, 1000);

    if(this._deviceService.is_defaultDevice) {
       this.isDefaltMsg = true;
    }
  }

  getDevicesData() {

    this.device_group_ID = this._sharedService._device_group_ID;
    this.selectedDevice = this._sharedService.selectedDevice;
    this.selectedOtherDevice = this._sharedService.selectedOtherDevice;

    this.deviceGroupname = this._sharedService.deviceGroupname;
    this.creationDate = this._sharedService.creationDate;
    this.protectionPolicyGroup_id = this._sharedService.protectionPolicyGroup_id;
    this.protectedDevices = this._sharedService.protectedDevices;
  
    this.description = this._sharedService.description == null ? "" : this._sharedService.description;

    this.isEditGroup = this._sharedService.isEditGroup;

  }

  async bulkRemoveDevices() {
    this._ngxLoader.start();
    // let body = {
    //   "device_group": 1,
    //   "devices": this.selectedDevice,
    // }

    // await this._deviceService.bulkUploadDeviceGroup(body).subscribe(res => {
    //   this._ngxLoader.stop();

    // }, (err) => {
    //   console.log("Error", err);
    //   this._ngxLoader.stop();
    // });

    let body = {
      "devices": this.selectedDevice,
    }

    await this._deviceService.bulkUnRegisterDevices(body).subscribe(res => {
      this._ngxLoader.stop();
      this.selectedDevice = [];
    }, (err) => {
      console.log("Error", err);
      this._ngxLoader.stop();
    });


  }

  async bulkAddDevices() {

    this._ngxLoader.start();
    let body = {
      "device_group": +this.device_group_ID,
      "devices": this.selectedOtherDevice,
    }

    if (this.device_group_ID != undefined) {
      await this._deviceService.bulkUploadDeviceGroup(body).subscribe(res => {
        this._ngxLoader.stop();
        this.selectedOtherDevice = [];

      }, (err) => {
        console.log("Error", err);
        this._ngxLoader.stop();
      });
    }
  }

  async createDeviceGroup() {

    this._ngxLoader.start();


    let addBody = {
      "name": this.deviceGroupname,
      "description": this.description,
      "policy_group": this.protectionPolicyGroup_id,
      "protected_devices": this.protectedDevices
    }

    if (!this.isEditGroup) {
      await this._deviceService.addDeviceGroup(addBody).subscribe(async (res) => {
        if (res) {
          this.device_group_ID = res['id'];
          this._deviceService.isDeviceClone = false;
          if(this.selectedDevice.length > 0) {
            await this.bulkRemoveDevices();
          }
          
          await this.bulkAddDevices();

          this._sharedService.getToastPopup('Device Group added successfully', 'AZT Device', 'success');
        }

        this._ngxLoader.stop();
      }, (err) => {
        if (err.status == 403) {
          this._ngxLoader.stop();
          this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
          return;
        }
        else if (err.status == 400) {
          this._ngxLoader.stop();
          this._sharedService.getToastPopup(err.error['name'], 'AZT Device', 'error');
          return;
        }
        else {
          this._ngxLoader.stop();
          this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
        }
      })
    }
    else {
      let updateBody = {
        "name": this.deviceGroupname,
        "description": this.description,
        "policy_group": this.protectionPolicyGroup_id,
        "protected_devices": this.protectedDevices
      }

      await this._deviceService.updateDeviceGroup(this.device_group_ID, updateBody).subscribe(async (res) => {
        if (res) {
          this.device_group_ID = res['id'];
          this._deviceService.isDeviceClone = false;
          if(this.selectedDevice.length > 0) {
            await this.bulkRemoveDevices();
          }
          await this.bulkAddDevices();
          this._sharedService.getToastPopup('Device Group updated successfully', 'AZT Device', 'success');
        }
        this._ngxLoader.stop();
      }, (err) => {
        if (err.status == 403) {
          this._ngxLoader.stop();
          this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
          return;
        }
        else if (err.status == 400) {
          this._ngxLoader.stop();
          this._sharedService.getToastPopup(err.error['name'], 'AZT Device', 'error');
          return;
        }
        else {
          this._ngxLoader.stop();
          this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
          return;
        }
      });
    }
  }

  async saveData() {

    this._sharedService._device_group_ID = "";
    this._sharedService.selectedDevice = [];
    this._sharedService.selectedOtherDevice = [];
    this._deviceService.is_defaultDevice = false;
    this._sharedService.isBack = false;
    await this.createDeviceGroup();

    //const createDeviceGroup = this.createDeviceGroup();

    // forkJoin([bulkRemoveDevices, bulkAddDeviceGroup]);

    this._router.navigateByUrl('/', {skipLocationChange: true}).then(()=>   this._router.navigate(['/devices/device-group-summary']));
    //this._router.navigate(['/devices/device-group-summary']);
  }

  back() {

    this._sharedService.isBack = true;
    this._router.navigate(['/device-groups/device'], { queryParams: { deviceGroupID: this.device_group_ID, deviceName: DeviceNav.DEVICE_GROUPS, isDeviceInstallWizard: true, isDeviceCloneUrl: false } });
  }
}
