import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceDrillLevelComponent } from './device-drill-level.component';

describe('DeviceDrillLevelComponent', () => {
  let component: DeviceDrillLevelComponent;
  let fixture: ComponentFixture<DeviceDrillLevelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeviceDrillLevelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceDrillLevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
