import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-drill-level',
  templateUrl: './device-drill-level.component.html',
  styleUrls: ['./device-drill-level.component.css']
})
export class DeviceDrillLevelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
