import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceGroupWizardComponent } from './device-group-wizard.component';

describe('DeviceGroupWizardComponent', () => {
  let component: DeviceGroupWizardComponent;
  let fixture: ComponentFixture<DeviceGroupWizardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeviceGroupWizardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceGroupWizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
