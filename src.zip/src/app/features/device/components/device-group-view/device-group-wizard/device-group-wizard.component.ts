import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DeviceNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-device-group-wizard',
  templateUrl: './device-group-wizard.component.html',
  styleUrls: ['./device-group-wizard.component.css']
})
export class DeviceGroupWizardComponent implements OnInit {

  deviceBlankUrl: string = "/";
  deviceCloneUrl: string = "/";
  deviceName: string = "N/A";
  constructor(private _sharedService: SharedService, private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getPolicyUrl();
  }

  getPolicyUrl() {

    this.deviceName = this._route.snapshot.queryParams['deviceName'];
    switch (this.deviceName) {
      case DeviceNav.DEVICE_GROUPS:
        this.deviceBlankUrl = '/device-groups/general';
        this.deviceCloneUrl = '/device-groups/source-device';
        break;

      case DeviceNav.PROTECTION_POLICIES:
        this.deviceBlankUrl = '/protection-policies/general';
        this.deviceCloneUrl = '/protection-policies/source-policy';
        break;

      case DeviceNav.EXCEPTION_POLICIES:
        this.deviceBlankUrl = '/exception-policies/general';
        this.deviceCloneUrl = '/exception-policies/source-policy';
        break;

      case DeviceNav.NOTIFICATION_POLICIES:
        this.deviceBlankUrl = '/notification-policies/general';
        this.deviceCloneUrl = '/notification-policies/source-policy';
        break;

        case DeviceNav.SYSTEM_POLICIES:
          this.deviceBlankUrl = '/system-policies/general';
          this.deviceCloneUrl = '/system-policies/source-policy';
          break;
    }
  }

  redirectToBlankPolicy() {
    this.clearDeviceData();
    this._sharedService.isSaved = false;
    this._sharedService.isAddMode = true;
      // this._sharedService.NavComponent();
    this._router.navigate([this.deviceBlankUrl], { queryParams: { deviceName: this.deviceName, isDeviceInstallWizard: true, isDeviceCloneUrl: false ,isAdd : true} });
  }

  redirectToClonePolicy() {
    this.clearDeviceData();
    this._sharedService.isSaved = false;
    this._sharedService.isAddMode = false;
    this._router.navigate([this.deviceCloneUrl], { queryParams: { deviceName: this.deviceName, isDeviceInstallWizard: true, isDeviceCloneUrl: true,isAdd : false } });
  }

  clearDeviceData(){
    this._sharedService.deviceGroupname = "";
    this._sharedService.description = "";
    this._sharedService.protectionPolicyGroup_id = "";
    this._sharedService.protectedDevices = "";
    this._sharedService.creationDate = "";

  }

}
