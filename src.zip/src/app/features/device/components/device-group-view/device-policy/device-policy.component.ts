import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-device-policy',
  templateUrl: './device-policy.component.html',
  styleUrls: ['./device-policy.component.css']
})
export class DevicePolicyComponent implements OnInit {

  constructor(private _router: Router, private _sharedService: SharedService) { }

  ngOnInit(): void {
  }

  next() {
    this._router.navigateByUrl('/device-groups/device');
}

back(){
  this._router.navigateByUrl('/device-groups/protection-mode');
 }

  BaseProtection() {
    this._router.navigateByUrl('/policy-group/base-protection-server');
  }

}
