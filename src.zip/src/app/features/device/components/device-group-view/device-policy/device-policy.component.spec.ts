import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DevicePolicyComponent } from './device-policy.component';

describe('DevicePolicyComponent', () => {
  let component: DevicePolicyComponent;
  let fixture: ComponentFixture<DevicePolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DevicePolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DevicePolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
