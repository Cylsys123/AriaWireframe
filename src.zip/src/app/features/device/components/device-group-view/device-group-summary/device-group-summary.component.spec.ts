import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceGroupSummaryComponent } from './device-group-summary.component';

describe('DeviceGroupSummaryComponent', () => {
  let component: DeviceGroupSummaryComponent;
  let fixture: ComponentFixture<DeviceGroupSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeviceGroupSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceGroupSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
