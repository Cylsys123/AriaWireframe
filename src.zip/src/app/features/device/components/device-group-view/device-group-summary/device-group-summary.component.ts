import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { forkJoin, Observable } from 'rxjs';
import { PolicyService } from 'src/app/features/policy/services/policy.service';
import { DeviceNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { NotificationService } from 'src/app/features/notification/services/notification.service';
import { DeviceService } from '../../../services/device.service';

@Component({
  selector: 'app-device-group-summary',
  templateUrl: './device-group-summary.component.html',
  styleUrls: ['./device-group-summary.component.css']
})
export class DeviceGroupSummaryComponent implements OnInit {
  deviceBlankUrl: string = "/";

  deviceName: string = "N/A";
  deviceGroupArr: any = [];
  policyGrpArr: any = [];
  groupByList: any = [];
  tooltipText: any

  filterParams: any = {};
  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'name';
  isScroll: boolean = false;
  deviceUrl: any = "/device-groups"

  constructor(
    private _deviceService: DeviceService,
    private _notificationService: NotificationService,
    private _sharedService: SharedService,
    private _policyService: PolicyService,
    private _ngxLoader: NgxUiLoaderService,
    private translate: TranslateService,
    private _router: Router,
    private _route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this._setPreData();
    this._fetchDataAndPopulate();
    //this.getPolicyUrl();
    this._notificationService.filterSharingSubject
      .subscribe((borrower) => {
        if (borrower['url'] == 'device-groups') {
          this.filterParams = borrower['data'];
          this.globalPageNumber = 1;
          this.deviceGroupArr[0]['data']['value'] = [];
          this._fetchDataAndPopulate();
        }
      }
      );

    this.tooltipText = `
      <div class="tooltiptxt" >
        <div class="row " >
          <div class="col-md-12">
            <p><span>Risk Lavel :</span>  URGENT. NEED ATTENTION</p>
          </div>
          <div class="col-md-12">
            <p><span>Summary :</span>  Your alerts indicates there are devices under attack and are not yet fully
                    protected by the AZT Prevent Protection Policy .</p>
          </div>
          <div class="col-md-12">
            <p><span>Actions :</span>   Use the ACTIONS buttons provided to change the protection policy to PREVENT mode.
            <a>Learn more...</a></p>
          </div>
        </div> 
      </div>`
  }

  private _setPreData() {

    this._sharedService._device_group_ID = "";
    this._sharedService.selectedDevice = [];
    this._sharedService.selectedOtherDevice = [];
    this.policyGrpArr = this._route.snapshot.data['device']?.policyGroups?.results;

    this.deviceGroupArr.push(
      {
        "name": this.translate.instant("LBL_AZT_DEVICE_GROUPS"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_RISK_LEVEL')
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_DEVICE_NAME')
            },
            {
              colKey: 'policy_group_name',
              colKeyLabel: this.translate.instant('LBL_AZT_POLICY_GROUP')
            },

            {
              colKey: 'protected_devices',
              colKeyLabel: this.translate.instant('LBL_AZT_PROTECTED_DEVICES')
            },

            {
              colKey: 'modified',
              colKeyLabel: this.translate.instant('LBL_AZT_MODIFIED_DATE')
            },

            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_ACTION')
            }
          ],
          "value": []
        }
      });

    this.groupByList = [
      { name: 'All' },
      { name: 'Device group' },
      { name: 'Device type' },
      { name: 'Nofification' },
      { name: 'Alert' },
      { name: 'Valnerabilities' },
      { name: 'Policies' },
      { name: 'Integration' }
    ];
    this.getPolicyGroup();
  }

  changePolicyGroup(value: any) {
    this._ngxLoader.start();
    // this._deviceService.putDeviceGroupApi(value['id'], { 'name': value['policy_group_name'], 'policy_group': value['policy_group'] }).subscribe((res) => {

    this._ngxLoader.stop(); this._deviceService.putDeviceGroupApi(value['id'], { 'policy_group': value['policy_group'] }).subscribe((res) => {
      this._sharedService.getToastPopup('Successfully, updated policy group', 'AZT Device Group', 'success');
    },
      (err) => {
        this._ngxLoader.stop();
        // this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
        if (err.status == 403) {
          this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
        }
        else if (err.status == 400) {
          this._sharedService.getToastPopup(err.error['name'], 'AZT Device', 'error');
        }
        else {
          this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
        }
      })
  }

  getPolicyUrl() {

    this.deviceName = this._route.snapshot.queryParams['deviceName'];
    switch (this.deviceName) {
      case DeviceNav.DEVICE_GROUPS:
        this.deviceBlankUrl = '/device-groups/general';
        break;

      case DeviceNav.PROTECTION_POLICIES:
        this.deviceBlankUrl = '/protection-policies/general';
        break;

      case DeviceNav.EXCEPTION_POLICIES:
        this.deviceBlankUrl = '/exception-policies/general';
        break;

      case DeviceNav.NOTIFICATION_POLICIES:
        this.deviceBlankUrl = '/notification-policies/general';
        break;

      case DeviceNav.SYSTEM_POLICIES:
        this.deviceBlankUrl = '/system-policies/general';
        break;
    }
  }
  navigateUrl() {
    // this._router.navigate(['device-group-wizard'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS } });
    // this._router.navigate(['/device-groups/general'],{ queryParams: { deviceName: this.deviceName, isDeviceInstallWizard: true, isDeviceCloneUrl: false } });
    this._sharedService.deviceGroupname = ""
    this._sharedService.description = "";
    this._sharedService.protectionPolicyGroup_id = "";
    this._sharedService.protectedDevices = "";
    this._sharedService.creationDate = "";
    this._sharedService._device_group_ID = "";

    this._sharedService.isSaved = false;
    this._sharedService.isAddMode = true;
    this._sharedService.isBack = false;
    this._router.navigate(['/device-groups/general'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, isDeviceInstallWizard: true, isDeviceCloneUrl: false, isAdd: true } });
  }

  general() {
    this._router.navigate(['/device-groups/general'], { queryParams: { deviceName: this.deviceName, isDeviceInstallWizard: true, isDeviceCloneUrl: false } });
  }

  editDeviceGroup(value: any) {
    // this._router.navigate(['/device-groups/general', deviceID], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, isDeviceInstallWizard: true, isDeviceCloneUrl: false, isEditGroup: true } });
    this._router.navigate(['/device-groups/general'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, isDeviceInstallWizard: true, isDeviceCloneUrl: false, isEditGroup: true, deviceID: value.id } });
    this._deviceService.is_defaultDevice = value.is_default;
  }

  showSortArrow(queryParamKey: string | undefined): boolean {
    return queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-');
  }

  sortTableCol(queryParamKey: string | undefined) {
    if (queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-')) {
      this.sortParamKey = queryParamKey;
    } else {
      this.sortParamKey = '-' + queryParamKey;
    }
    this.globalPageNumber = 1;
    if (this.isScrollDisable) this.isScrollDisable = false;
    this.deviceGroupArr[0]['data']['value'] = [];
    this._fetchDataAndPopulate();
  }

  onScrollDown() {

    this.isScroll = true;
    this._fetchDataAndPopulate();
  }

  private _setPaginationConfig(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());
    let filterQueryParams = this.filterParams;
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);

    if (!this.isScroll) {
      this.deviceGroupArr[0]['data']['value'] = [];
    }
    let sortQueryParams = {}
    sortQueryParams = {
      ordering: this.sortParamKey
    };
    // if (this.deviceGroupArr[0]['data']['value'].length > 0) {
    //   sortQueryParams = {
    //     ordering: this.sortParamKey
    //   };
    // }

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };
    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  private _fetchDataAndPopulate() {
    let deviceQueryParams = this._setPaginationConfig();
    this._ngxLoader.start();
    this._deviceService.getDeviceGroupsWithQueryApi(deviceQueryParams).subscribe(res => {

      this._ngxLoader.stop();
      if (res && res['count'] !== 0 && res['results'].length !== 0) {
        this.deviceGroupArr[0]['data']['value'].push(...res['results']);
        // for (let index = 0; index < this.deviceGroupArr[0]['data']['value'].length; index++) {
        //   const element = this.deviceGroupArr[0]['data']['value'][index]; 
        // }
        this.totalRecords = res['count'];
        if (this.totalRecords === this.deviceGroupArr[0]['data']['value'].length) {
          this.isScrollDisable = true;
        }
        this.globalPageNumber += 1;
      }
    }, (err) => {
      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
    });
  }

  deleteDevice(item) {
    this._sharedService._device_group_ID = item.id;
    this._sharedService.isFrmDeviceGrp = true;
    this._sharedService.isFrmAlert = false;
    this._sharedService.deviceGroupname = item.name;
    this._sharedService.protectedDevices = item.protected_devices;
    this._router.navigate(['/confirmation']);
  }

  getPolicyGroup() {
    this._deviceService.getDeviceGroupApi().subscribe((res) => {
      console.log('res'); console.log(res);
      localStorage.setItem('deviceGroup', JSON.stringify(res));
      localStorage.setItem('devices', JSON.stringify(res));
    },
      (err) => {
        console.log('err'); console.log(err);
      })
  }

  tooltipOptions = {
    'placement': 'left',
    'showDelay': 500,
    'tooltip-class': 'riskTooltip'
  }


}
