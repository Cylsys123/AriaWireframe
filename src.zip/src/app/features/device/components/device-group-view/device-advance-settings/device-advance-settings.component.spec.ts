import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceAdvanceSettingsComponent } from './device-advance-settings.component';

describe('DeviceAdvanceSettingsComponent', () => {
  let component: DeviceAdvanceSettingsComponent;
  let fixture: ComponentFixture<DeviceAdvanceSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeviceAdvanceSettingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceAdvanceSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
