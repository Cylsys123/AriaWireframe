import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { PolicyService } from 'src/app/features/policy/services/policy.service';
import { DeviceNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { DeviceService } from '../../../services/device.service';

@Component({
  selector: 'app-device-advance-settings',
  templateUrl: './device-advance-settings.component.html',
  styleUrls: ['./device-advance-settings.component.css']
})
export class DeviceAdvanceSettingsComponent implements OnInit {

  urlData: string = ""
  policyGroupId: any;
  protectionPolicySimpleArr: any = [];
  protectionPolicyCounterMeasureArr: any = [];
  primaryKey: any;
  policySimpleArr: any = [];
  policyCounterMeasureArr: any = [];
  policyGrpName: string = '';
  groupByList: any = [];
  isPolicyCloneUrl: any = false;

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  sortParamKey: string = 'name';
  deviceGroupList: any;

  device_group : string = "";
  device_group_ID: any;
  deviceGroupName: any;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private _deviceService: DeviceService,
    private translate: TranslateService
  ) { }

  ngOnInit(): void {
    this._setPreData();

    this.getDeviceGroup();

    this.getDefaultPolicy();

    this._route.queryParams.subscribe(params => {
      this.device_group_ID = params.deviceGroupID;
      // this.deviceGroupName = params.deviceGroupName;
    });
  }

  private _setPreData() {
    this.protectionPolicySimpleArr.push(
      {
        "name": this.translate.instant("LBL_AZT_SIMPLE"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_STATUS')
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_NAME')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_POLICY_DETAILS')
            },

            {
              colKey: 'modified',
              colKeyLabel: this.translate.instant('LBL_AZT_MODIFIED_DATE')
            }

          ],
          "value": []
        }
      });


    // this.policyGroupId = this._route.snapshot.queryParams['policyGrpid'];
    // this._callPolicyGroupById(this.policyGroupId);

    this.groupByList = [
      { name: 'Policy Group Type' },
      { name: 'Policy Group Status' },
      { name: 'On/Off' },
      { name: 'Policy Category' },
      { name: 'Policy Group Mode' },
      { name: 'Policy Group Function' },
    ];

   
  }

  

  getDefaultPolicy(){
    this._ngxLoader.start();
    this._deviceService.getPolicyGroupsTempWithQueryApi({}).subscribe(res => {
      this._ngxLoader.stop();
      console.log(res);
      let defaultPolicyGroup = res;
      console.log("defaultPolicyGroup",defaultPolicyGroup);

      this.protectionPolicySimpleArr[0]['data']['value'] = defaultPolicyGroup['countermeasures'];
      // localStorage.setItem('defaultPolicyGroupDevice',JSON.stringify(res));
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) 
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Policy', 'error');
      else 
        this._sharedService.getToastPopup('Internal server error', 'AZT Policy', 'error');
    });
  }


  onToggle(event, value) {
    if (event.target.checked) {
      value['state'] = 1;
      this.upsert(this.policyCounterMeasureArr, value);
      this._sharedService.getToastPopup(value['name'] + ' is enabled. Please click on apply button to save it.', 'AZT Policy', 'success');
      return 1;
    } else {
      value['state'] = 0;
      this.upsert(this.policyCounterMeasureArr, value);
      this._sharedService.getToastPopup(value['name'] + ' is disabled. Please click on apply button to save it.', 'AZT Policy', 'success');
      return 0;
    }
  }

  upsert(array, element) { // (1)
    const i = array.findIndex(_element => _element.id === element.id);
    if (i > -1) array[i] = element; // (2)
    else array.push(element);
  }


  changeStatus(value: object, type: string) {
    if (type == 'simple') {
      value['state'] = Number(value['state']);
      this.upsert(this.policySimpleArr, value);
    } else {
      this.upsert(this.policyCounterMeasureArr, value);
    }

    if (value['state'] == 0) {
      this._sharedService.getToastPopup(value['name'] + ' is disabled. Please click on apply button to save it.', 'AZT Policy', 'success');
    } else {
      this._sharedService.getToastPopup(value['name'] + ' is enabled. Please click on apply button to save it.', 'AZT Policy', 'success');
    }
  }

  applyToGroup(){

    // let simple = this.protectionPolicySimpleArr[0]['data']['value'].map(simple => {
    //   return { id: simple['id'], state: simple['state'] };
    // });
   
    // // this._policyService.simplePolicyObj = simple;
    // // this._policyService.frmAdvanceSetting = true;
    // this._router.navigate(['/policy-group/protection-policy']);
  }

  back(){
    if(this.device_group_ID){
      this._router.navigate(['/device-groups/general'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, isDeviceInstallWizard: true, isDeviceCloneUrl: false, isEditGroup: true, deviceGroupID: this.device_group_ID} });
    }
    else {
      this._router.navigate(['/device-groups/general'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS,isDeviceInstallWizard: true, isDeviceCloneUrl: false } });
    }
  }

  reset() {
    let defaultPolicyGroup = JSON.parse(localStorage.getItem('defaultPolicyGroup'));
    this.protectionPolicySimpleArr[0]['data']['value'] = defaultPolicyGroup.simple;
  }

  getDeviceGroup() {
    this._ngxLoader.start();
    this._deviceService.getDeviceGroupApi().subscribe(res => {
      
      this.deviceGroupList = res['results'];
      this._ngxLoader.stop();
    });
  }

  changeDeviceGroup(value: any) {
    this.device_group_ID = value;
  }

  goToDeviceGroup() {
    // this._router.navigate(['/device-groups/general', deviceID], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, isDeviceInstallWizard: true, isDeviceCloneUrl: false, isEditGroup: true } });
    this._router.navigate(['/device-groups/general'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, isDeviceInstallWizard: true, isDeviceCloneUrl: false, isEditGroup: true, deviceGroupID: this.device_group_ID } });

    this._deviceService.frmDeviceSetting = true;
  }

}
