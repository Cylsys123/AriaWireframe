import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SourceDeviceComponent } from './source-device.component';

describe('SourceDeviceComponent', () => {
  let component: SourceDeviceComponent;
  let fixture: ComponentFixture<SourceDeviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SourceDeviceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SourceDeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
