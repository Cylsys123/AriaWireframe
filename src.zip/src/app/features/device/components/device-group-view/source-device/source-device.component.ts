import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { PolicyService } from 'src/app/features/policy/services/policy.service';
import { DeviceNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { DeviceService } from '../../../services/device.service';

@Component({
  selector: 'app-source-device',
  templateUrl: './source-device.component.html',
  styleUrls: ['./source-device.component.css']
})
export class SourceDeviceComponent implements OnInit {


  deviceGroupList: any;
  device_Group_Id: any ;

  constructor(private _deviceService: DeviceService,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService,
    private _router: Router) { }

  ngOnInit(): void {
    this.getDeviceGroup();
  }

  getDeviceGroup() {
    this._ngxLoader.start();
    this._deviceService.getDeviceGroupApi().subscribe(res => {
      
      this.deviceGroupList = res['results'];
      this._ngxLoader.stop();
    });
  }

  onChange(evt) {
    this.device_Group_Id = evt.target.value;
  }

  back() {
    this._router.navigate(['/device-group-wizard'],{ queryParams: { deviceName: DeviceNav.DEVICE_GROUPS } });
  }

  cloneDeviceGroup() {

    this._sharedService.isSaved = true;
    this._sharedService.NavComponent();
    this._sharedService.fromSourceDevgroup = true;
    this._deviceService.isDeviceClone = true;
    this._sharedService.isAddMode = false;
    this._router.navigate(['/device-groups/general'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, isDeviceInstallWizard: true, isDeviceCloneUrl: false, isClone : true,deviceID: this.device_Group_Id } });
  }

}
