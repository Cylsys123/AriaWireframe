import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneralDeviceComponent } from './general-device.component';

describe('GeneralDeviceComponent', () => {
  let component: GeneralDeviceComponent;
  let fixture: ComponentFixture<GeneralDeviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GeneralDeviceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GeneralDeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
