import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common'
import { DeviceService } from '../../../services/device.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { PolicyService } from 'src/app/features/policy/services/policy.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { DeviceNav } from 'src/app/shared/enum/shared.enum';

import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';

const wsUrl = "wss://tc-ui.eng.cspi.com/ws/";
export interface Message {
  author: string;
  message: string;
}
@Component({
  selector: 'app-general-device',
  templateUrl: './general-device.component.html',
  styleUrls: ['./general-device.component.css']
})
export class GeneralDeviceComponent implements OnInit {
  public messages: Subject<Message>;
  device_group_ID: any;
  policy_Groups: any;
  deviceGroupName: string;
  deviceGroupDescription: string;
  deviceGeneralForm: FormGroup;
  deviceGroupData: any;
  isEdit: boolean = false;
  isView: boolean = true;
  isAdd: boolean;
  isEditGroup: boolean;
  isAddMode: boolean;
  errMessage: string = "";

  deviceGroupArr: any = [];

  isDefaultDevice: number;

  title = 'socketrv';
  content = '';
  received = [];
  sent = [];
  _messages: Subject<any>;

  constructor(private _router: Router,
    private _route: ActivatedRoute,
    private _fb: FormBuilder,
    private _deviceService: DeviceService,
    public datepipe: DatePipe,
    private _ngxLoader: NgxUiLoaderService,
    private _policyService: PolicyService,
    private _sharedService: SharedService,
    
  ) {
    
     window.addEventListener('beforeunload', (event) => {
      console.log('deviceGeneralForm log');
      if(this.deviceGeneralForm.dirty){
        /*if(window.confirm("Do you really want to leave?")){

        }
        else {

        }*/
        event.preventDefault();
        event.returnValue = 'There are unsaved changes which will be lost - do you still want to proceed with the refresh?';
      } else {
        
      }
    }); 
  }

  async ngOnInit() {

    this.isAddMode = this._sharedService.isAddMode;

    if(this._deviceService.frmDeviceSetting) {
      this._route.queryParams.subscribe(params => {
        this.isAdd = params.isAdd;
        this.isEditGroup = params.isEditGroup;
        this.device_group_ID = params.deviceGroupID;
      });
    }
    else {
      this._route.queryParams.subscribe(params => {
        this.isAdd = params.isAdd;
        this.isEditGroup = params.isEditGroup;
        this.device_group_ID = params.deviceID;
      });
    }

    if (this.isAdd) {
      this.fnHideShow();
    }

    if (this.device_group_ID == null && this.device_group_ID == undefined) {
      this.createdeviceGeneralForm();
      await this._getPolicyGroupList();
      // this._getDeviceGroupData();
    }

    else {
      this.createdeviceGeneralForm();
      await this._getDeviceGroupData();
      await this._getPolicyGroupList();
    }

    if (this._sharedService.isBackToGeneral || this._sharedService.isSaved) {
      this.getDevisesData();
    }
    else {
      this._sharedService.deviceGroupname = ""
    }
  }


  editDeviceGroup(value: any) {
    this._deviceService.is_defaultDevice = value.is_default;
  }


  getDevisesData() {

    this.deviceGroupName = this._sharedService.deviceGroupname;
    this.deviceGroupDescription = this._sharedService.description;
    this.deviceGeneralForm.patchValue({
      'deviceGroupname': this._sharedService.deviceGroupname,
      'protectionPolicyGroup_id': this._sharedService.protectionPolicyGroup_id,
      'protectedDevices': this._sharedService.protectedDevices,
      'creationDate': this.datepipe.transform(this._sharedService.creationDate, 'MMM-dd-yyyy'),
      'description': this._sharedService.description,
    });
    this.isAdd = true;
    // this.isEdit = false;
  }

  createdeviceGeneralForm() {
    this.deviceGeneralForm = this._fb.group({
      'deviceGroupname': ['', Validators.required],
      'creationDate': [''],
      'protectionPolicyGroup_id': [null, Validators.required],
      'protectedDevices': [0, Validators.required],
      'description': ['']
    });
  }

  private _getDeviceGroupData() {
    //loader start
    this._ngxLoader.start();
    this._deviceService.getDeviceGroupByIdApi(this.device_group_ID).subscribe(res => {
      this.isAdd = false;
      this.deviceGroupData = res;
      this._ngxLoader.stop();


      this.deviceGroupName = this.deviceGroupData['name'];
      this._sharedService.deviceGroupname = this.deviceGroupData['name'];
      this.deviceGroupDescription = this.deviceGroupData['description'];

      this.deviceGeneralForm.patchValue({
        'deviceGroupname': this.deviceGroupData['name'],
        'protectedDevices': this.deviceGroupData['protected_devices'],
        'creationDate': this.datepipe.transform(this.deviceGroupData['creation'], 'MMM-dd-yyyy'),
        'description': this.deviceGroupData['description'],
        'protectionPolicyGroup_id': this.deviceGroupData['policy_group']
      });





      if (this.deviceGroupData["is_default"]) {
        this.deviceGeneralForm.get('deviceGroupname').disable({ onlySelf: true });
      }
      if (this.deviceGroupData.is_default) {
        this.deviceGeneralForm.get('deviceGroupname').disable()
        this.isDefaultDevice = this.deviceGroupData.is_default ? 1 : 0;
      }
      this._sharedService.protectionPolicyGroup_id = this.deviceGroupData['policy_group'];

      this._sharedService.protectedDevices = this.deviceGroupData['protected_devices'];
      this._sharedService.description = this.deviceGroupData['description'];
      this._sharedService.creationDate = this.datepipe.transform(this.deviceGroupData['creation'], 'MMM-dd-yyyy');

      this._sharedService._device_group_ID = this.device_group_ID;
      this._sharedService.isSaved = true;
      this._sharedService.NavComponent()

    }, (err) => {
      if (err.status == 403) {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
      }
      else {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
      }
    });
  }

  private _getPolicyGroupList() {
    this._ngxLoader.start();

    this._policyService.getPolicyGroupApi().subscribe(policy_groups => {
      this._ngxLoader.stop();
      this.policy_Groups = policy_groups['results'];

      // if (!this.isAdd) {
      //   this.policy_Groups.forEach(element => {
      //     if (element.id == this.deviceGroupData['policy_group'] && this.deviceGroupData['policy_group'] != undefined) {
      //       this.deviceGeneralForm.patchValue({
      //         'protectionPolicyGroup_id': this.deviceGroupData['policy_group']
      //       })
      //     }
      //     else {
      //       this.deviceGeneralForm.value.protectionPolicyGroup_id = null;
      //     }
      //   });
      // }
    });
  }

  changePolicyGroup(event) {
    this.deviceGeneralForm.value.protectionPolicyGroup_id = event.target.value;
  }

  checkDevGroup() {
    if (this.deviceGeneralForm.value.deviceGroupname.length == 0 || this.deviceGeneralForm.value.deviceGroupname == "") {
      return;
    };
    if (this.deviceGeneralForm.value.deviceGroupname.length > 64) {
      this._sharedService.getToastPopup('Ensure that Device Group Name has no more than 64 characters.', 'AZT Device', 'error');
      this.deviceGeneralForm.controls['deviceGroupname'].reset();
      return;
    }
    if ((this._sharedService._device_group_ID != null && this._sharedService._device_group_ID != undefined) && !this.deviceGeneralForm.get('deviceGroupname').dirty) {
      this._sharedService.deviceGroupname = this.deviceGeneralForm.value.deviceGroupname;
    }
    else {
      this._ngxLoader.start();
      this._deviceService.getDeviceGroupNameApi(this.deviceGeneralForm.value.deviceGroupname).subscribe(res => {
        this._ngxLoader.stop();
        if (res && res['count'] != 0) {
          this.errMessage = "Name already exists. Update and retry";
          return;
        }
        else {
          this.errMessage = "";
        }
      }, (err) => {
        this._ngxLoader.stop();
        if (err.status == 403) {
          this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
        }
        else if (err.status == 400) {
          this._sharedService.getToastPopup(err.error['name'], 'AZT Device', 'error');
        }
        else {
          this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
        }
      });
    }
  }

  submitdeviceGeneralForm() {
    //if (this.deviceGeneralForm.value.deviceGroupname.length > 64) {
    if (this.deviceGeneralForm.get('deviceGroupname').value.length > 64) {
      this._sharedService.getToastPopup('Ensure that Device Group Name has no more than 64 characters.', 'AZT Device', 'error');
      this.deviceGeneralForm.controls['deviceGroupname'].reset();
      return;
    }

    if (this.deviceGeneralForm.invalid) {
      return;
    }

    if ((this._sharedService._device_group_ID != null && this._sharedService._device_group_ID != undefined) && !this.deviceGeneralForm.get('deviceGroupname').dirty) {
      this._sharedService.deviceGroupname = this.deviceGeneralForm.value.deviceGroupname;
      this._sharedService.protectionPolicyGroup_id = this.deviceGeneralForm.value.protectionPolicyGroup_id;
      // this._sharedService.creationDate = this.datepipe.transform(this.deviceGroupData['creation'], 'MMM-dd-yyyy');
      this._sharedService.protectedDevices = this.deviceGeneralForm.value.protectedDevices;
      this._sharedService.description = this.deviceGeneralForm.value.description;
      this._sharedService.isSaved = true;
      this._deviceService.isNext = true;
      this._sharedService.NavComponent();
      this.deviceGeneralForm.reset();
      this._router.navigate(['/device-groups/device'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, deviceGroupID: this.device_group_ID, isEditGroup: this.isEditGroup, isDeviceInstallWizard: true } });
    }
    else {

      this._deviceService.getDeviceGroupNameApi(this.deviceGeneralForm.value.deviceGroupname).subscribe(res => {

        if (res && res['count'] != 0) {
          this.errMessage = "The Device Group Name already exists";
          return;
        }
        else {
          this._sharedService.deviceGroupname = this.deviceGeneralForm.value.deviceGroupname;

          if (!this.isAdd) {
            this._sharedService.creationDate = this.datepipe.transform(this.deviceGroupData['creation'], 'MMM-dd-yyyy');
          }

          this._sharedService.protectionPolicyGroup_id = this.deviceGeneralForm.value.protectionPolicyGroup_id;
          this._sharedService.protectedDevices = this.deviceGeneralForm.value.protectedDevices;
          this._sharedService.description = this.deviceGeneralForm.value.description;
          this._sharedService.isSaved = true;
          this._deviceService.isNext = true;
          this._sharedService.NavComponent();
          this.deviceGeneralForm.reset();
          this._router.navigate(['/device-groups/device'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, deviceGroupID: this.device_group_ID, isEditGroup: this.isEditGroup, isDeviceInstallWizard: true } });
        }
      }, (err) => {
        console.log("Err", err);
      });
    }

  }

  saveDescription() {
    this.deviceGeneralForm.patchValue({
      'deviceGroupname': this.deviceGeneralForm.value.deviceGroupname,
      'description': this.deviceGeneralForm.value.description
    });

    this.deviceGroupName = this.deviceGeneralForm.value.deviceGroupname;
    this.deviceGroupDescription = this.deviceGeneralForm.value.description;
    this.isEdit = false;
    this.isView = true;
  }

  fnHideShow() {
    this.isEdit = true;
    this.isView = false;
  }

  hideOnCancel() {
    this.isEdit = false;
    this.isView = true;
  }

  back() {
    if (this._sharedService.fromSourceDevgroup) {
      this._router.navigate(['/device-groups/source-device'], { queryParams: { isDeviceInstallWizard: true, isDeviceCloneUrl: true, isAdd: false } });
    }
    else {
      this._router.navigate(['/devices/device-group-summary']);
    }
  }

  advanceSetting() {
    this._deviceService.frmDeviceSetting = false;
    this._router.navigate(['/device-groups/device-setting'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS, deviceGroupID: this.device_group_ID, isEditGroup: this.isEditGroup, isDeviceInstallWizard: true,deviceGroupName:this._sharedService.deviceGroupname } });
  }
}
