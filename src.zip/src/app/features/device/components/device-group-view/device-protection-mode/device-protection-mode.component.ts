import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-device-protection-mode',
  templateUrl: './device-protection-mode.component.html',
  styleUrls: ['./device-protection-mode.component.css']
})
export class DeviceProtectionModeComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }

  next() {
    this._router.navigateByUrl('/device-groups/protection-policy');
}

back(){
  this._router.navigateByUrl('/device-groups/general');
 }

}
