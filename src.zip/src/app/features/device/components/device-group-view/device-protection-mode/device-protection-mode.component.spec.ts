import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceProtectionModeComponent } from './device-protection-mode.component';

describe('DeviceProtectionModeComponent', () => {
  let component: DeviceProtectionModeComponent;
  let fixture: ComponentFixture<DeviceProtectionModeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeviceProtectionModeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceProtectionModeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
