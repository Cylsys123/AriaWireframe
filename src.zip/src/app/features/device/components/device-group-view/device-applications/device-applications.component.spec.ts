import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceApplicationsComponent } from './device-applications.component';

describe('DeviceApplicationsComponent', () => {
  let component: DeviceApplicationsComponent;
  let fixture: ComponentFixture<DeviceApplicationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeviceApplicationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceApplicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
