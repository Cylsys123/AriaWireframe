import { Component, EventEmitter, Output, ElementRef, OnInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { DeviceNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { DeviceService } from '../../../services/device.service';

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.css']
})
export class DevicesComponent implements OnInit {

  _device_group_ID: any = "";
  _devicesList: any = [];
  _otherDevicesList: any = [];
  isScroll: boolean = false
  deviceGroupname = "";
  creationDate = "";
  protectionPolicyGroup_id = "";
  protectedDevices = "";
  description = "";

  masterDevicesSelected: boolean;
  masterOtherDevicesSelected: boolean;
  selectedDevice = [];
  checkedDeviceList: any;
  masterChecked: boolean = false;

  selectedOtherDevice = [];
  checkedOtherDeviceList: any;
  masterCheckedOtherDev: boolean = false;

  isEditGroup: boolean;
  isBackToGeneral: boolean;
  isEnbled: boolean = true;

  isDeviceScrollDisable: boolean = false
  isOtherDeviceScrollDisable: boolean = false

  @Output() refreshList = new EventEmitter();
  @ViewChildren("checkboxes") checkboxes: QueryList<ElementRef>;
  @ViewChildren("otherCheckboxes") otherCheckboxes: QueryList<ElementRef>;

  filterParams: any = {};
  sortParamKey: string = '';
  globalDevicePageNumber: number = 1;
  globalOtherDevicePageNumber: number = 1;
  hideAddDevSection: boolean = false;
  totalRecords: number = 0;
  readonly globalLimit: number = 50;
  isOtherScrolling: boolean;

  constructor(private _router: Router,
    private _route: ActivatedRoute,
    private _deviceService: DeviceService,
    private _ngxLoader: NgxUiLoaderService,
    private _sharedService: SharedService
  ) { }

  async ngOnInit() {
console.log('testtt');
    this._route.queryParams.subscribe(params => {

      this._device_group_ID = params.deviceGroupID;
      this.isEditGroup = params.isEditGroup;
    });


    this.deviceGroupname = this._sharedService.deviceGroupname;

    this.creationDate = this._sharedService.creationDate;
    this.protectionPolicyGroup_id = this._sharedService.protectionPolicyGroup_id;
    this.protectedDevices = this._sharedService.protectedDevices;
    this.description = this._sharedService.description;

    if (this._device_group_ID != undefined && this._device_group_ID != null) {
      this.getDevicesGroup();
      this.isEnbled = null;
    }
    else if (this._sharedService.isSaved && (this._sharedService._device_group_ID != undefined && this._sharedService._device_group_ID != "" && this._sharedService._device_group_ID != null)) {
      this._device_group_ID = this._sharedService._device_group_ID;
      this.getDevicesGroup();
    }

    await this.getOtherDevicesGroup();

    if (this._sharedService.isBack) {
      let paginate = Math.ceil(this._sharedService.selectedOtherDevice.length / this.globalLimit)

      if (paginate > 1) {
        for (let index = 0; index < paginate; index++) {
          this.onScrollDown("Other");
        }
      }
    }

    if (this._deviceService.is_defaultDevice) {
      this.hideAddDevSection = true;
    }
  }

  async getDevicesGroup() {

    this._ngxLoader.start();

    let deviceQueryParams = this._setPaginationConfig(this.globalDevicePageNumber, "Devices");
    this._deviceService.getDevicesByGroup_IdApi(deviceQueryParams).subscribe(res => {
      this._ngxLoader.stop();
      this._devicesList.push(...res['results']);

      this.globalDevicePageNumber++;
      var totalRecords = parseInt(res['count']);

      if (totalRecords === this._devicesList.length) {
        this.isDeviceScrollDisable = true;
      }

      if (this._sharedService.isBack == true) {
        for (let index = 0; index < this._devicesList.length; index++) {
          this._devicesList[index].isSelected = false;
          for (let zindex = 0; zindex < this._sharedService.selectedDevice.length; zindex++) {
            if (this._devicesList[index].id == this._sharedService.selectedDevice[zindex]) {
              this._devicesList[index].isSelected = true;
            }
          }
        }
        this.selectedDevice = this._sharedService.selectedDevice;

        if (this._devicesList.length > 0) {
          let isFalse = this._devicesList.filter(x => x.isSelected == false);
          // this._otherDevicesList.length > 0 ? this
          if (isFalse.length == 0) {
            this.masterDevicesSelected = true;
          }
        }
      }

    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
      }

    });
  }

  async getOtherDevicesGroup() {
    this._ngxLoader.start();
    let deviceQueryParams = this._setPaginationConfig(this.globalOtherDevicePageNumber, "OtherDevices");
    await this._deviceService.getOtherDevicesByGroup_IdApi(deviceQueryParams).subscribe(res => {
      this._ngxLoader.stop();
      this._otherDevicesList.push(...res['results']);

      this.globalOtherDevicePageNumber++;
      this.totalRecords = parseInt(res['count']);

      if (this.totalRecords === this._otherDevicesList.length) {
        this.isOtherDeviceScrollDisable = true;
      }
      else {
        if (this.isOtherScrolling && !this._sharedService.isBack && this.masterOtherDevicesSelected) {
          for (let index = 0; index < res['results'].length; index++) {
            this.selectedOtherDevice.push(res['results'][index].id);
          }
        }
      }
      if (this._sharedService.isBack == true) {

        for (let i = 0; i < this._otherDevicesList.length; i++) {
          this._otherDevicesList[i].isSelected = false;
          for (let yindex = 0; yindex < this._sharedService.selectedOtherDevice.length; yindex++) {
            if (this._otherDevicesList[i].id == this._sharedService.selectedOtherDevice[yindex]) {
              this._otherDevicesList[i].isSelected = true;
            }

          }
        }
        this.selectedOtherDevice = this._sharedService.selectedOtherDevice;

        if (this._otherDevicesList.length > 0) {
          let isFalse = this._otherDevicesList.filter(x => x.isSelected == false);
          // this._otherDevicesList.length > 0 ? this
          if (isFalse.length == 0) {
            this.masterOtherDevicesSelected = true;
          }
        }
      }
      else {
        if (this.masterOtherDevicesSelected) {
          for (let index = 0; index < this._otherDevicesList.length; index++) {
            this._otherDevicesList[index].isSelected = true;
          }
        }
      }

    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
      }
    });
  }

  ngAfterViewChecked() {

    if (this.masterDevicesSelected == true) {
      this.checkboxes.forEach((element) => {
        element.nativeElement.checked = true;
      });
    }

    if (this.masterOtherDevicesSelected == true) {
      this.otherCheckboxes.forEach((element) => {
        element.nativeElement.checked = true;
      });
    }
  }

  ngAfterViewInit() {

    if (this.masterDevicesSelected == true) {
      this.checkboxes.forEach((element) => {
        element.nativeElement.checked = true;
      });
    }

    if (this.masterOtherDevicesSelected == true) {
      this.otherCheckboxes.forEach((element) => {
        element.nativeElement.checked = true;
      });
    }
  }


  checkUncheckAllDevices(event) {
    this.selectedDevice = [];

    for (var i = 0; i < this._devicesList.length; i++) {
      this.masterDevicesSelected = event.target.checked;
      if (event.target.checked == true) {
        this._devicesList[i].isSelected = true;
        this.selectedDevice.push(this._devicesList[i].id);
        this.checkboxes.forEach((element) => {
          element.nativeElement.checked = true;
        });
      } else if (event.target.checked == false) {
        this.selectedDevice = [];
        this.checkboxes.forEach((element) => {
          element.nativeElement.checked = false;
        });
      }
      this._devicesList[i].isSelected = this.masterDevicesSelected;
    }

    this.getCheckedDeviceItemList();
  }

  isAllSelectedDevices(item, event) {
    if (event.target.checked == true) {
      this.selectedDevice.push(item.id);

      let obj = this._devicesList.find(o => o.id === item.id);
      obj.isSelected = true

    } else if (event.target.checked == false) {
      const index: number = this.selectedDevice.indexOf(item.id);
      if (index !== -1) {
        this.masterDevicesSelected = false;
        this.selectedDevice.splice(index, 1);
        let obj = this._devicesList.find(o => o.id === item.id);
        obj.isSelected = false
      }

    }
    this.masterDevicesSelected = this._devicesList.every(function (item: any) {
      return item.isSelected == true;
    })

    this.getCheckedDeviceItemList();
  }

  getCheckedDeviceItemList() {

    this.checkedDeviceList = [];
    for (var i = 0; i < this._devicesList.length; i++) {
      if (this._devicesList[i].isSelected)
        this.checkedDeviceList.push(this._devicesList[i]);
    }
    this.checkedDeviceList = JSON.stringify(this._devicesList);

    if (this.selectedDevice.length > 0) {
      this.isEnbled = false;
    }
    else {
      this.isEnbled = true;
    }
  }


  checkUncheckOtherDevices(event) {
    this.selectedOtherDevice = [];

    for (var i = 0; i < this._otherDevicesList.length; i++) {
      this._otherDevicesList[i].isSelected = this.masterOtherDevicesSelected;

      if (event.target.checked == true) {
        this._otherDevicesList.isSelected = true;
        this.selectedOtherDevice.push(this._otherDevicesList[i].id);
        this.otherCheckboxes.forEach((element) => {
          element.nativeElement.checked = true;
        });
      } else if (event.target.checked == false) {
        this._otherDevicesList.isSelected = false;
        this.selectedOtherDevice = [];
        this.otherCheckboxes.forEach((element) => {
          element.nativeElement.checked = false;
        });
      }
    }
    this.getCheckedOtherDeviceItemList();
  }

  isAllSelectedOtherDevices(item, event) {

    if (event.target.checked == true) {
      this.selectedOtherDevice.push(item.id);

      let obj = this._otherDevicesList.find(o => o.id === item.id);
      obj.isSelected = true

    } else if (event.target.checked == false) {
      const index: number = this.selectedOtherDevice.indexOf(item.id);
      if (index !== -1) {


        this.masterOtherDevicesSelected = false;
        this.selectedOtherDevice.splice(index, 1);
        let obj = this._otherDevicesList.find(o => o.id === item.id);
        obj.isSelected = false
      }
    }

    this.masterOtherDevicesSelected = this._otherDevicesList.every(function (item: any) {
      return item.isSelected == true;
    });

    this.getCheckedOtherDeviceItemList();
  }

  getCheckedOtherDeviceItemList() {

    this.checkedOtherDeviceList = [];
    for (var i = 0; i < this._otherDevicesList.length; i++) {
      if (this._otherDevicesList[i].isSelected)
        this.checkedOtherDeviceList.push(this._otherDevicesList[i]);
    }
    this.checkedOtherDeviceList = JSON.stringify(this._otherDevicesList);

    if (this.selectedOtherDevice.length > 0) {
      this.isEnbled = false;
    }
    else {
      this.isEnbled = true;
    }
  }

  sendData() {
    this._sharedService._device_group_ID = this._device_group_ID;
    this._sharedService.selectedDevice = this.selectedDevice;
    this._sharedService.selectedOtherDevice = this.selectedOtherDevice;

    this._sharedService.deviceGroupname = this.deviceGroupname;
    this._sharedService.creationDate = this.creationDate;
    this._sharedService.protectionPolicyGroup_id = this.protectionPolicyGroup_id;
    this._sharedService.protectedDevices = this.protectedDevices;
    this._sharedService.description = this.description;
    this._sharedService.isEditGroup = this._device_group_ID != null && this._device_group_ID != undefined && this._device_group_ID > 0 ? true : false;

    this._sharedService.sendMessage({
      "device_group": this._device_group_ID,
      "devices": this.selectedDevice,
      "devicesOther": this.selectedOtherDevice,
    });
    this.refreshList.emit("refresh");
    console.log('features/device refreshList'); console.log(this.refreshList);
    this._router.navigate(['/save-setting']);
  }

  back() {
    this._sharedService.isBackToGeneral = true;
    this._deviceService.isNext = false;
    this._sharedService.NavComponent();
    if (this._device_group_ID != null && this._device_group_ID != undefined)
      this._router.navigate(['/device-groups/general'], {
        queryParams: {
          deviceName: DeviceNav.DEVICE_GROUPS,
          deviceGroupID: this._device_group_ID, deviceID: this._device_group_ID, isEditGroup: this.isEditGroup, isDeviceInstallWizard: true
        }
      });
    else
      this._router.navigate(['/device-groups/general'])


  }

  private _setPaginationConfig(pageNumber, Type): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());

    let filterQueryParams = this.filterParams;


    // let filterQueryParams = {
    // };
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    // let sortQueryParams = {
    //   ordering: this.sortParamKey
    // };
    let sortQueryParams = {}

    //get pagination
    let paginationQueryParams = {
      page: pageNumber
    };

    //final query params
    let groupIdParams = {}
    if (Type == "Devices") {
      groupIdParams = {
        device_group: this._device_group_ID
      }
    } else {
      groupIdParams = {
        exclude_device_group: this._device_group_ID == undefined ? "" : this._device_group_ID
      }
    }

    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams, ...groupIdParams };
  }

  async onScrollDown(Type) {

    if (Type == "Devices") {


      await this.getDevicesGroup();

      if (this.masterDevicesSelected == true) {
        this.checkboxes.forEach((element) => {
          element.nativeElement.checked = true;
        });
      }


    }
    else {

      this.isOtherScrolling = true;
      await this.getOtherDevicesGroup();
      if (this.masterOtherDevicesSelected == true) {
        this.otherCheckboxes.forEach((element) => {
          element.nativeElement.checked = true;
        });
      }


    }

    // if (this.masterSelected == true)
    //   // await this.onScrollSelectAll();

    //   this.checkboxes.forEach((element) => {
    //     element.nativeElement.checked = true;
    //   });
    //   if (Type == "Devices") {

    //   }
    // this.isScroll = true;
    // this._fetchDataAndPopulate();
  }

}
