import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-innernav',
  templateUrl: './device-innernav.component.html',
  styleUrls: ['./device-innernav.component.css']
})
export class DeviceInnernavComponent implements OnInit {

  public isActive: boolean = true;

  constructor() { }

  ngOnInit(): void {
  }

}
