import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-type',
  templateUrl: './device-type.component.html',
  styleUrls: ['./device-type.component.css']
})
export class DeviceTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
