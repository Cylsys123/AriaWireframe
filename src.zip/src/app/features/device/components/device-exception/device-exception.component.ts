import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-exception',
  templateUrl: './device-exception.component.html',
  styleUrls: ['./device-exception.component.css']
})
export class DeviceExceptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
