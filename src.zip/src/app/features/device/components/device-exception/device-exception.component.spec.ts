import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceExceptionComponent } from './device-exception.component';

describe('DeviceExceptionComponent', () => {
  let component: DeviceExceptionComponent;
  let fixture: ComponentFixture<DeviceExceptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeviceExceptionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceExceptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
