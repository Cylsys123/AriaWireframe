import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-device',
  templateUrl: './new-device.component.html',
  styleUrls: ['./new-device.component.css']
})
export class NewDeviceComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }

  next() {
    this._router.navigateByUrl('/devices/protection-profile');
  }
}
