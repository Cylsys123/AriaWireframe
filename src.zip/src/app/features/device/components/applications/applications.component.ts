import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-applications',
  templateUrl: './applications.component.html',
  styleUrls: ['./applications.component.css']
})
export class ApplicationsComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }

  next() {
    this._router.navigateByUrl('/devices/hardware-performance');
  }
}
