import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Console } from 'console';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { NotificationService } from 'src/app/features/notification/services/notification.service';
import { DeviceNav } from 'src/app/shared/enum/shared.enum';
import { SharedService } from 'src/app/shared/services/shared.service';
import { DeviceService } from '../../services/device.service';

@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
  styleUrls: ['./device.component.css']
})
export class DeviceComponent implements OnInit {

  url: any = "device-groups"
  deviceArr: any = [];
  deviceGrpArr: any = [];
  groupByList: any = [];

  readonly globalLimit: number = 50;
  globalPageNumber: number = 1;
  isScrollDisable: boolean = false;
  totalRecords: number = 0;
  filterParams: any = {};
  sortParamKey: string = 'name';
  deviceUrl: any = "/devices"
  isOpened: boolean = false;
  refreshGrid: boolean = false;
  tooltipText: any;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _deviceService: DeviceService,
    private _sharedService: SharedService,
    private _notificationService: NotificationService,
    private _ngxLoader: NgxUiLoaderService,
    private translate: TranslateService,
  ) { }

  ngOnInit(): void {
    this._setPreData();
    this._fetchDataAndPopulate();

    this._notificationService.filterSharingSubject
      .subscribe((borrower) => {
        if (borrower['url'] == 'device') {
          this.filterParams = borrower['data'];
          this.globalPageNumber = 1;
          this.deviceArr[0]['data']['value'] = [];
          this._fetchDataAndPopulate();
        }
      }
      );

    this.tooltipText = `
      <div class="tooltiptxt" >
        <div class="row " >
          <div class="col-md-12">
            <p><span>Risk Lavel :</span>  URGENT. NEED ATTENTION</p>
          </div>
          <div class="col-md-12">
            <p><span>Summary :</span>  Your alerts indicates there are devices under attack and are not yet fully
                    protected by the AZT Prevent Protection Policy .</p>
          </div>
          <div class="col-md-12">
            <p><span>Actions :</span>   Use the ACTIONS buttons provided to change the protection policy to PREVENT mode.
            <a>Learn more...</a></p>
          </div>
        </div> 
      </div>`
  }

  refreshList($event: any) {
    console.log('this.refreshGrid '); console.log(this.refreshGrid);
    this.refreshGrid = true;
  }

  private _setPreData() {
    this.deviceGrpArr = this._route.snapshot.data['device']?.deviceGroups?.results;
    this.deviceArr.push(
      {
        "name": this.translate.instant("LBL_AZT_NEW_DEVICE"),
        "data": {
          "columnKeyName": [
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_RISK_LEVEL')
            },
            {
              colKey: 'status',
              colKeyLabel: this.translate.instant('LBL_AZT_STATUS')
            },
            {
              colKey: 'creation',
              colKeyLabel: this.translate.instant('LBL_AZT_AZT_DEPLOYED_DATE')
            },
            {
              colKey: 'name',
              colKeyLabel: this.translate.instant('LBL_AZT_DEVICE_NAME')
            },
            {
              colKey: 'ip',
              colKeyLabel: this.translate.instant('LBL_AZT_DEVICE_IP')
            },
            {
              colKey: 'os_name',
              colKeyLabel: this.translate.instant('LBL_AZT_OS')
            },

            {
              colKey: 'device_group_name',
              colKeyLabel: this.translate.instant('LBL_AZT_DEVICE_GROUPS')
            },

            {
              colKey: 'application_count',
              colKeyLabel: this.translate.instant('LBL_AZT_APP_COUNT')
            },
            {
              colKey: undefined,
              colKeyLabel: this.translate.instant('LBL_AZT_ACTION')
            }
          ],
          "value": []
        }
      });

    this.groupByList = [
      { name: 'All' },
      { name: 'Device group' },
      { name: 'Device type' },
      { name: 'Nofification' },
      { name: 'Alert' },
      { name: 'Valnerabilities' },
      { name: 'Policies' },
      { name: 'Integration' }
    ];
    this.getDevices()
  }

  changeDeviceGroup(value: any) {

    this._ngxLoader.start();
    this._deviceService.putDeviceApi(value['id'], { 'device_group': value['device_group'] }).subscribe((res) => {

      this._ngxLoader.stop();
      this._sharedService.getToastPopup('Successfully, updated device group', 'AZT Device', 'success');
    },
      (err) => {
        if (err.status == 403) {
          this._ngxLoader.stop();
          this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
        }
        else {
          this._ngxLoader.stop();
          this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
        }
      })
  }


  navigateUrl() {
    this._router.navigate(['device-group-wizard'], { queryParams: { deviceName: DeviceNav.DEVICE_GROUPS } });
  }

  showSortArrow(queryParamKey: string | undefined): boolean {
    return queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-');
  }

  sortTableCol(queryParamKey: string | undefined) {
    if (queryParamKey === this.sortParamKey.replace('-', '') && this.sortParamKey.includes('-')) {
      this.sortParamKey = queryParamKey;
    } else {
      this.sortParamKey = '-' + queryParamKey;
    }
    this.globalPageNumber = 1;
    if (this.isScrollDisable) this.isScrollDisable = false;
    this.deviceArr[0]['data']['value'] = [];
    this._fetchDataAndPopulate();
  }

  onScrollDown() {
    console.log('scroll');
    this._fetchDataAndPopulate();
  }

  private _setPaginationConfig(): object {
    //get filter
    //let filterData = this.removeEmpty(this.getFilterDataFunc());
    let filterQueryParams = this.filterParams;
    //get sorting
    // this.fetchDataAndPopulate(filterData, true);
    let sortQueryParams = {
      ordering: this.sortParamKey
    };

    //get pagination
    let paginationQueryParams = {
      page: this.globalPageNumber
    };

    //final query params
    return { ...filterQueryParams, ...sortQueryParams, ...paginationQueryParams };
  }

  private _fetchDataAndPopulate() {
    this._ngxLoader.start();
    let deviceQueryParams = this._setPaginationConfig();
    this._deviceService.getDevicesWithQueryApi(deviceQueryParams).subscribe(res => {
      this._ngxLoader.stop();

      if (res && res['count'] !== 0 && res['results'].length !== 0) {
        for (let index = 0; index < res['results'].length; index++) {
          var OneDay = new Date().getTime() + (1 * 24 * 60 * 60 * 1000)
          var last_seen = new Date(res['results'][index].last_seen).getTime();


          if (OneDay > last_seen) {
            res['results'][index].onlinestatus = "Offline";
          }
          else {
            res['results'][index].onlinestatus = "Online";
          }
          // var a = last_seen.
          // if (last_seen > )
        }

        this.deviceArr[0]['data']['value'].push(...res['results']);
        this.totalRecords = res['count'];
        if (this.totalRecords === this.deviceArr[0]['data']['value'].length) {
          this.isScrollDisable = true;
        }

        this.globalPageNumber += 1;
      }
    }, (err) => {
      this._ngxLoader.stop();
      if (err.status == 403) {
        this._sharedService.getToastPopup(err.error['detail'], 'AZT Device', 'error');
      }
      else {
        this._sharedService.getToastPopup('Internal server error', 'AZT Device', 'error');
      }
    });
  }

  getDevices() {
    this._deviceService.getDeviceGroupApi().subscribe((res) => {
      localStorage.setItem('devices', JSON.stringify(res));
    },
      (err) => {
        console.log('err'); console.log(err);
      })
  }
  tooltipOptions = {
    'placement': 'left',
    'showDelay': 500,
    'tooltip-class': 'riskTooltip'
  }

  isOpen() {
    return this.isOpened;
  }

  myTooltip() {
    this.isOpened = !this.isOpened;
    // let tootltipMessage = document.getElementById("safeTooltip")

    // return (tootltipMessage);

  }

}
