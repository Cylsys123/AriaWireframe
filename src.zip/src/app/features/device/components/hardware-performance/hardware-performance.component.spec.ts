import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HardwarePerformanceComponent } from './hardware-performance.component';

describe('HardwarePerformanceComponent', () => {
  let component: HardwarePerformanceComponent;
  let fixture: ComponentFixture<HardwarePerformanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HardwarePerformanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HardwarePerformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
