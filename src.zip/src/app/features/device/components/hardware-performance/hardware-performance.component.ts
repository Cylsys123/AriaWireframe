import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hardware-performance',
  templateUrl: './hardware-performance.component.html',
  styleUrls: ['./hardware-performance.component.css']
})
export class HardwarePerformanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
