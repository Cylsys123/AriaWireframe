import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { PolicyWizardMainComponent } from '../policy/components/policy-group-wizard/policy-wizard-main/policy-wizard-main.component';
import { AlertComponent } from './components/alert/alert.component';
import { ApplicationsComponent } from './components/applications/applications.component';
import { DeviceExceptionComponent } from './components/device-exception/device-exception.component';
import { DeviceAdvanceSettingsComponent } from './components/device-group-view/device-advance-settings/device-advance-settings.component';
import { DeviceApplicationsComponent } from './components/device-group-view/device-applications/device-applications.component';
import { DeviceDrillLevelComponent } from './components/device-group-view/device-drill-level/device-drill-level.component';
import { DeviceGroupSummaryComponent } from './components/device-group-view/device-group-summary/device-group-summary.component';
import { DeviceGroupWizardComponent } from './components/device-group-view/device-group-wizard/device-group-wizard.component';
import { DevicePolicyComponent } from './components/device-group-view/device-policy/device-policy.component';
import { DeviceProtectionModeComponent } from './components/device-group-view/device-protection-mode/device-protection-mode.component';
import { DevicesComponent } from './components/device-group-view/devices/devices.component';
import { GeneralDeviceComponent } from './components/device-group-view/general-device/general-device.component';
import { SaveSettingsComponent } from './components/device-group-view/save-settings/save-settings.component';
import { SourceDeviceComponent } from './components/device-group-view/source-device/source-device.component';
import { DeviceGroupComponent } from './components/device-group/device-group.component';
import { DeviceMainComponent } from './components/device-main/device-main.component';
import { DeviceTypeComponent } from './components/device-type/device-type.component';
import { DeviceComponent } from './components/device/device.component';
import { HardwarePerformanceComponent } from './components/hardware-performance/hardware-performance.component';
import { NewDeviceComponent } from './components/new-device/new-device.component';
import { ProtectionProfileComponent } from './components/protection-profile/protection-profile.component';
import { DeviceResolverService } from './services/device-resolver.service';

const routes: Routes = [
  { path: 'device-group-wizard', component: DeviceGroupWizardComponent },
  { path: 'save-setting', component: SaveSettingsComponent },

  {
    path: 'devices',
    component: DeviceMainComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', component: DeviceComponent, resolve: {device: DeviceResolverService} },
      { path: 'device-group', component: DeviceGroupComponent },
      { path: 'new-device', component: NewDeviceComponent },
      { path: 'protection-profile', component: ProtectionProfileComponent },
      { path: 'device-exception', component: DeviceExceptionComponent },
      { path: 'device-type', component: DeviceTypeComponent },
      { path: 'device-group-summary', component: DeviceGroupSummaryComponent, resolve: {device: DeviceResolverService}},
      { path: 'device-drill-level', component: DeviceDrillLevelComponent },
      { path: 'device-alert', component: AlertComponent },
      { path: 'applications', component: ApplicationsComponent },
      { path: 'hardware-performance', component: HardwarePerformanceComponent },
      { path: '**', redirectTo: '/devices', pathMatch: 'full' },
    ]
  },

  {
    path: 'device-groups',
    canActivate: [AuthGuard],
    component: PolicyWizardMainComponent,
    children: [
      { path: 'source-device', component: SourceDeviceComponent },
      { path: 'general', component: GeneralDeviceComponent },
      // {path: 'general/:id', component: GeneralDeviceComponent},
      { path: 'protection-mode', component: DeviceProtectionModeComponent },
      { path: 'protection-policy', component: DevicePolicyComponent },

      { path: 'device', component: DevicesComponent },
      { path: 'applications', component: DeviceApplicationsComponent },
      { path: 'device-setting', component: DeviceAdvanceSettingsComponent },
      { path: '**', redirectTo: '/device-group', pathMatch: 'full' },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DeviceRoutingModule { }
