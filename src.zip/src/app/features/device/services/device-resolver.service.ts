import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PolicyService } from '../../policy/services/policy.service';
import { DeviceService } from './device.service';

@Injectable({
  providedIn: 'root'
})
export class DeviceResolverService {

  constructor(private _deviceService: DeviceService,
              private _policyService: PolicyService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
    return forkJoin([
      this._deviceService.getDeviceGroupsWithQueryApi({}),
      this._policyService.getPolicyGroupsWithQueryApi({})
    ])
    .pipe(
      map(result=>{
        return {
          deviceGroups: result[0],
          policyGroups: result[1]
      };
      })
    )
  }
}
