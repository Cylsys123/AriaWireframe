import { Injectable } from '@angular/core';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';

@Injectable({
  providedIn: 'root'
})
export class DeviceService {
  isDeviceClone: boolean;
  is_defaultDevice: boolean = false;
  isNext:boolean = false;
  frmDeviceSetting: boolean;

  constructor(
    private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService,
  ) { }


  //dashboard/device/
  getDevicesApi(queryParamsObj) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDeviceEndpoint(queryParamsObj));
  }


  //dashboard/device/
  getDevicesWithQueryApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDeviceWithQueryParamsEndpoint(queryParamsObj));
  }

  //dashboard/device_group/
  getDeviceGroupsWithQueryApi(queryParamsObj: Object) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDeviceGroupWithQueryParamsEndpoint(queryParamsObj));
  }

  //dashboard/device_group/
  getDeviceGroupApi() {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDeviceGroupEndpoint());
  }

  //dashboard/device_group/
  putDeviceApi(id: string, body: any) {
    return this._apiHttpService
      .put(this._apiEndpointsService.getDeviceEndpoint(id), body);
  }

  //dashboard/device_group/
  putDeviceGroupApi(id: string, body: any) {
    return this._apiHttpService.patch(this._apiEndpointsService.getDeviceGroupEndpoint(id), body);
  }

  getDeviceGroupByIdApi(id: any) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDeviceGroupEndpoint(id));
  }

  //dashboard/device/id
  // getDevicesByGroup_IdApi(id){
  //   return this._apiHttpService
  //     .get(this._apiEndpointsService.getDeviceEndpoint(id));
  // }

  // public getDevicesByGroup_IdApi(device_group_Id){
  //   return this._apiHttpService
  //   .get(this._apiEndpointsService.getDevicesGroupEndpoint(device_group_Id));

  // }

  public getDevicesByGroup_IdApi(querParams) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDevicesWithQueryParamsEndpoint(querParams));

  }

  // public getOtherDevicesByGroup_IdApi(device_group_Id = 1) {
  //   return this._apiHttpService
  //     .get(this._apiEndpointsService.getOtherDevicesEndpoint(device_group_Id));

  // }

  public getOtherDevicesByGroup_IdApi(querParams) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getOtherDevicesWithQueryParamsEndpoint(querParams));

  }

  bulkUploadDeviceGroup(body: any) {
    return this._apiHttpService
      .post(this._apiEndpointsService.bulkChangeDeviceGroup(), body);
  }

  bulkUnRegisterDevices(body: any) {
    return this._apiHttpService
      .post(this._apiEndpointsService.bulkDevicesUnregister(), body);
  }

  addDeviceGroup(body: any) {
    return this._apiHttpService
      .post(this._apiEndpointsService.addDeviceGroup(), body);
  }


  updateDeviceGroup(id, body: any) {
    return this._apiHttpService
      .patch(this._apiEndpointsService.getDataByIdEndpoint(id), body);
  }

  deleteDeviceGroup(id) {
    return this._apiHttpService.delete(this._apiEndpointsService.deleteDeviceGroups(id));
  }

  getDeviceGroupNameApi(name: any) {
    return this._apiHttpService
      .get(this._apiEndpointsService.getDeviceGroupNameEndpoint(name));
  }

  getPolicyGroupsTempWithQueryApi(queryParamsObj:Object){
    return this._apiHttpService
      .get(this._apiEndpointsService.getPolicyGroupTempWithQueryParamsEndpoint(queryParamsObj));
  }

}
