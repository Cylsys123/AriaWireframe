import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, Observer } from 'rxjs';
import { ApiEndpointsService } from 'src/app/core/services/api-endpoints.service';
import { ApiHttpService } from 'src/app/core/services/api-http.service';

import * as Rx from "rxjs"
import { AnonymousSubject } from 'rxjs/internal/Subject';
import { map } from 'rxjs/operators';

import { webSocket } from 'rxjs/webSocket';

const wsUrl = "wss://tc-ui.eng.cspi.com/ws/";

const subject = webSocket(wsUrl);
@Injectable({
  providedIn: 'root'
})
export class SharedService {


  selectedDevice: any[] = [];
  selectedOtherDevice: any[] = [];
  _device_group_ID: any;
  _devicesData: Object;
  isBack: boolean = false;
  isUserLoggedIn: boolean = false
  isBackToGeneral = false;

  deviceGroupname = "";
  creationDate = "";
  protectionPolicyGroup_id = "";
  protectedDevices = "";
  description = "";

  isEditGroup: boolean;
  fromSourceDevgroup: boolean = false;
  isAddMode: boolean = false;

  isFrmAlert: boolean = false;
  isFrmDeviceGrp: boolean = false;

  private subject = new Subject<any>();

  frmDeviceGrp: boolean = false;
  frmAlert: boolean = false;

  isCancelFrmDeviceGrp: boolean = false;
  /**Wizard Nav Component General/Devices */
  public onNavComponent = new Subject<boolean>();
  alertIds: any;
  isCancelFrmAlert: boolean;
  isTrusted: boolean;
  devGroupname: any;
  public NavComponent() {
    this.onNavComponent.next(true);
  }

  alertObj = {
    id: "",
    device_id: "",
    category: "",
    status: ""
  };
  isSaved: boolean = false;

  deviceObj = {
    device_group_ID: "",
    deviceGroupname: "",
    creationDate: "",
    protectionPolicyGroup_id: "",
    protectedDevices: "",
    description: ""
  }



  constructor(
    private _toastr: ToastrService,
    private _apiHttpService: ApiHttpService,
    private _apiEndpointsService: ApiEndpointsService,
  ) {
    // this.messages = <Subject<any>>this.connect(wsUrl).pipe(
    //   map(
    //     (response: MessageEvent): any => {
    //       console.log(response.data);
    //       let data = JSON.parse(response.data)
    //       return data;
    //     }
    //   )
    // );
    // this.connect(wsUrl);
  }

  isLoggedIn() {
    return sessionStorage.getItem('isAuthenticated');
  }


  getToastPopup(errorMsg: string, errorModule: string, errorType: string) {
    switch (errorType) {
      case 'error':
        this._toastr.error(errorMsg, errorModule, {
          progressBar: true
        });
        break;
      case 'info':
        this._toastr.info(errorMsg, errorModule, {
          progressBar: true
        });
        break;
      case 'success':
        this._toastr.success(errorMsg, errorModule, {
          progressBar: true
        });
        break;
    }
  }


  sendMessage(devicesData: any) {
    this.subject.next({ data: devicesData });
  }

  clearMessage() {
    this.subject.next();
  }

  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }

  rtnSingleObjFromArrObj(arrObjParams, obj) {
    let key = Object.keys(obj)[0];
    return arrObjParams.filter(arrObjParam => arrObjParam[key] == obj[key])[0];
  }

  _replaceArrayObject(arr1, arr2) {
    return arr1.map(obj => arr2.find(o => o.key === obj.key) || obj);
  }

  _removeObjectFromArray(arr1,data){
    return arr1.filter(obj => obj.key != data.key);
  }


  /////////////////////////Websocket Implementation





  // public connect(url): Rx.Subject<MessageEvent> {
  //   if (!this.subject) {
  //     this.subject = this.create(url);
  //     console.log("Successfully connected: " + url);
  //   }
  //   return this.subject;
  // }

  // private create(url): Rx.Subject<MessageEvent> {
  //   let ws = new WebSocket(url);

  //   let observable = Rx.Observable.create((obs: Rx.Observer<MessageEvent>) => {
  //     ws.onmessage = obs.next.bind(obs);
  //     ws.onerror = obs.error.bind(obs);
  //     ws.onclose = obs.complete.bind(obs);
  //     return ws.close.bind(ws);
  //   });
  //   let observer = {
  //     next: (data: Object) => {
  //       if (ws.readyState === WebSocket.OPEN) {
  //         ws.send(JSON.stringify(data));
  //       }
  //     }
  //   };
  //   return Rx.Subject.create(observer, observable);
  // }

  // public send() {
  //   let ws = new WebSocket("wss://tc-ui.eng.cspi.com/ws/")
  //   ws.onopen = function (e) {
      
  //     setInterval(() => {
  //       ws.send(JSON.stringify({
  //         action: "list",
  //         request_id: new Date().getTime(),
  //         cookies: 'j73f3z2dohofrwvly5hi7o7cg1i5atkc',
  //         csrftoken: 'CVw1VYUrA0Yw9q5Q7hfJIg6BRKp8pSev'
  //       }))
  //     }, 3000);
      
  //   }
  //   ws.onmessage = function (e) {
  //     console.log(e)
  //   }
  //   ws.onerror = (e) => {
  //     console.log(e)
  //   }
  // }

}
