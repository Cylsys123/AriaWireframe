import { AfterContentChecked, Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { NetworkSetupType } from 'src/app/shared/enum/shared.enum';


@Component({
  selector: 'app-wizard-header',
  templateUrl: './wizard-header.component.html',

  styleUrls: ['./wizard-header.component.css']
})
export class WizardHeaderComponent implements OnInit, AfterContentChecked {
  title: string = '';
  constructor(
    private translate: TranslateService
  ) { }

  ngOnInit(): void {

  }

  setTitle() {
    switch (location.pathname) {
      case '/post-install-wizard':
        this.title = this.translate.instant('LBL_AZT_AZT_POST_INSTALL_WIZARD');
        break;

      case '/post-install-wizard/network-setup':
        this.title = this.translate.instant('LBL_AZT_NETWORK_SETUP');
        break;

      case '/post-install-wizard/host-server/' + NetworkSetupType.AIRGAPPED:
      case '/post-install-wizard/host-server/' + NetworkSetupType.DIRECT_ONLINE:
      case '/post-install-wizard/host-server/' + NetworkSetupType.PROXY_ENABLED:
        this.title = this.translate.instant('LBL_AZT_TRUST_CENTER_HOST_NETWORK_DETAIL');
        break;

      case '/post-install-wizard/admin-account':
        this.title = this.translate.instant('LBL_AZT_ADMINISTRATION_ACCOUNT');
        break;

      case '/post-install-wizard/site-profile':
        this.title = this.translate.instant('LBL_AZT_SITE_PROFILE');
        break;

      case '/post-install-wizard/ntp-dns-mail':
        this.title = this.translate.instant('LBL_AZT_NTP_DNS_MAIL_DETAILS');
        break;

      case '/policy-group/source-policy':
        this.title = this.translate.instant("LBL_AZT_POLICY_GROUP_WIZARD") + " / " + this.translate.instant("LBL_AZT_SOURCE_POLICY_GROUP");
        break;

      case '/policy-group/general':
        this.title = this.translate.instant('LBL_AZT_POLICY_GROUP_WIZARD') + " / " +  this.translate.instant('LBL_AZT_GENERAL_POLICY_GROUP');
        break;

      case '/policy-group/protection-mode':
        this.title = this.translate.instant('LBL_AZT_POLICY_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROTECTION_MODE');
        break;

      case '/policy-group/protection-policy':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROTECTION_POLICY');
        break;

      case '/policy-group/exception-policy':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_EXCEPTION_POLICY');
        break;

      case '/policy-group/notification-policy':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_NOTIFICATION_POLICIES');
        break;

      case '/policy-group/miscellaneous-policy':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_MISCELLANEOUS_POLICIES');
        break;

      case '/policy-group/device-groups':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_DEVICE_GROUPS');
        break;

      case '/policy-group/properties':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROPERTIES');
        break;

      // protection policies

      case '/protection-policies/source-policy':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_SOURCE_POLICY_GROUP');
        break;
      case '/protection-policies/general':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_GENERAL_POLICY_GROUP');
        break;
      case '/protection-policies/protection-mode':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROTECTION_MODE');
        break;

      case '/protection-policies/properties':
        this.title = this.translate.instant('LBL_AZT_PROTECTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROPERTIES');
        break;

      // exception policies

      case '/exception-policies/source-policy':
        this.title = this.translate.instant('LBL_AZT_EXCEPTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_SOURCE_POLICY_GROUP');
        break;
      case '/exception-policies/general':
        this.title = this.translate.instant('LBL_AZT_EXCEPTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_GENERAL');
        break;;
        break;


      case '/exception-policies/properties':
        this.title = this.translate.instant('LBL_AZT_EXCEPTION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROPERTIES');
        break;

      // notification policies

      case '/notification-policies/source-policy':
        this.title = this.translate.instant('LBL_AZT_NOTIFICATION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_SOURCE_POLICY_GROUP');
        break;
      case '/notification-policies/general':
        this.title = this.translate.instant('LBL_AZT_NOTIFICATION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_GENERAL_POLICY_GROUP');
        break;

      case '/notification-policies/properties':
        this.title = this.translate.instant('LBL_AZT_NOTIFICATION_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROPERTIES');    
        break;
      
        // system policies

      case '/system-policies/source-policy':
        this.title = this.translate.instant('LBL_AZT_SYSTEM_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_SOURCE_POLICY_GROUP');  
        break;
      case '/system-policies/general':
        this.title = this.translate.instant('LBL_AZT_SYSTEM_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_GENERAL_POLICY_GROUP');
        break;

      case '/system-policies/properties':
        this.title = this.translate.instant('LBL_AZT_SYSTEM_POLICY_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROPERTIES');
        break;

        // Device group

        case '/device-groups/source-device':
        this.title = this.translate.instant('LBL_AZT_DEVICE_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_SOURCE_DEVICE_GROUP');
        break;

        case '/device-groups/general':
        this.title = this.translate.instant('LBL_AZT_DEVICE_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_GENERAL');
        break;
        case '/device-groups/protection-mode':
          this.title = this.translate.instant('LBL_AZT_DEVICE_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_PROTECTION_MODE');
          break;
        
          case '/device-groups/device':
          this.title = this.translate.instant('LBL_AZT_DEVICE_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_EXCEPTION_POLICY');
          break;

        case '/device-groups/device-application':
          this.title = this.translate.instant('LBL_AZT_DEVICE_GROUP_WIZARD') + " / " + this.translate.instant('LBL_AZT_NOTIFICATION_POLICIES');
          break;
    }
  }

  ngAfterContentChecked(): void {
    this.setTitle();
  }
}
