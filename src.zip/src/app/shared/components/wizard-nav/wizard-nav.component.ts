import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PolicyService } from 'src/app/features/policy/services/policy.service';
import { DeviceService } from 'src/app/features/device/services/device.service';
import { IPostInstallWizardForms } from 'src/app/features/post-install-wizard/models/ipost-install-wizard-forms';
import { PostInstallWizardService } from 'src/app/features/post-install-wizard/services/post-install-wizard.service';
import { DeviceNav, PolicyNav } from '../../enum/shared.enum';
import { SharedService } from '../../services/shared.service';

@Component({
  selector: 'app-wizard-nav',
  templateUrl: './wizard-nav.component.html',
  styleUrls: ['./wizard-nav.component.css']
})
export class WizardNavComponent implements OnInit {

  isPolicyInstallWizard: any = false;
  isDeviceInstallWizard: any = false;
  isPolicyCloneUrl: any = false;
  isDeviceCloneUrl: any = false;
  isAdd: any = false;
  policyName: string | null = 'N/A';
  deviceName: string | null = 'N/A';
  getWizardNavigations: any = [];
  postInstallWizardFormValues: IPostInstallWizardForms;

  constructor(
    private _route: ActivatedRoute,
    private _postInstalllWizardServ: PostInstallWizardService,
    private _sharedService: SharedService,
    private _router: Router,
    private _policyService: PolicyService,
    private _deviceService:DeviceService
  ) { }

  ngOnInit(): void {


    this.getPolicyNavObs();
    this.postInstallWizardFormValues = this._postInstalllWizardServ.postInstallFormValues;
    if (this.isPolicyInstallWizard) this.generatePolicyNavigation();
    else this.generateWizardNavigation();

    this._sharedService.onNavComponent.subscribe(value => {
      this.generateWizardNavigation();
    });
    this._policyService.checkClonedPolicySubject.subscribe(value => {
      this.isPolicyInstallWizard = true;
      this.policyName = PolicyNav.POLICY_GROUPS;
      this.isPolicyCloneUrl = 'true';
      this.generatePolicyNavigation();
    })
  }

  getPolicyNavObs() {

    this.isDeviceInstallWizard = this._route.snapshot.queryParams['isDeviceInstallWizard'];
    this.isPolicyInstallWizard = this._route.snapshot.queryParams['isPolicyInstallWizard'];
    this.isPolicyCloneUrl = this._route.snapshot.queryParams['isPolicyCloneUrl'];
    this.isDeviceCloneUrl = this._route.snapshot.queryParams['isDeviceCloneUrl'];
    this.isAdd = this._route.snapshot.queryParams['isAdd']
    this.policyName = this._route.snapshot.queryParams['policyName'];
    this.deviceName = this._route.snapshot.queryParams['deviceName'];
  }

  fnNavigateDevices(getWizardNavigation) {   

    
    for (let index = 0; index < this.getWizardNavigations.length; index++) {
      
      if(this.getWizardNavigations[index].navName == getWizardNavigation.navName){
        this.getWizardNavigations[index].isActive = true;  
      }
      else {
        this.getWizardNavigations[index].isActive = false;  
      }
    }

    this._router.navigate([getWizardNavigation['routerLink']])
  }

  generateWizardNavigation() {
    if (this.isDeviceInstallWizard) {
      switch (this.deviceName) {
        case DeviceNav.DEVICE_GROUPS:

          let routerLink = '/device-groups/device'

          if (this._sharedService.isSaved) {
            routerLink = '/device-groups/device'
          }
          else {
            routerLink = '/device-groups/general';
          }

          this.getWizardNavigations = [
            {
              isActive: !this._deviceService.isNext? true: false,
              routerLink: '/device-groups/general',
              navName: 'General',
            },


            // {
            //   isActive: false,
            //   routerLink: '/device-groups/protection-mode',
            //   navName: 'Protection Mode',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/device-groups/protection-policy',
            //   navName: 'Policy Group',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/device-groups/exception-policy',
            //   navName: 'Exception Policies',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/device-groups/notification-policy',
            //   navName: 'Notification Policies',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/device-groups/system-policy',
            //   navName: 'System Policies',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/device-groups/miscellaneous-policy',
            //   navName: 'Miscellaneous Policies',
            // },
            {
              isActive: this._deviceService.isNext? true: false,
              routerLink: routerLink,
              navName: 'Devices',
            }
            // {
            //   isActive: false,
            //   routerLink: '/device-groups/applications',
            //   navName: 'Application',
            // }
          ]

          if (this.isDeviceCloneUrl == 'true') {
            this.getWizardNavigations.unshift({
              isActive: this.isDeviceCloneUrl,
              routerLink: '/device-groups/source-device',
              navName: 'Source Device Group',
            })
          }
          break;

        case PolicyNav.PROTECTION_POLICIES:
          this.getWizardNavigations = [
            {
              isActive: !this.isDeviceCloneUrl,
              routerLink: '/protection-policies/general',
              navName: 'General',
            },
            {
              isActive: false,
              routerLink: '/protection-policies/protection-mode',
              navName: 'Protection Mode',
            },
            {
              isActive: false,
              routerLink: '/protection-policies/properties',
              navName: 'Properties',
            }
          ];
          if (this.isDeviceCloneUrl == 'true') {
            this.getWizardNavigations.unshift({
              isActive: this.isDeviceCloneUrl,
              routerLink: '/protection-policies/source-policy',
              navName: 'Source Policy',
            })
          }
          break;

        case PolicyNav.EXCEPTION_POLICIES:
        case PolicyNav.NOTIFICATION_POLICIES:
          this.getWizardNavigations = [
            {
              isActive: !this.isDeviceCloneUrl,
              routerLink: PolicyNav.EXCEPTION_POLICIES == this.policyName ? '/exception-policies/general' : '/notification-policies/general',
              navName: 'General',
            },
            {
              isActive: false,
              routerLink: PolicyNav.EXCEPTION_POLICIES == this.policyName ? '/exception-policies/properties' : '/notification-policies/properties',
              navName: 'Properties',
            }
          ];
          if (this.isDeviceCloneUrl == 'true') {
            this.getWizardNavigations.unshift({
              isActive: this.isDeviceCloneUrl,
              routerLink: PolicyNav.EXCEPTION_POLICIES == this.policyName ? '/exception-policies/source-policy' : '/notification-policies/source-policy',
              navName: 'Source Policy',
            })
          }
          break;

        case PolicyNav.SYSTEM_POLICIES:
        case PolicyNav.SYSTEM_POLICIES:
          this.getWizardNavigations = [
            {
              isActive: !this.isDeviceCloneUrl,
              routerLink: PolicyNav.SYSTEM_POLICIES == this.policyName ? '/system-policies/general' : '/system-policies/general',
              navName: 'General',
            },
            {
              isActive: false,
              routerLink: PolicyNav.SYSTEM_POLICIES == this.policyName ? '/system-policies/properties' : '/system-policies/properties',
              navName: 'Properties',
            }
          ];
          if (this.isDeviceCloneUrl == 'true') {
            this.getWizardNavigations.unshift({
              isActive: this.isDeviceCloneUrl,
              routerLink: PolicyNav.SYSTEM_POLICIES == this.policyName ? '/system-policies/source-policy' : '/system-policies/source-policy',
              navName: 'Source Policy',
            })
          }
          break;
      }
    }
  }

  generatePolicyNavigation() {
    if (this.isPolicyInstallWizard) {
      switch (this.policyName) {
        case PolicyNav.POLICY_GROUPS:
          this.getWizardNavigations = [
            {
              isActive: !this.isPolicyCloneUrl,
              routerLink: '/policy-group/general',
              navName: 'General',
              isDisable: this.isPolicyCloneUrl == 'true' && !this._policyService.policyGroupFormValues['isPolicyGroupCloned']
            },
            // {
            //   isActive: false,
            //   routerLink: '/policy-group/protection-mode',
            //   navName: 'Protection Mode',
            // },
            {
              isActive: false,
              routerLink: '/policy-group/protection-policy',
              navName: 'Protection Policies',
              isDisable: this.isPolicyCloneUrl == 'true' && !this._policyService.policyGroupFormValues['isPolicyGroupCloned']
            },
            // {
            //   isActive: false,
            //   routerLink: '/policy-group/exception-policy',
            //   navName: 'Exception Policies',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/policy-group/notification-policy',
            //   navName: 'Notification Policies',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/policy-group/system-policy',
            //   navName: 'System Policies',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/policy-group/miscellaneous-policy',
            //   navName: 'Miscellaneous Policies',
            // },
            // {
            //   isActive: false,
            //   routerLink: '/policy-group/device-groups',
            //   navName: 'Device Groups',
            // },
            // {
            //   isActive: false,
            //   routerLink:'/policy-group/properties',
            //   navName:'Properties',
            // }
          ]
          if (this.isPolicyCloneUrl == 'true') {
            this.getWizardNavigations.unshift({
              isActive: this.isPolicyCloneUrl,
              routerLink: '/policy-group/source-policy',
              navName: 'Source Policy Group',
              isDisable: false
            })
          }
          break;

        case PolicyNav.PROTECTION_POLICIES:
          this.getWizardNavigations = [
            {
              isActive: !this.isPolicyCloneUrl,
              routerLink: '/protection-policies/general',
              navName: 'General',
            },
            {
              isActive: false,
              routerLink: '/protection-policies/protection-mode',
              navName: 'Protection Mode',
            },
            {
              isActive: false,
              routerLink: '/protection-policies/properties',
              navName: 'Properties',
            }
          ];
          if (this.isPolicyCloneUrl == 'true') {
            this.getWizardNavigations.unshift({
              isActive: this.isPolicyCloneUrl,
              routerLink: '/protection-policies/source-policy',
              navName: 'Source Policy',
            })
          }
          break;
        case PolicyNav.EXCEPTION_POLICIES:
        case PolicyNav.NOTIFICATION_POLICIES:
          this.getWizardNavigations = [
            {
              isActive: !this.isPolicyCloneUrl,
              routerLink: PolicyNav.EXCEPTION_POLICIES == this.policyName ? '/exception-policies/general' : '/notification-policies/general',
              navName: 'General',
            },
            {
              isActive: false,
              routerLink: PolicyNav.EXCEPTION_POLICIES == this.policyName ? '/exception-policies/properties' : '/notification-policies/properties',
              navName: 'Properties',
            }
          ];
          if (this.isPolicyCloneUrl == 'true') {
            this.getWizardNavigations.unshift({
              isActive: this.isPolicyCloneUrl,
              routerLink: PolicyNav.EXCEPTION_POLICIES == this.policyName ? '/exception-policies/source-policy' : '/notification-policies/source-policy',
              navName: 'Source Policy',
            })
          }
          break;

        default:
          this.getWizardNavigations = [
            {
              isActive: !this.isPolicyCloneUrl,
              routerLink: '/policy-group/general',
              navName: 'General',
            },
            {
              isActive: false,
              routerLink: '/policy-group/protection-policy',
              navName: 'Protection Policies',
            }
          ]
      }
    }
  }
}