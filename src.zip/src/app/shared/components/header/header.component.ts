import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { NgxUiLoaderService } from "ngx-ui-loader";
import { AuthService } from "src/app/features/auth/services/auth.service";
import { SharedService } from "../../services/shared.service";

import { webSocket, WebSocketSubject } from "rxjs/webSocket";
import { IfStmt } from "@angular/compiler";

const _subject = new WebSocket('wss://tc-ui.eng.cspi.com/ws/');
@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
})

export class HeaderComponent implements OnInit {
  isCollapsed: boolean = false;
  isOpened: boolean = false;
  username: string = "";
  count: number = 0;
  lstReports: any = [];
  subject = webSocket('wss://tc-ui.eng.cspi.com/ws/')


  constructor(
    private _authService: AuthService,
    private _router: Router,
    private _sharedService: SharedService,
    private _ngxLoader: NgxUiLoaderService
  ) {


  }

  ngOnInit(): void {

    _subject.onopen = function (e) {
      _subject.send(
        JSON.stringify({
          action: "subscribe_to_notification_activity",
          request_id: new Date().getTime(),
        })
      );

      _subject.send(
        JSON.stringify({
          action: "list",
          request_id: new Date().getTime(),
        })
      );
    };
    _subject.addEventListener("message", (event) => {
      this.count += 1;
      if (_subject.readyState === _subject.OPEN) {

        if (JSON.parse(event.data).action == 'list') {
          if (JSON.parse(event.data).seen == false)
            this.lstReports.push(JSON.parse(event.data));
        }
        else {

          if (JSON.parse(event.data).seen == false) {
            this.lstReports.push(JSON.parse(event.data));
            let msg = JSON.parse(event.data).context + ' ' + JSON.parse(event.data).message
            this._sharedService.getToastPopup(msg, "Report", "success");
          }
        }
      }

    });
    _subject.onerror = (e) => {
      console.log(e);
    };

    let userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
    this.username = userInfo["first_name"] + " " + userInfo["last_name"];
  }


  isCollapse() {
    return this.isCollapsed;
  }

  async fnReport() {
    this.count = 0;
    for (let index = 0; index < this.lstReports.length; index++) {
      if (_subject.readyState === _subject.OPEN) {
        await _subject.send(
          JSON.stringify({
            action: "patch",
            request_id: new Date().getTime(),
            pk: this.lstReports[index].id,
            data: {
              seen: true,
            },
          }),
        );
      }
    }
    await _subject.send(
      JSON.stringify({
        action: "list",
        request_id: new Date().getTime(),
      })
    );

    this._router.navigate(["/reports/reportsActivity"]);
  }

  onClickLogout() {
    this._ngxLoader.start();
    this._authService.getLogoutApi().subscribe(
      (res) => {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup("Logout Success! Redirecting...", "AZT Logout", "success");
        sessionStorage.setItem("isAuthenticated", "false");
        this._sharedService.isUserLoggedIn = false;
        localStorage.setItem("isUserLoggedIn", "false");
        this._router.navigate(["login"]);
      },
      (err) => {
        this._ngxLoader.stop();
        this._sharedService.getToastPopup("Internal Server Error", "AZT Error", "error");
      }
    );
  }
}
