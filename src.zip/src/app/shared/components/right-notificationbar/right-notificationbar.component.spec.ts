import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RightNotificationbarComponent } from './right-notificationbar.component';

describe('RightNotificationbarComponent', () => {
  let component: RightNotificationbarComponent;
  let fixture: ComponentFixture<RightNotificationbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RightNotificationbarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RightNotificationbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
