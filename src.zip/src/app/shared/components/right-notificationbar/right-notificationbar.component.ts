import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-notificationbar',
  templateUrl: './right-notificationbar.component.html',
  styleUrls: ['./right-notificationbar.component.css']
})
export class RightNotificationbarComponent implements OnInit {
  isOpened: boolean=false;
  constructor() { }

  ngOnInit(): void {
  }
  isOpen(){
    return this.isOpened;
   }
  showHide(){
    this.isOpened=!this.isOpened;
  }
}
