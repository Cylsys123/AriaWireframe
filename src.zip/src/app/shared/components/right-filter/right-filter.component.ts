import { DatePipe } from '@angular/common';
import { Component, Input, OnChanges, OnInit, SimpleChange, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { DeviceService } from 'src/app/features/device/services/device.service';
import { NotificationService } from 'src/app/features/notification/services/notification.service';

@Component({
  selector: 'app-right-filter',
  templateUrl: './right-filter.component.html',
  styleUrls: ['./right-filter.component.css']
})
export class RightFilterComponent implements OnInit, OnChanges {
  isOpened: boolean = false;
  latestAlertCatArr: any = [];
  latestAlertStatusArr: any = [];
  latestdeviceGroupArr: any = [];
  latestdeviceGroupArr2: any = [];
  latestdeviceGroupsArr: any = [];
  latestOSArr: any = [];
  triggerFileArr: any = [];
  triggerFileArrItem: any = [];
  selectedFilterArr: any = [];
  aggregrate: boolean = false;
  detectDate: number = 0;
  dateDeployed: number = 0;
  isAuditTrail: boolean = false;
  isAlert: boolean = false
  isDevice: boolean = false
  isDeviceGroups: boolean = false;
  @Input() url: string;
  @Input() refreshGrid: boolean = false;


  eventTypeArr: any = [];
  eventTypeArrItem: any = [];

  usernameArr: any = [];
  usernameArrItem: any = [];

  constructor(
    private _notificationService: NotificationService,
    private _deviceService: DeviceService,
    private translate: TranslateService,
    public datepipe: DatePipe,
  ) { }


  ngOnChanges(changes: SimpleChanges) {
    if (changes['url']['currentValue'] && !changes['url'].isFirstChange()) {
      this._checkUrl();
    }

    if (this.refreshGrid) {
      this._deviceService.getDeviceGroupApi().subscribe((res) => {
        localStorage.setItem('devices', JSON.stringify(res));
        console.log('localStorage in right filter'); console.log(localStorage);
      },
        (err) => {
          console.log('err'); console.log(err);
        })
    }

  }

  ngOnInit(): void {
    this._initSetCatAndStatus();
  }

  private _initSetCatAndStatus() {
    this._checkUrl();
  }

  private _checkUrl() {

    if (this.url == '/devices') {
      this.isAuditTrail = false;
      this.isAlert = false;
      this.isDeviceGroups = false;
      this.isDevice = true;

      let latestdeviceGroupArr = JSON.parse(localStorage.getItem('devices'));
      this.latestdeviceGroupArr2 = latestdeviceGroupArr['results'].map((latestAlertCat) => {
        return { key: latestAlertCat['id'], value: latestAlertCat['name'], 'selected': false }
      });

      let latestOSArr = JSON.parse(localStorage.getItem('devices'));
      this.latestOSArr = latestOSArr['results'].map((latestAlertCat) => {
        //return { key: 'policy_group_name', value: latestAlertCat['policy_group_name'], 'selected': false }
        return { key: 'os_name', value: latestAlertCat['os_name'], 'selected': false }
      });

      this.latestOSArr = [...new Map(this.latestOSArr.map(item =>
        [item['value'], item])).values()];


    }

    if (this.url == '/device-groups') {
      this.isAuditTrail = false;
      this.isAlert = false;
      this.isDeviceGroups = true;
      this.isDevice = false;
      let latestdeviceGroupArr = JSON.parse(localStorage.getItem('deviceGroup'));

      this.latestdeviceGroupArr = latestdeviceGroupArr['results'].map((latestAlertCat) => {
        //return { key: 'policy_group_name', value: latestAlertCat['policy_group_name'], 'selected': false }
        return { key: latestAlertCat['policy_group'], value: latestAlertCat['policy_group_name'], 'selected': false }
      });

      this.latestdeviceGroupArr = [...new Map(this.latestdeviceGroupArr.map(item =>
        [item['value'], item])).values()];


    }

    if (this.url == '/notification') {
      this.isAlert = true;
      this.isAuditTrail = false;
      this.isDeviceGroups = false;
      this.isDevice = false;

      let latestAlertCatArr = JSON.parse(localStorage.getItem('alertCategory'));
      this.latestAlertCatArr = latestAlertCatArr['Categories'].map((latestAlertCat) => {
        return { key: this.getKeys(latestAlertCat), value: this.getValue(latestAlertCat), 'selected': false }
      });
      // this.latestAlertCatArr.unshift({key:'-1',value:'ALL NOTIFICATION TYPE','selected':false});


      let latestAlertStatusArr = JSON.parse(localStorage.getItem('alertStatus'));
      this.latestAlertStatusArr = latestAlertStatusArr['Status'].map((latestAlertCat) => {
        return { key: this.getKeys(latestAlertCat), value: this.getValue(latestAlertCat), 'selected': false }
      });
      // this.latestAlertStatusArr.unshift({key:'-1',value:'ALL STATUS ','selected':false});


      let triggerFileArr = JSON.parse(localStorage.getItem('triggerFile'));
      this.triggerFileArrItem = triggerFileArr['filenames'].map((triggerFile) => {
        return { key: triggerFile, value: triggerFile, 'selected': false }
      });

      this.assignTriggerFileCopy();

    }

    if (this.url == '/notification/auditTrailLogs') {
      this.isAuditTrail = true;
      this.isAlert = false;
      this.isDevice = false;
      this.isDeviceGroups = false;

      //event 

      let eventTypeArr = Object.entries(JSON.parse(localStorage.getItem('eventType')));
      this.eventTypeArrItem = eventTypeArr.map((eventType) => {
        return { key: eventType[0], value: eventType[1], 'selected': false }
      });

      this.assignEventTypeCopy();


      //username

      let usernameArr = JSON.parse(localStorage.getItem('username'));
      this.usernameArrItem = usernameArr['users'].map((username) => {
        return { key: username, value: username, 'selected': false }
      });

      this.assignUsernameCopy();
    }
  }

  assignTriggerFileCopy() {
    this.triggerFileArr = Object.assign([], this.triggerFileArrItem);
  }

  filterTriggerItem(value) {
    if (!value) {
      this.assignTriggerFileCopy();
    } // when nothing has typed
    this.triggerFileArr = Object.assign([], this.triggerFileArrItem).filter(
      item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
    )
  }

  assignEventTypeCopy() {
    this.eventTypeArr = Object.assign([], this.eventTypeArrItem);
  }

  filterEventTypeItem(value) {
    if (!value) {
      this.assignEventTypeCopy();
    } // when nothing has typed
    this.eventTypeArr = Object.assign([], this.eventTypeArrItem).filter(
      item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
    )
  }

  assignUsernameCopy() {
    this.usernameArr = Object.assign([], this.usernameArrItem);
  }

  filterUsernameItem(value) {
    if (!value) {
      this.assignUsernameCopy();
    } // when nothing has typed
    this.usernameArr = Object.assign([], this.usernameArrItem).filter(
      item => item.value.toLowerCase().indexOf(value.toLowerCase()) > -1
    )
  }


  isOpen() {
    return this.isOpened;
  }
  showHide() {
    this.isOpened = !this.isOpened;
  }

  getValue(value) {
    return Object.values(value)[0];
  }

  getKeys(value) {
    return Object.keys(value)[0];
  }

  clearFilter(selectedFilterObj = undefined) {
    if (selectedFilterObj === undefined) {
      this.selectedFilterArr = [];
      this.aggregrate = false;
      this.detectDate = 0;
      this.dateDeployed = 0;
      this._initSetCatAndStatus();
      let nextData = {};
      if (nextData['url'] = 'alert') {
        this._notificationService.filterSharingSubject.next(nextData);
      }
      if (nextData['url'] = 'audit') {
        this._notificationService.filterSharingSubject.next(nextData);
      }
      if (nextData['url'] = 'device') {
        this._notificationService.filterSharingSubject.next(nextData);
      }
      if (nextData['url'] = 'device-groups') {
        this._notificationService.filterSharingSubject.next(nextData);
      }

      // this._notificationService.filterSharingSubject.next({});
    }
  }

  onSelectFilter(selectedFilterObj, category = undefined) {
    switch (category) {
      case 'AGGREGATE':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_AGGREGATE"),
          filterSubCatNam: undefined,
          filterSubCatId: -1 // -1 means all
        });
        if (selectedFilterObj) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        }
        break;

      case 'DETECT_DATE':
        this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_DETECT_DATE"),
          filterSubCatNam: this.getDetectDate(selectedFilterObj),
          filterSubCatId: selectedFilterObj // -1 means all
        });
        break;

      case 'DETECT_DEVICE_STATUS':
        this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_STATUS"),
          filterSubCatNam: this.getDeviceStatus(selectedFilterObj),
          filterSubCatId: selectedFilterObj // -1 means all
        });
        break;

      case 'POLICY_GROUP':
        this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_POLICY_GROUP"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key'] // -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

      case 'STATUS':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_STATUS_SM"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key'] // -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        // if(selectedFilterObj['key'] == '-1'){
        //   if(!selectedFilterObj['selected']){
        //     this.latestAlertStatusArr.map((latestAlertStatus)=>{
        //       latestAlertStatus.selected = true;
        //     });
        //     //remove other
        //     this.selectedFilterArr = this.selectedFilterArr.filter(function(el) { return el.filterCatType != category || (el.filterCatType == category && el.filterSubCatId == '-1') ; });
        //   }else{
        //     this.latestAlertStatusArr.map((latestAlertStatus)=>{
        //       latestAlertStatus.selected = false;
        //     });
        //     this.selectedFilterArr = this.selectedFilterArr.filter(function(el) { return el.filterCatType != category });
        //   }
        // }
        break;

      case 'NOTIFICATION_TYPE':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_NOTIFICATION_TYPE"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key']// -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        // if(selectedFilterObj['key'] == '-1' ){
        //   if(!selectedFilterObj['selected']){
        //     this.latestAlertCatArr.map((latestAlertCat)=>{
        //       latestAlertCat.selected = true;
        //     });
        //     this.selectedFilterArr = this.selectedFilterArr.filter(function(el) { return el.filterCatType != category || (el.filterCatType == category && el.filterSubCatId == '-1') });
        //   }else{
        //     this.latestAlertCatArr.map((latestAlertCat)=>{
        //       latestAlertCat.selected = false;
        //     });
        //     this.selectedFilterArr = this.selectedFilterArr.filter(function(el) { return el.filterCatType != category }); 
        //   }
        // }
        break;

      case 'TRIGGER_FILE':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_TRIGGER_FILE"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key']// -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

      case 'EVENT_TYPE':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_EVENT_TYPE"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key']// -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

      case 'USERNAME':
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_USERNAME"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key']// -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

      case 'DATE_LAST_MODIFIED':
        this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_DATE_LAST_MODIFIED"),
          filterSubCatNam: this.getDetectDate(selectedFilterObj),
          filterSubCatId: selectedFilterObj // -1 means all
        });
        break;

      case 'DATE_DEPLOYED':
        this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_DATE_DEPLOYED"),
          filterSubCatNam: this.getDetectDate(selectedFilterObj),
          filterSubCatId: selectedFilterObj // -1 means all
        });
        break;

      case 'DEVICE_GROUPS':
        this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_DEVICE_GROUPS"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key'] // -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

      case 'OPERATING_SYSTEM':
        this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category });
        this.selectedFilterArr.push({
          filterCatType: category,
          filterCatName: this.translate.instant("LBL_AZT_OS"),
          filterSubCatNam: selectedFilterObj['value'],
          filterSubCatId: selectedFilterObj['key'] // -1 means all
        });
        if (selectedFilterObj['selected']) {
          this.selectedFilterArr = this.selectedFilterArr.filter(function (el) { return el.filterCatType != category || el.filterSubCatId != selectedFilterObj['key'] });
        }
        break;

    }
    console.log('selectedFilterArr'); console.log(this.selectedFilterArr);
  }

  applyFilter() {
    let paramsObj = {};
    this.selectedFilterArr.map((selectedFilter) => {
      switch (selectedFilter['filterCatType']) {
        case 'AGGREGATE':

          break;
        case 'DETECT_DATE':
          paramsObj = { ...paramsObj, ...this.getDetectDateParams(selectedFilter['filterSubCatId']) };
          break;

        case 'DATE_LAST_MODIFIED':
          paramsObj = { ...paramsObj, ...this.getLastModifiedDateParams(selectedFilter['filterSubCatId']) };
          break;

        case 'DATE_DEPLOYED':
          paramsObj = { ...paramsObj, ...this.getDeployedDateParams(selectedFilter['filterSubCatId']) };
          break;

        case 'DEVICE_GROUPS':
          let deviceGroups = { device_group: selectedFilter['filterSubCatId'] };
          paramsObj = { ...paramsObj, ...deviceGroups };
          break;

        case 'OPERATING_SYSTEM':
          let oSName = { os_name: selectedFilter['filterSubCatNam'] };
          paramsObj = { ...paramsObj, ...oSName };
          break;

        case 'DETECT_DEVICE_STATUS':
          paramsObj['active'] = this.getDeviceParams(selectedFilter['filterSubCatId']);
          break;

        case 'STATUS':
          if (paramsObj['status']) {
            paramsObj['status'] = paramsObj['status'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let statusParams = { status: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...statusParams };
          }

          break;

        case 'POLICY_GROUP':
          let statusParams = { policy_group: selectedFilter['filterSubCatId'] };
          paramsObj = { ...paramsObj, ...statusParams };

          break;

        case 'NOTIFICATION_TYPE':
          if (paramsObj['category']) {
            paramsObj['category'] = paramsObj['category'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let notificationParams = { category: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...notificationParams };
          }
          break;

        case 'TRIGGER_FILE':
          if (paramsObj['trigger_file']) {
            paramsObj['trigger_file'] = paramsObj['trigger_file'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let triggerParams = { trigger_file: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...triggerParams };
          }
          break;

        case 'EVENT_TYPE':
          if (paramsObj['category']) {
            paramsObj['category'] = paramsObj['category'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let triggerParams = { category: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...triggerParams };
          }
          break;

        case 'USERNAME':
          if (paramsObj['user']) {
            paramsObj['user'] = paramsObj['user'] + '|' + selectedFilter['filterSubCatId'];
          } else {
            let triggerParams = { user: selectedFilter['filterSubCatId'] };
            paramsObj = { ...paramsObj, ...triggerParams };
          }
          break;
      }
    })
    let nextData = {};
    if (this.isAuditTrail) {
      delete paramsObj['STATUS'];
      delete paramsObj['NOTIFICATION_TYPE'];
      delete paramsObj['TRIGGER_FILE'];
      nextData['url'] = 'audit';
    }

    if (this.isAlert) {
      delete paramsObj['EVENT_TYPE'];
      delete paramsObj['USERNAME'];
      nextData['url'] = 'alert';
    }

    if (this.isDevice) {
      delete paramsObj['EVENT_TYPE'];
      delete paramsObj['USERNAME'];
      nextData['url'] = 'device';
    }

    if (this.isDeviceGroups) {
      delete paramsObj['EVENT_TYPE'];
      delete paramsObj['USERNAME'];
      nextData['url'] = 'device-groups';
    }

    nextData['data'] = paramsObj;
    console.log('nextData: '); console.log(nextData);
    this._notificationService.filterSharingSubject.next(nextData);
  }

  getDetectDate(days) {
    if (days == 1) {
      return this.translate.instant("LBL_AZT_LAST_24_HOUR");
    } else if (days == 7) {
      return this.translate.instant("LBL_AZT_LAST_7_DAYS");
    } else if (days == 30) {
      return this.translate.instant("LBL_AZT_LAST_30_DAYS");
    } else {
      return this.translate.instant("LBL_AZT_LAST_365_DAYS");
    }
  }

  getDeviceStatus(status) {
    if (status == 1) {
      return this.translate.instant("LBL_AZT_DEVICE_STATUS_ACTIVE");
    } else {
      return this.translate.instant("LBL_AZT_DEVICE_STATUS_INACTIVE");
    }
  }

  getDeviceParams(status) {
    if (status == 1) {
      return this.translate.instant("LBL_AZT_DEVICE_STATUS_TRUE");
    } else {
      return this.translate.instant("LBL_AZT_DEVICE_STATUS_FALSE");
    }
  }

  getDetectDateParams(days) {
    let format = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    let previousDays = new Date();
    previousDays.setDate(new Date().getDate() - days);
    // if (days == 1) {
    //   return { date_added__lte: this.datepipe.transform(new Date(), format), date_added__gte: this.datepipe.transform(previousDays, format) };
    // } else if (days == 7) {
    //   return { date_added__lte: this.datepipe.transform(new Date(), format), date_added__gte: this.datepipe.transform(previousDays, format) };
    // } else if (days == 30) {
    //   return { date_added__lte: this.datepipe.transform(new Date(), format), date_added__gte: this.datepipe.transform(previousDays, format) };
    // } else {
    //   return { date_added__lte: this.datepipe.transform(new Date(), format), date_added__gte: this.datepipe.transform(previousDays, format) };
    // }
    if (this.isAlert)
      return this.alertcondition(format, previousDays);
    else
      return this.audittrailcondition(format, previousDays);
  }



  private audittrailcondition(format: string, previousDays: Date) {
    return { date_added__lte: this.datepipe.transform(new Date(), format), date_added__gte: this.datepipe.transform(previousDays, format) };
  }

  private alertcondition(format: string, previousDays: Date) {
    return { recorded__lte: this.datepipe.transform(new Date(), format), recorded__gte: this.datepipe.transform(previousDays, format) };
  }

  getLastModifiedDateParams(days) {
    let format = 'yyyy-MM-ddThh:mm';
    let previousDays = new Date();
    previousDays.setDate(new Date().getDate() - days);
    if (days == 1) {
      return { last_seen__lte: this.datepipe.transform(new Date(), format), last_seen__gte: this.datepipe.transform(previousDays, format) };
    } else if (days == 7) {
      return { last_seen__lte: this.datepipe.transform(new Date(), format), last_seen__gte: this.datepipe.transform(previousDays, format) };
    } else if (days == 30) {
      return { last_seen__lte: this.datepipe.transform(new Date(), format), last_seen__gte: this.datepipe.transform(previousDays, format) };
    } else {
      return { last_seen__lte: this.datepipe.transform(new Date(), format), last_seen__gte: this.datepipe.transform(previousDays, format) };
    }
  }

  getDeployedDateParams(days) {
    let format = 'yyyy-MM-ddThh:mm';
    let previousDays = new Date();
    previousDays.setDate(new Date().getDate() - days);
    if (days == 1) {
      return { creation__lte: this.datepipe.transform(new Date(), format), creation__gte: this.datepipe.transform(previousDays, format) };
    } else if (days == 7) {
      return { creation__lte: this.datepipe.transform(new Date(), format), creation__gte: this.datepipe.transform(previousDays, format) };
    } else if (days == 30) {
      return { creation__lte: this.datepipe.transform(new Date(), format), creation__gte: this.datepipe.transform(previousDays, format) };
    } else {
      return { creation__lte: this.datepipe.transform(new Date(), format), creation__gte: this.datepipe.transform(previousDays, format) };
    }
  }

  getDeviceGroupsParams(device) {

  }

  getOSParams(operating_system) {

  }

}
