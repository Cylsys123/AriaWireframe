import { Component, Input, OnChanges, OnInit, ViewChild } from '@angular/core';
import { AuthService } from 'src/app/features/auth/services/auth.service';

@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.css']
})
export class MenuListComponent implements OnInit {

  @Input() isCollapsed: boolean = false;
  versionDetail: any;


  constructor(
    private _authService: AuthService,
  ) {

  }

  ngOnInit(): void {
    this.getVersion();

  }




  getVersion() {

    this._authService.getVersion().subscribe((res: any) => {

      this.versionDetail = res.version;
    })
  }


}
