import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-left-sidebar',
  templateUrl: './left-sidebar.component.html',
  styleUrls: ['./left-sidebar.component.css']
})
export class LeftSidebarComponent implements OnInit {

  
  isOpened: boolean = false;
  isCollapsed: boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

  isOpen() {
    return this.isOpened;
  }


  showHide() {
    this.isOpened = !this.isOpened;
  }

  toggleMenu() {
    this.isCollapsed = !this.isCollapsed;
  }
}
