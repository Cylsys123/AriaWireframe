import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inner-sidebar',
  templateUrl: './inner-sidebar.component.html',
  styleUrls: ['./inner-sidebar.component.css']
})
export class InnerSidebarComponent implements OnInit {
  isOpened: boolean = false;
  isPolicyInstallWizard: boolean = false;
  isAdvanceSettings: boolean = false;

  constructor(private _router: Router) { }

  ngOnInit(): void {
  }

  isOpen() {
    return this.isOpened;
  }


  showHide() {
    this.isOpened = !this.isOpened;
  }

  setTitle() {

    if (this._router.url == "/policy-group") {
      this.isPolicyInstallWizard = true;
    } else if (this._router.url == "/settings/advanced-settings") {
      this.isPolicyInstallWizard = true;
    }


  }


  ngAfterContentChecked(): void {
    this.setTitle();
  }
}
