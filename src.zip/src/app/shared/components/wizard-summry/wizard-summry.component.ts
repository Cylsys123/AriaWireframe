import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wizard-summry',
  templateUrl: './wizard-summry.component.html',
  styleUrls: ['./wizard-summry.component.css']
})
export class WizardSummryComponent implements OnInit {

  isOpened: boolean=false;
  isPolicyInstallWizard: boolean = false;
  constructor(private _router: Router) { }

  ngOnInit(): void {
  }

  isOpen(){
    return this.isOpened;
   }
  
   
  showHide(){
    this.isOpened =!this.isOpened;
  }

  setTitle() {

    if (this._router.url == "/policy-group") {
      this.isPolicyInstallWizard = true;
    } else if (this._router.url == "/policy-group/protection-mode") {
      this.isPolicyInstallWizard = true;
    }
    else if (this._router.url == "/policy-group/protection-policy") {
      this.isPolicyInstallWizard = true;
    }
    else if (this._router.url == "/policy-group/exception-policy") {
      this.isPolicyInstallWizard = true;
    }
    else if (this._router.url == "/policy-group/notification-policy") {
      this.isPolicyInstallWizard = true;
    }
    else if (this._router.url == "/policy-group/system-policy") {
      this.isPolicyInstallWizard = true;
    }
    else if (this._router.url == "/policy-group/miscellaneous-policy") {
      this.isPolicyInstallWizard = true;
    }
    // else if (this._router.url == "/policy-group/properties") {
    //   this.isPolicyInstallWizard = true;
    // }
  }


  ngAfterContentChecked(): void {
    this.setTitle();
  }

}
