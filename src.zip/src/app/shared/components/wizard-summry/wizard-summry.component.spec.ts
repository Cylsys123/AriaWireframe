import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WizardSummryComponent } from './wizard-summry.component';

describe('WizardSummryComponent', () => {
  let component: WizardSummryComponent;
  let fixture: ComponentFixture<WizardSummryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WizardSummryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WizardSummryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
