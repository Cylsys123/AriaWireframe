import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MediumWidgetsComponent } from './medium-widgets.component';

describe('MediumWidgetsComponent', () => {
  let component: MediumWidgetsComponent;
  let fixture: ComponentFixture<MediumWidgetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MediumWidgetsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MediumWidgetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
