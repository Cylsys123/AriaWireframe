import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-medium-widgets',
  templateUrl: './medium-widgets.component.html',
  styleUrls: ['./medium-widgets.component.css']
})
export class MediumWidgetsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  mediumWidgets = [
    {
      "name":"Protected Device",
      "count":300,
      "arrow":"DOWN",
      "percentageCount":"10%",
      "summaryData":{
        "columnKeyName":[
          "Type",
          "Applications"
        ],
        "value":[
          {
            "lbl_type":"Online",
            "lbl_application":200
          },
          {
            "lbl_type":"Offline",
            "lbl_application":90
          },
          {
            "lbl_type":"New",
            "lbl_application":10
          }
        ]}
    },
    {
      "name":"Total Application",
      "count":300,
      "arrow":"DOWN",
      "percentageCount":"10%",
      "summaryData":{
        "columnKeyName":[
          "Type",
          "Applications"
        ],
        "value":[
          {
            "lbl_type":"Trusted",
            "lbl_application":60
          },
          {
            "lbl_type":"Untrusted",
            "lbl_application":40
          },
          {
            "lbl_type":"New",
            "lbl_application":20
          }
        ]}
    },
    {
      "name":"Devices at Risk",
      "count":"Top 3",
      
      "summaryData":{
        "columnKeyName":[
          "IP",
          "Vulnerabilities"
        ],
        "value":[
          {
            "lbl_type":"192.168.1.122",
            "lbl_application":50
          },
          {
            "lbl_type":"192.168.1.122",
            "lbl_application":30
          },
          {
            "lbl_type":"192.168.1.122",
            "lbl_application":20
          }
        ]}
    },
    {
      "name":"Attack / Threats",
      "count":"Top 3",
      // "arrow":"DOWN",
      // "percentageCount":"10%",
      "summaryData":{
        "columnKeyName":[
          "Treat",
          "Attacks"
        ],
        "value":[
          {
            "lbl_type":"Revlective Injection",
            "lbl_application":50
          },
          {
            "lbl_type":"No Trust",
            "lbl_application":30
          },
          {
            "lbl_type":"Unauthorised Binary",
            "lbl_application":20
          }
        ]}
    }
  
  ]

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.mediumWidgets, event.previousIndex, event.currentIndex);
  }
}
