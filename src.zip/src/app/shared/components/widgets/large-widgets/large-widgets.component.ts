import { Component, Input, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Router } from '@angular/router';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-large-widgets',
  templateUrl: './large-widgets.component.html',
  styleUrls: ['./large-widgets.component.css']
})
export class LargeWidgetsComponent implements OnInit {

  @Input() largeWidgetParams: object[];
  newDeviceWidgetArr: any = [];
  latestAlertArr: any = [];
  inventoryAppsArr: any = [];
  latestAlertCatArr: any = [];
  latestAlertStatusArr: any = [];
  constructor(private translate: TranslateService,
    private sharedService: SharedService,
    private _route: Router) { }

  ngOnInit(): void {
    this._setPreData();
    this._setWidgetDataOnLoad();
  }

  private _setPreData() {
    this.newDeviceWidgetArr.push(
      {
        "name": this.translate.instant("LBL_AZT_NEW_DEVICE"),
        "count": 300,
        "arrow": "DOWN",
        "percentageCount": "10%",
        "summaryData": {
          "columnKeyName": [
            this.translate.instant('LBL_AZT_DEVICE_NAME'),
            this.translate.instant('LBL_AZT_OS'),
            this.translate.instant('LBL_AZT_IP'),
            this.translate.instant('LBL_AZT_GROUP'),
            this.translate.instant('LBL_AZT_APP_COUNT'),
            this.translate.instant('LBL_AZT_ACTION')
          ],
          "value": []
        }
      });

    this.latestAlertArr.push(
      {
        "name": this.translate.instant("LBL_AZT_LATEST_ALERTS"),
        "count": 300,
        "arrow": "DOWN",
        "percentageCount": "10%",
        "summaryData": {
          "columnKeyName": [
            this.translate.instant('LBL_AZT_IP'),
            this.translate.instant('LBL_AZT_MESSAGE'),
            this.translate.instant('LBL_AZT_CATEGORY'),
            this.translate.instant('LBL_AZT_STATUS'),
            this.translate.instant('LBL_AZT_ACTION')
          ],
          "value": []
        }
      });

      this.inventoryAppsArr.push(
        {
          "name": this.translate.instant("LBL_AZT_NEWLY_DISCOVERED_APPS"),
          "count": 300,
          "arrow": "DOWN",
          "percentageCount": "10%",
          "summaryData": {
            "columnKeyName": [
              this.translate.instant('LBL_AZT_APPLICATION'),
              this.translate.instant('LBL_AZT_DEVICES'),
              this.translate.instant('LBL_AZT_PLATFORM'),
              this.translate.instant('LBL_AZT_ACTION')
            ],
            "value": []
          }
        });

    this.latestAlertCatArr = JSON.parse(localStorage.getItem('alertCategory'));
    this.latestAlertStatusArr = JSON.parse(localStorage.getItem('alertStatus'));
  }

  private _setWidgetDataOnLoad() {
    for (let widget of this.largeWidgetParams) {
      if (widget['name'] == 'device' && widget['data'] !== undefined) {
        this.newDeviceWidgetArr[0]['summaryData']['value'] = widget['data'].results;
      } else if (widget['name'] == 'alert' && widget['data'] !== undefined) {
        this.latestAlertArr[0]['summaryData']['value'] = widget['data'];
      } else if (widget['name'] == 'apps' && widget['data'] !== undefined) {
        this.inventoryAppsArr[0]['summaryData']['value'] = widget['data'];
      }
    }

  }

  getAlertStatusAndCat(id: number | string, type: string) {
    return type == 'status' ? this.latestAlertStatusArr['Status'].filter((mData) => { return mData[id] })[0][id] :
      this.latestAlertCatArr['Categories'].filter((mData) => { return mData[id] })[0][id];
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.newDeviceWidgetArr, event.previousIndex, event.currentIndex);
    moveItemInArray(this.latestAlertArr, event.previousIndex, event.currentIndex);
  }

  onClickAlert(alerts) {

    this.sharedService.alertObj.id = alerts.id;
    this.sharedService.alertObj.device_id = alerts.device_id;
    this.sharedService.alertObj.category = alerts.category;
    this.sharedService.alertObj.status = alerts.status;
    this._route.navigate(['/notification']);

  }

}
