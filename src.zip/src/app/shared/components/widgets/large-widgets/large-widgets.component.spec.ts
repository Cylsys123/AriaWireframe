import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LargeWidgetsComponent } from './large-widgets.component';

describe('LargeWidgetsComponent', () => {
  let component: LargeWidgetsComponent;
  let fixture: ComponentFixture<LargeWidgetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LargeWidgetsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LargeWidgetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
