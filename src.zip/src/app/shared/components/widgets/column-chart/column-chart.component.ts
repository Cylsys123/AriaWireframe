import { Component, OnInit } from '@angular/core';
import * as Chart from 'chart.js';

@Component({
  selector: 'app-column-chart',
  templateUrl: './column-chart.component.html',
  styleUrls: ['./column-chart.component.css']
})
export class ColumnChartComponent implements OnInit {



  constructor() { }

  ngOnInit(): void {
  }

  chartData = [
    {
      data: [80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80],
      label: 'Severe Risk',
      backgroundColor: [
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
        'rgb(217 57 29)',
      ],


    },
    {
      data: [120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120],
      label: 'Safe',
      backgroundColor: [
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
        'rgb(119 188 31)',
      ],


    },
    {
      data: [45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45,],
      label: 'Protected',
      backgroundColor: [
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
        'rgb(209 125 0)',
      ],
    },


  ];

  chartLabels = [
    '1 Jan',
    '2 Jan',
    '3 Jan',
    '4 Jan',
    '5 Jan',
    '6 Jan',
    '7 Jan',
    '8 Jan',
    '9 Jan',
    '10 Jan',
    '11 Jan',
    '12 Jan',
    '13 Jan',
    '14 Jan',
    '15 Jan',
  ];



  chartOptions = {
    responsive: true,
    tooltips: { enabled: true },
    hover: { mode: null },
    circular: true,

  };


}
