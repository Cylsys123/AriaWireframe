import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-widgets',
  templateUrl: './widgets.component.html',
  styleUrls: ['./widgets.component.css']
})
export class WidgetsComponent implements OnInit {

  @Input() widgetParams: object[];
  // @Input() deviceGroupParams: object[];
  constructor() { }

  ngOnInit(): void {
  }

}
