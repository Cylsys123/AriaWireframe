import { Component, Input, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from 'src/app/shared/services/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fullscreen-widgets',
  templateUrl: './fullscreen-widgets.component.html',
  styleUrls: ['./fullscreen-widgets.component.css']
})
export class FullscreenWidgetsComponent implements OnInit {

  @Input() fullscreenWidgetParams: object[];
  newDeviceWidgetArr: any = [];
  latestAlertArr: any = [];
  latestAlertCatArr: any = [];
  latestAlertStatusArr: any = [];
  constructor(private translate: TranslateService,
    private sharedService: SharedService,
    private _route: Router) { }

  ngOnInit(): void {
    this._setPreData();
    this._setWidgetDataOnLoad();
  }

  private _setPreData() {
    this.newDeviceWidgetArr.push(
      {
        "name": this.translate.instant("LBL_AZT_DEVICE_GROUPS"),
        "count": 300,
        "arrow": "DOWN",
        "percentageCount": "10%",
        "summaryData": {
          "columnKeyName": [
            this.translate.instant('LBL_AZT_DEVICE_GROUPS_NAME'),
            this.translate.instant('LBL_AZT_COUNT_OF_ALERTS'),
            this.translate.instant('LBL_AZT_POLICY_GROUP'),
            this.translate.instant('LBL_AZT_DEVICEs_IN_GROUP'),
            this.translate.instant('LBL_AZT_DATE_CREATED'),
            this.translate.instant('LBL_AZT_DATE_MODIFIED')
          ],
          "value": []
        }
      });
  }

  private _setWidgetDataOnLoad() {

    for (let widget of this.fullscreenWidgetParams) {
      if (widget['name'] == 'deviceGroup' && widget['data'].length > 0) {
        this.newDeviceWidgetArr[0]['summaryData']['value'] = widget['data'];
      }
    }

  }

  // getAlertStatusAndCat(id: number | string, type: string) {
  //   return type == 'status' ? this.latestAlertStatusArr['Status'].filter((mData) => { return mData[id] })[0][id] :
  //     this.latestAlertCatArr['Categories'].filter((mData) => { return mData[id] })[0][id];
  // }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.newDeviceWidgetArr, event.previousIndex, event.currentIndex);
    // moveItemInArray(this.latestAlertArr, event.previousIndex, event.currentIndex);
  }

}
