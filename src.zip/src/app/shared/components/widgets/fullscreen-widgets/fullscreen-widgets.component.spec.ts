import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FullscreenWidgetsComponent } from './fullscreen-widgets.component';

describe('FullscreenWidgetsComponent', () => {
  let component: FullscreenWidgetsComponent;
  let fixture: ComponentFixture<FullscreenWidgetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FullscreenWidgetsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FullscreenWidgetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
