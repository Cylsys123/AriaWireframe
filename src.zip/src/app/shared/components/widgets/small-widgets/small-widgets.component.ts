import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-small-widgets',
  templateUrl: './small-widgets.component.html',
  styleUrls: ['./small-widgets.component.css']
})
export class SmallWidgetsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  smallWidgets = [
    {
      // img:'assets/img/status.svg',
      title:'Status',
      status: 'InActive'
    },
    {
      title:'Trust Binaries',
      status: '2000',
      "arrow":"UP",
      "percentageCount":"10%",
    },
    {
      title:'Trust Stores',
      status: '20',
      "arrow":"UP",
      "percentageCount":"10%",
    },
    {
      title:'Trust Points',
      status: '20',
      "arrow":"UP",
      "percentageCount":"10%",
    },
   
  ];

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.smallWidgets, event.previousIndex, event.currentIndex);
  }
}
