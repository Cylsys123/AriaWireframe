export enum PolicyNav {
    POLICY_GROUPS = "PG",
    PROTECTION_POLICIES = "PP",
    EXCEPTION_POLICIES = "EP",
    NOTIFICATION_POLICIES = "NP",
    SYSTEM_POLICIES = "SP"
}


export enum ProtectionPolicy {
    // POLICY_GROUPS = "POLICY_GROUPS",
    PROTECTION_POLICIES = "Protection Policies"
}

export enum PolicyUrl {
    POLICY_GROUP = "/policy",
    PROTECTION_POLICY = "policy/protection-policy",
    EXCEPTION_POLICY = "policy/exception-policy",
    NOTIFICATION_POLICY = "policy/notification-policies",
    SYSTEM_POLICY = "policy/system-policies"
}

export enum NetworkSetupType {
    AIRGAPPED = "airgapped",
    DIRECT_ONLINE = "directOnline",
    PROXY_ENABLED = "proxyEnabled"
}

export enum DeviceNav {
    DEVICE_GROUPS = "Device Groups",
    PROTECTION_POLICIES = "Protection Policies",
    EXCEPTION_POLICIES = "Exception Policies",
    NOTIFICATION_POLICIES = "Notification Policies",
    SYSTEM_POLICIES = "System Policies"
}

export enum DeviceUrl {
    DEVICE_GROUP = "/Devices",
    PROTECTION_POLICY = "policy/protection-policy",
    EXCEPTION_POLICY = "policy/exception-policy",
    NOTIFICATION_POLICY = "policy/notification-policies",
    SYSTEM_POLICY = "policy/system-policies"
}

export enum InvAppGroupBy{
    ALL= 'all',
    PLATFORM = 'platforms',
    VENDOR = 'vendors',
    VALIDATION_STATUS = 'validation_statuses',
}
