import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-priview',
  templateUrl: './image-priview.component.html',
  styleUrls: ['./image-priview.component.css']
})
export class ImagePriviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
