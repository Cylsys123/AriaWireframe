import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClearHistoryComponent } from './clear-history.component';

describe('ClearHistoryComponent', () => {
  let component: ClearHistoryComponent;
  let fixture: ComponentFixture<ClearHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClearHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClearHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
