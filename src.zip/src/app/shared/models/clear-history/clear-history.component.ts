import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clear-history',
  templateUrl: './clear-history.component.html',
  styleUrls: ['./clear-history.component.css']
})
export class ClearHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
