import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
      isolate: false
    }),
  ],
  exports: [
    TranslateModule,
  ]
})
export class SharedModule {
  constructor(private translate: TranslateService) {

    translate.addLangs(["en", "fr"]);
    translate.setDefaultLang('en');

    // let browserLang = translate.getBrowserLang();
    let browserLang = 'en';
    translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
  }
}
