import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpLoaderFactory } from './shared.module';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { TooltipModule } from 'ng2-tooltip-directive';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HttpClientModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      },
      isolate: false
    }),
    NgxUiLoaderModule,
    TooltipModule,
    FormsModule

  ],
  exports: [
    CommonModule,
    TranslateModule,
    NgxUiLoaderModule,
    TooltipModule,
    FormsModule
  ]
})
export class SharedLazyModule { }
