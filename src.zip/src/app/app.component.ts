import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ApiEndpointsService } from './core/services/api-endpoints.service';
import { ApiHttpService } from './core/services/api-http.service';
import { AuthService } from './features/auth/services/auth.service';
import { SharedService } from '../app/shared/services/shared.service';
import { Console } from 'console';
import { Subscription } from 'rxjs';

export let browserRefresh = false;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isUserLoggedIn: boolean = false;
  subscription: Subscription;
  constructor(private _sharedService: SharedService) {

    window.onbeforeunload = function (e) {
      
      if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
        console.info("This page is reloaded1");
      } else {
        let hash = sessionStorage.getItem("TabHash");
        let tabs = JSON.parse(localStorage.getItem("TabsOpen") || "{}");
        delete tabs[hash];

        localStorage.setItem("TabsOpen", JSON.stringify(tabs));
        if (Object.keys(tabs).length === 0) {
          localStorage.setItem('isUserLoggedIn', 'false')
          let name = "sessionid";
          document.cookie =
            name + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
          name = "csrftoken";
          document.cookie =
            name + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
        }
      }
    };

    window.onload = function (e) {
      let tabhash = sessionStorage.getItem("TabHash")
      //console.log(4)

      if (!JSON.stringify(localStorage.getItem("TabsOpen")).includes(tabhash)) {

      }

      if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
        //console.info("This page is reloaded");
      } else {

        if (!JSON.stringify(localStorage.getItem("TabsOpen")).includes(tabhash)
        ) {
          if (performance.navigation.type == performance.navigation.TYPE_NAVIGATE) {
            let hash = "tab_" + +new Date();
            sessionStorage.setItem("TabHash", hash);
            let tabs = JSON.parse(localStorage.getItem("TabsOpen") || "{}");
            tabs[hash] = true;
            if (Object.keys(tabs).length > 0) {
              localStorage.setItem('isUserLoggedIn', 'true')
            }
            localStorage.setItem("TabsOpen", JSON.stringify(tabs));
          }
        }
      }
    };


  }


  ngOnInit() {
    // console.log(1)
    // if (this.isUserLoggedIn)
    //   this._sharedService.isUserLoggedIn = false;
  }

  ngAfterViewInit() {
    //console.log(2)
  }

  ngAfterViewChecked() {
    if (localStorage.getItem('isUserLoggedIn') == "true")
      this._sharedService.isUserLoggedIn = true;
  }
}
