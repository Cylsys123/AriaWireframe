import { HttpClientModule, HttpClientXsrfModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Constants } from './config/constant';
import { CoreModule } from './core/core.module';
import { AuthGuard } from './core/guards/auth.guard';
import { LoggedInAuthGuard } from './core/guards/logged-in-auth.guard';
import { CsrfTokenInterceptorService } from './core/interceptors/csrf-token-interceptor.service';
import { AuthModule } from './features/auth/auth.module';
import { DeviceModule } from './features/device/device.module';
import { HomeModule } from './features/home/home.module';
import { NotificationModule } from './features/notification/notification.module';
import { PolicyModule } from './features/policy/policy.module';
import { PostInstallWizardModule } from './features/post-install-wizard/post-install-wizard.module';
import { SharedModule } from './shared/shared.module';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TooltipModule } from 'ng2-tooltip-directive';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { InventoryModule } from './features/inventory/inventory.module';
import { ReportsModule } from './features/reports/reports.module';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    SharedModule,
    AppRoutingModule,
    CoreModule,
    AuthModule,
    HomeModule,
    PostInstallWizardModule,
    HttpClientModule,
    HttpClientXsrfModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    PolicyModule,
    InventoryModule,
    FormsModule,
    NotificationModule,
    DeviceModule,
    TooltipModule,
    InfiniteScrollModule,
    ReportsModule
  ],
  providers: [
    Constants,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CsrfTokenInterceptorService,
      multi: true
    },
    AuthGuard,
    LoggedInAuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
