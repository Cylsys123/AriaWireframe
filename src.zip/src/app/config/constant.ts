import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable()
export class Constants {

    public readonly API_ENDPOINT: string = environment.apiUrl;
    public readonly API_MOCK_ENDPOINT: string = environment.apiMockUrl;
    public readonly API_IS_DEVELOPMENT_ENV: boolean = environment.production;

    //Auth
    public readonly API_ENDPOINT_CSRF: string = 'dashboard/csrf/'
    public readonly API_ENDPOINT_LOGIN: string = 'dashboard/login/'
    public readonly API_ENDPOINT_LOGOUT: string = 'dashboard/logout/'
    public readonly API_ENDPOINT_SESSION: string = 'dashboard/session/'
    public readonly API_ENDPOINT_CHECKAUTH: string = 'dashboard/checkauth/'
    public readonly API_ENDPOINT_SECRET_QUES: string = 'dashboard/secret'
    public readonly API_ENDPOINT_CHANGE_PASSWORD: string = 'dashboard/change_password/'
    public readonly API_ENDPOINT_SYSTEM: string = 'dashboard/system/'

    //Post install Wizards
    public readonly API_ENDPOINT_NETWORK: string = 'dashboard/network/'
    public readonly API_ENDPOINT_PROXY: string = 'dashboard/proxy/'
    public readonly API_ENDPOINT_ADMIN_USER: string = 'dashboard/admin_user_creation/'
    public readonly API_ENDPOINT_SITE_NOTES: string = 'dashboard/site_notes/'
    public readonly API_ENDPOINT_SENDMAIL: string = 'dashboard/sendmail/'

    //Dashboard 360View
    public readonly API_ENDPOINT_DEVICE: string = 'dashboard/devices/'
    public readonly API_ENDPOINT_DEVICE_GROUP: string = 'dashboard/devicegroups/'
    public readonly API_ENDPOINT_ALERT_LIST: string = 'dashboard/alert/'
    public readonly API_ENDPOINT_ALERT_RESOLVE: string = 'dashboard/alert/resolve/'

    public readonly API_ENDPOINT_ALERT_LIST_TEST: string = 'dashboard/alert/group/?page_size=10&device=ac8fbf57-ee90-499d-9610-62c354f0405a&category=1&status=1'
    public readonly API_ENDPOINT_ALERT_LIST_GROUP: string = 'dashboard/alert/group/'
    public readonly API_ENDPOINT_ALERT_CATEGORY_LIST: string = 'dashboard/alert/category/'
    public readonly API_ENDPOINT_ALERT_STATUS: string = 'dashboard/alert/status/'
    public readonly API_ENDPOINT_ALERT_TRIGGER: string = 'dashboard/alert/trigger/'
    public readonly API_ENDPOINT_ALERT_FILENAME: string = 'dashboard/alert/filenames/'
    public readonly API_ENDPOINT_CHANGE_DEVICE: string = 'dashboard/devices/change_device_group/'
    public readonly API_ENDPOINT_AUDIT_TRAIL: string = 'dashboard/audit/'
    public readonly API_ENDPOINT_AUDIT_TRAIL_CATEGORY_LIST: string = 'dashboard/audit/categories/'
    public readonly API_ENDPOINT_AUDIT_TRAIL_USERS: string = 'dashboard/audit/users/'
    public readonly API_ENDPOINT_UNREGISTER_DEVICE: string = 'dashboard/devices/unregister/'
    //Policy
    public readonly API_ENDPOINT_POLICY: string = 'dashboard/policy/'
    public readonly API_ENDPOINT_POLICY_GROUP: string = 'dashboard/policygroups/'
    public readonly API_ENDPOINT_POLICY_GROUP_TEMP: string = 'dashboard/policygroups/temporary/'
    public readonly API_ENDPOINT_COUNTER_MEASURE_POLICY: string = 'dashboard/counterMeasurePolicy/'
    public readonly API_ENDPOINT_CREATE_POLICY_GROUP: string = 'dashboard/policygroup/create/'
    public readonly API_ENDPOINT_POLICY_GROUP_VALIDATE: string = 'dashboard/policygroups/validate/name/'
    //policy group name validation url is pending

    // Export to CSV
    public readonly API_ENDPOINT_GET_AUDIT_CSV_FORMAT: string = 'dashboard/audit/export/csv/'
    public readonly API_ENDPOINT_GET_AUDIT_SYSLOG_FORMAT: string = 'dashboard/audit/export/syslog/'

    // Inventory
    public readonly API_ENDPOINT_INVENTORY_APP: string = 'dashboard/applications/'
    public readonly API_ENDPOINT_INVENTORY_APP_GROUPS: string = 'dashboard/applications/groups/'
    public readonly API_ENDPOINT_INVENTORY_APP_FILENAMES: string = 'dashboard/applications/filenames/'
    public readonly API_ENDPOINT_INVENTORY_APP_NAMES: string = 'dashboard/applications/names/'
    public readonly API_ENDPOINT_INVENTORY_APP_DEVICES: string = '/dashboard/applications/devices/'

    // Report
    public readonly API_ENDPOINT_REPORTS: string = 'reports/'
    public readonly API_ENDPOINT_GET_REPORT_GROUPS: string = 'reportgroups/'
    
}