export const environment = {
  production: true,
  apiUrl:location.origin,
  apiMockUrl:location.origin,
  domainUrl:location.origin,
  app_env: 'production'
};
